// ---------------------------------------------------------------------------
// multiplayer-service — Serveur de salles multijoueur (socket.io) pour RBND
// Port 3003 FIXE · path '/' (utilisé par Caddy pour le forwarding, NE PAS changer)
//
// Contrat partagé avec le client :
//   interface MpPlayerState { id: string; name: string; ballId: string; color: number; x: number; y: number; z: number }
//
//   Client -> Serveur :
//     mp:join   { room, name, ballId, color }  ack { ok:true, room } | { ok:false, error }
//     mp:create { name, ballId, color }        ack { ok:true, room }
//     mp:move   { x, y, z }                    (pas d'ack, pas de rebroadcast)
//     mp:chat   { text }                       (rate-limit 1 msg / 500 ms)
//     mp:leave  —
//     mp:ping   —                              ack (t: number)
//
//   Serveur -> Client :
//     mp:joined        { room, you, players: MpPlayerState[] }
//     mp:player-joined { player: MpPlayerState }
//     mp:player-left   { id, name }
//     mp:snap          { p: Array<[id, x, y, z]> }   (boucle 66 ms ≈ 15 Hz)
//     mp:chat          { id, from, name, text, ts }
//     mp:sys           { text, ts }
// ---------------------------------------------------------------------------
import { createServer } from 'http'
import { Server, Socket } from 'socket.io'

interface MpPlayerState {
  id: string
  name: string
  ballId: string
  color: number
  x: number
  y: number
  z: number
}

type JoinAck = (res: { ok: true; room: string } | { ok: false; error: string }) => void
type CreateAck = (res: { ok: true; room: string }) => void
type PingAck = (t: number) => void

const PORT = 3003
const PUBLIC_ROOM = 'public'
const MAX_PLAYERS = 12
const SNAP_INTERVAL_MS = 66 // ≈ 15 Hz
const CHAT_COOLDOWN_MS = 500
const NAME_MAX = 16
const CHAT_MAX = 200
const SPAWN_RANGE = 14
const SPAWN_Y = 1.5
const MOVE_LIMIT = 130
const MOVE_Y_MIN = -10
const MOVE_Y_MAX = 60
const DEFAULT_COLOR = 0xd4574b
const DEFAULT_BALL_ID = 'classic'
/** Code de salle : A-Z0-9 sans ambiguïté (pas de 0/O ni 1/I). */
const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'

const httpServer = createServer()
const io = new Server(httpServer, {
  // DO NOT change the path, it is used by Caddy to forward the request to the correct port
  path: '/',
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
  pingTimeout: 60000,
  pingInterval: 25000,
})

/** Salles : code -> (socketId -> état joueur). « public » est créée à la volée. */
const rooms = new Map<string, Map<string, MpPlayerState>>()
/** Salles modifiées depuis le dernier mp:snap (évite les emits inutiles à 15 Hz). */
const dirtyRooms = new Set<string>()
/** Anti-spam chat : socketId -> timestamp du dernier message accepté. */
const lastChatAt = new Map<string, number>()

// --- Utilitaires -----------------------------------------------------------

const clamp = (v: number, min: number, max: number): number => Math.min(max, Math.max(min, v))
const round2 = (v: number): number => Math.round(v * 100) / 100
/** Coordonnée de spawn aléatoire dans [-14, 14], arrondie à 2 décimales. */
const spawnCoord = (): number => Math.round((Math.random() * 2 - 1) * SPAWN_RANGE * 100) / 100
/** Identifiant de message chat : 9 caractères aléatoires. */
const chatId = (): string => Math.random().toString(36).slice(2, 11)

/** Génère un code de salle unique de 4 caractères (A-Z0-9 sans 0/O/1/I). */
const generateRoomCode = (): string => {
  let code: string
  do {
    code = ''
    for (let i = 0; i < 4; i += 1) {
      code += CODE_ALPHABET[Math.floor(Math.random() * CODE_ALPHABET.length)]
    }
  } while (rooms.has(code))
  return code
}

const getOrCreateRoom = (roomCode: string): Map<string, MpPlayerState> => {
  let room = rooms.get(roomCode)
  if (!room) {
    room = new Map()
    rooms.set(roomCode, room)
  }
  return room
}

/** 'public' est préservé tel quel ; les codes sont trim + uppercase. */
const normalizeRoom = (raw: unknown): string => {
  const s = typeof raw === 'string' ? raw.trim() : ''
  return s.toLowerCase() === PUBLIC_ROOM ? PUBLIC_ROOM : s.toUpperCase()
}

const sanitizeName = (raw: unknown): string => {
  const s = typeof raw === 'string' ? raw.trim().slice(0, NAME_MAX) : ''
  return s.length > 0 ? s : 'Joueur'
}

const sanitizeBallId = (raw: unknown): string => {
  const s = typeof raw === 'string' ? raw.trim().slice(0, 40) : ''
  return s.length > 0 ? s : DEFAULT_BALL_ID
}

const sanitizeColor = (raw: unknown): number => {
  const n = typeof raw === 'number' ? raw : Number(raw)
  return Number.isFinite(n) ? clamp(Math.floor(n), 0, 0xffffff) : DEFAULT_COLOR
}

const markDirty = (roomCode: string): void => {
  dirtyRooms.add(roomCode)
}

// --- Gestion des salles ----------------------------------------------------

/**
 * Retire le socket de sa salle courante : diffuse mp:player-left + mp:sys,
 * puis supprime la salle privée si elle devient vide (public toujours dispo).
 */
const leaveRoom = (socket: Socket, reason: string): void => {
  const roomCode = socket.data.room as string | undefined
  if (!roomCode) return
  socket.data.room = undefined
  socket.leave(roomCode)

  const room = rooms.get(roomCode)
  if (!room) return
  const player = room.get(socket.id)
  room.delete(socket.id)
  markDirty(roomCode)

  if (player) {
    io.to(roomCode).emit('mp:player-left', { id: socket.id, name: player.name })
    io.to(roomCode).emit('mp:sys', { text: `${player.name} a quitté la salle`, ts: Date.now() })
    console.log(`[mp] ${player.name} (${socket.id}) a quitté « ${roomCode} » (${reason}) — ${room.size} joueur(s) restant(s)`)
  }

  if (roomCode !== PUBLIC_ROOM && room.size === 0) {
    rooms.delete(roomCode)
    dirtyRooms.delete(roomCode)
    console.log(`[mp] Salle privée « ${roomCode} » supprimée (vide)`)
  }
}

/** Ajoute le joueur à la salle (spawn aléatoire), marque la salle dirty. */
const addPlayer = (
  socket: Socket,
  roomCode: string,
  name: string,
  ballId: string,
  color: number,
): MpPlayerState => {
  // Déjà dans une salle → sortie propre d'abord (player-left + sys sur l'ancienne).
  if (socket.data.room) leaveRoom(socket, 'changement de salle')

  const room = getOrCreateRoom(roomCode)
  const player: MpPlayerState = {
    id: socket.id,
    name,
    ballId,
    color,
    x: spawnCoord(),
    y: SPAWN_Y,
    z: spawnCoord(),
  }
  room.set(socket.id, player)
  socket.join(roomCode)
  socket.data.room = roomCode
  markDirty(roomCode)
  console.log(`[mp] ${name} (${socket.id}) a rejoint « ${roomCode} » — ${room.size} joueur(s)`)
  return player
}

/** Diffuse le resync complet + notifications d'arrivée (appelé après l'ack). */
const broadcastJoin = (socket: Socket, roomCode: string, joined: MpPlayerState): void => {
  const room = rooms.get(roomCode)
  if (!room) return
  const players = Array.from(room.values())
  // Resync complet à TOUS les membres (lui inclus) — chacun se reconnaît via `you`.
  for (const member of room.values()) {
    io.to(member.id).emit('mp:joined', { room: roomCode, you: member.id, players })
  }
  // Aux AUTRES membres : le nouveau joueur + message système.
  socket.to(roomCode).emit('mp:player-joined', { player: joined })
  io.to(roomCode).emit('mp:sys', { text: `${joined.name} a rejoint la salle`, ts: Date.now() })
}

// --- Connexions ------------------------------------------------------------

io.on('connection', (socket) => {
  console.log(`[mp] Connexion: ${socket.id}`)

  socket.on('mp:join', (payload: unknown, ack?: JoinAck) => {
    const respond: JoinAck = typeof ack === 'function' ? ack : () => {}
    const p = (payload ?? {}) as { room?: unknown; name?: unknown; ballId?: unknown; color?: unknown }
    const roomCode = normalizeRoom(p.room)

    if (!roomCode) {
      respond({ ok: false, error: 'Salle introuvable' })
      return
    }

    const existing = rooms.get(roomCode)
    // 'public' est toujours disponible ; un code privé doit exister.
    if (roomCode !== PUBLIC_ROOM && (!existing || existing.size === 0)) {
      respond({ ok: false, error: 'Salle introuvable' })
      return
    }
    if (existing && existing.size >= MAX_PLAYERS && !existing.has(socket.id)) {
      respond({ ok: false, error: 'Salle pleine (12 max)' })
      return
    }

    // Resync idempotent : déjà membre de cette salle → on renvoie simplement
    // l'état complet (pas de leave/re-add, pas de reset de position, pas de sys).
    if (socket.data.room === roomCode && existing && existing.has(socket.id)) {
      respond({ ok: true, room: roomCode })
      io.to(socket.id).emit('mp:joined', {
        room: roomCode,
        you: socket.id,
        players: Array.from(existing.values()),
      })
      return
    }

    const player = addPlayer(socket, roomCode, sanitizeName(p.name), sanitizeBallId(p.ballId), sanitizeColor(p.color))
    respond({ ok: true, room: roomCode })
    broadcastJoin(socket, roomCode, player)
  })

  socket.on('mp:create', (payload: unknown, ack?: CreateAck) => {
    const respond: CreateAck = typeof ack === 'function' ? ack : () => {}
    const p = (payload ?? {}) as { name?: unknown; ballId?: unknown; color?: unknown }
    const roomCode = generateRoomCode()
    rooms.set(roomCode, new Map()) // réserve le code unique
    console.log(`[mp] Salle privée « ${roomCode} » créée par ${socket.id}`)

    // Join automatique du créateur (mêmes règles/événements que mp:join).
    const player = addPlayer(socket, roomCode, sanitizeName(p.name), sanitizeBallId(p.ballId), sanitizeColor(p.color))
    respond({ ok: true, room: roomCode })
    broadcastJoin(socket, roomCode, player)
  })

  socket.on('mp:move', (payload: unknown) => {
    const roomCode = socket.data.room as string | undefined
    if (!roomCode) return
    const player = rooms.get(roomCode)?.get(socket.id)
    if (!player) return
    const p = (payload ?? {}) as { x?: unknown; y?: unknown; z?: unknown }
    const x = Number(p.x)
    const y = Number(p.y)
    const z = Number(p.z)
    if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z)) return
    player.x = clamp(x, -MOVE_LIMIT, MOVE_LIMIT)
    player.y = clamp(y, MOVE_Y_MIN, MOVE_Y_MAX)
    player.z = clamp(z, -MOVE_LIMIT, MOVE_LIMIT)
    markDirty(roomCode) // pas de rebroadcast immédiat : la boucle 15 Hz diffuse
  })

  socket.on('mp:chat', (payload: unknown) => {
    const roomCode = socket.data.room as string | undefined
    if (!roomCode) return
    const player = rooms.get(roomCode)?.get(socket.id)
    if (!player) return

    const now = Date.now()
    if (now - (lastChatAt.get(socket.id) ?? 0) < CHAT_COOLDOWN_MS) return // anti-spam, ignore

    const p = (payload ?? {}) as { text?: unknown }
    const text = (typeof p.text === 'string' ? p.text : '').trim().slice(0, CHAT_MAX)
    if (!text) return

    lastChatAt.set(socket.id, now)
    io.to(roomCode).emit('mp:chat', { id: chatId(), from: socket.id, name: player.name, text, ts: now })
  })

  socket.on('mp:leave', () => {
    leaveRoom(socket, 'mp:leave')
  })

  socket.on('mp:ping', (ack?: PingAck) => {
    if (typeof ack === 'function') ack(Date.now())
  })

  socket.on('error', (error) => {
    console.error(`[mp] Socket error (${socket.id}):`, error)
  })

  socket.on('disconnect', (reason) => {
    leaveRoom(socket, `disconnect (${reason})`)
    lastChatAt.delete(socket.id)
    console.log(`[mp] Déconnexion: ${socket.id}`)
  })
})

// --- Boucle de synchro 15 Hz -----------------------------------------------
// Un seul emit par salle et par tick, positions arrondies à 2 décimales.
// Skip : salle vide, ou rien n'a changé depuis le dernier snap (move/join/leave).
const snapTimer = setInterval(() => {
  for (const [roomCode, room] of rooms) {
    if (room.size === 0 || !dirtyRooms.has(roomCode)) continue
    dirtyRooms.delete(roomCode)
    const p = Array.from(
      room.values(),
      (pl) => [pl.id, round2(pl.x), round2(pl.y), round2(pl.z)] as [string, number, number, number],
    )
    io.to(roomCode).emit('mp:snap', { p })
  }
}, SNAP_INTERVAL_MS)

httpServer.listen(PORT, () => {
  console.log(`Multiplayer service (socket.io) listening on port ${PORT}`)
})

// --- Arrêt propre ----------------------------------------------------------
const shutdown = (signal: string): void => {
  console.log(`Received ${signal} signal, shutting down server...`)
  clearInterval(snapTimer)
  httpServer.close(() => {
    console.log('Multiplayer service closed')
    process.exit(0)
  })
}

process.on('SIGTERM', () => shutdown('SIGTERM'))
process.on('SIGINT', () => shutdown('SIGINT'))
