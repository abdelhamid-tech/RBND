'use client';

/* ============================================================
   Moteur de jeu — Laboratoire de Physique
   400 niveaux · 20 mondes thématisés :
   - Palette par monde (ciel, sol shader, néons, obstacles, lumières)
   - Layout d'obstacles généré de façon déterministe (seed = id)
   - Mécaniques : bumpers (flipper), obstacles mobiles, portails
   - Défis : collect / survival / combo + niveaux BOSS de fin de monde
   Rendu du ballon et physique pilotés par BallDef (boutique).
============================================================ */

import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import type { BallDef, LevelDef } from '@/lib/game/types';
import { CHAPTERS } from '@/lib/game/levels';
import { buildBallTexture } from '@/lib/game/ball-textures';
import { crazyGames } from '@/lib/crazygames';
import { Crown, Pause, Play, RotateCcw, DoorOpen, Volume2, VolumeX, Sparkles } from 'lucide-react';

export interface GameResult {
  success: boolean;
  timeMs: number;
  progressLabel: string;
  stats: { bounces: number; collected: number; bestChain: number; timeLeftSec: number };
}

interface HudState {
  timeLabel: string;
  timeFrac: number;
  timeDanger: boolean;
  progressMain: string;
  progressSub: string;
  restFrac: number;
  speed: number;
  height: number;
  energy: number;
  fps: number;
}

interface Props {
  level: LevelDef;
  ball: BallDef;
  onExit: () => void;
  onResult: (r: GameResult) => void;
}

type Phase = 'countdown' | 'playing' | 'paused' | 'done';

const R = 0.55;
const GRAV = 35.0;
const MAX_V = 50.0;
const FIXED_DT = 1 / 120;
const ARENA = 12;
const COMBO_WINDOW = 4.0;
const BUMPER_R = 0.95;
const BUMPER_H = 1.15;

interface TargetSpec {
  pos: THREE.Vector3;
}

interface TargetObj {
  group: THREE.Group;
  halo: THREE.Mesh;
  baseY: number;
  phase: number;
  dying: boolean;
  scale: number;
  collected: boolean;
}

interface ObstacleSpec {
  x: number;
  z: number;
  w: number;
  h: number;
  d: number;
  /** axe d'oscillation si obstacle mobile */
  axis: 'x' | 'z' | null;
  amp: number;
  speed: number;
  phase: number;
}

interface Layout {
  obstacles: ObstacleSpec[];
  bumpers: Array<{ x: number; z: number }>;
  portal: { ax: number; az: number; bx: number; bz: number } | null;
}

/** RNG déterministe (mulberry32) — même layout côté client et serveur */
function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Génère le layout de l'arène pour un niveau (déterministe). */
function genLayout(level: LevelDef): Layout {
  const rng = mulberry32(level.id * 7919 + 1013);
  const obstacles: ObstacleSpec[] = [];
  const centers: Array<{ x: number; z: number; w: number; d: number }> = [];

  let guard = 0;
  while (obstacles.length < level.obstacleCount && guard++ < 300) {
    const x = (rng() * 2 - 1) * (ARENA - 4.5);
    const z = (rng() * 2 - 1) * (ARENA - 4.5);
    const w = 1.3 + rng() * 2.2;
    const d = 1.3 + rng() * 2.2;
    const h = 1.2 + rng() * 3.0;
    if (Math.hypot(x, z) < 4.2) continue; // zone de spawn dégagée
    let ok = true;
    for (const c of centers) {
      if (Math.hypot(c.x - x, c.z - z) < (Math.max(c.w, c.d) + Math.max(w, d)) / 2 + 1.5) {
        ok = false;
        break;
      }
    }
    if (!ok) continue;
    obstacles.push({ x, z, w, h, d, axis: null, amp: 0, speed: 0, phase: 0 });
    centers.push({ x, z, w, d });
  }

  // Obstacles mobiles : sélection aléatoire parmi les obstacles posés
  const movers = Math.min(level.movers, obstacles.length);
  const order = obstacles.map((_, i) => i).sort(() => rng() - 0.5);
  for (let k = 0; k < movers; k++) {
    const o = obstacles[order[k]];
    const axis: 'x' | 'z' = rng() < 0.5 ? 'x' : 'z';
    const room =
      axis === 'x'
        ? ARENA - 1.2 - Math.abs(o.x) - o.w / 2
        : ARENA - 1.2 - Math.abs(o.z) - o.d / 2;
    const amp = Math.min(1.2 + rng() * 1.8, Math.max(0, room));
    if (amp > 0.3) {
      o.axis = axis;
      o.amp = amp;
      o.speed = 0.5 + rng() * 0.9;
      o.phase = rng() * Math.PI * 2;
    }
  }

  // Bumpers (butées de flipper)
  const bumpers: Array<{ x: number; z: number }> = [];
  guard = 0;
  while (bumpers.length < level.bumpers && guard++ < 200) {
    const x = (rng() * 2 - 1) * (ARENA - 3.5);
    const z = (rng() * 2 - 1) * (ARENA - 3.5);
    if (Math.hypot(x, z) < 4.0) continue;
    let ok = true;
    for (const c of centers) {
      if (Math.hypot(c.x - x, c.z - z) < Math.max(c.w, c.d) / 2 + 2.0) {
        ok = false;
        break;
      }
    }
    if (ok) {
      for (const b of bumpers) {
        if (Math.hypot(b.x - x, b.z - z) < 3.4) {
          ok = false;
          break;
        }
      }
    }
    if (!ok) continue;
    bumpers.push({ x, z });
  }

  // Portail de téléportation (paire de positions opposées)
  let portal: Layout['portal'] = null;
  if (level.portals) {
    guard = 0;
    while (guard++ < 200) {
      const a1 = rng() * Math.PI * 2;
      const r1 = 5.5 + rng() * 4.5;
      const ax = Math.cos(a1) * r1;
      const az = Math.sin(a1) * r1;
      const a2 = a1 + Math.PI + (rng() - 0.5) * 1.2;
      const r2 = 5.5 + rng() * 4.5;
      const bx = Math.cos(a2) * r2;
      const bz = Math.sin(a2) * r2;
      const okA = centers.every((c) => Math.hypot(c.x - ax, c.z - az) > Math.max(c.w, c.d) / 2 + 1.6);
      const okB = centers.every((c) => Math.hypot(c.x - bx, c.z - bz) > Math.max(c.w, c.d) / 2 + 1.6);
      const okBump = bumpers.every(
        (b) => Math.hypot(b.x - ax, b.z - az) > 2.4 && Math.hypot(b.x - bx, b.z - bz) > 2.4
      );
      if (okA && okB && okBump) {
        portal = { ax, az, bx, bz };
        break;
      }
    }
  }

  return { obstacles, bumpers, portal };
}

/** Ease avec léger dépassement (apparition des textes flottants) */
function easeOutBack(p: number): number {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * (p - 1) ** 3 + c1 * (p - 1) ** 2;
}

export default function GameCanvas({ level, ball, onExit, onResult }: Props) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [phase, setPhase] = useState<Phase>('countdown');
  const [count, setCount] = useState(3);
  const [snd, setSnd] = useState(true);
  const [fx, setFx] = useState(true);
  const [hud, setHud] = useState<HudState>({
    timeLabel: '', timeFrac: 1, timeDanger: false,
    progressMain: '', progressSub: '', restFrac: 0,
    speed: 0, height: 0, energy: 0, fps: 60,
  });

  const onResultRef = useRef(onResult);
  onResultRef.current = onResult;

  const controlsRef = useRef<{
    togglePause: () => void;
    restart: () => void;
    setSnd: (v: boolean) => void;
    setFx: (v: boolean) => void;
  } | null>(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    /* ================= THÈME DU MONDE ================= */
    const CH = CHAPTERS[Math.min(CHAPTERS.length, Math.max(1, level.chapter)) - 1] ?? CHAPTERS[0];
    const ACCENT = new THREE.Color(CH.accent);
    const ACCENT2 = new THREE.Color(CH.accent2);
    const SKY_TOP = new THREE.Color(CH.skyTop);
    const SKY_BOT = new THREE.Color(CH.skyBot);
    const layout = genLayout(level);

    /* ================= RENDERER / SCÈNE ================= */
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    mount.appendChild(renderer.domElement);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.touchAction = 'none';
    renderer.domElement.style.cursor = 'crosshair';

    const scene = new THREE.Scene();
    scene.background = SKY_BOT.clone().multiplyScalar(0.85);
    scene.fog = new THREE.Fog(SKY_BOT.clone().multiplyScalar(0.6), 25, 55);

    const camera = new THREE.PerspectiveCamera(40, mount.clientWidth / mount.clientHeight, 0.1, 200);
    camera.position.set(0, 22, 14);
    camera.lookAt(0, 0, 0);

    // Environnement pour les reflets (métal / clearcoat)
    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;

    /* ================= CIEL ================= */
    const skyGeo = new THREE.SphereGeometry(80, 24, 16);
    const skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide, depthWrite: false, fog: false,
      uniforms: { cTop: { value: SKY_TOP }, cBot: { value: SKY_BOT } },
      vertexShader: 'varying vec3 vP; void main(){ vP=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader: 'varying vec3 vP; uniform vec3 cTop; uniform vec3 cBot;' +
        'void main(){ float h=clamp(normalize(vP).y*0.5+0.5,0.0,1.0);' +
        'vec3 c=mix(cBot,cTop,pow(h,0.8)); gl_FragColor=vec4(c,1.0); }',
    });
    scene.add(new THREE.Mesh(skyGeo, skyMat));

    // Étoiles statiques : coquille sphérique lointaine en points additifs
    const STARS_N = 140;
    const starPos = new Float32Array(STARS_N * 3);
    for (let i = 0; i < STARS_N; i++) {
      const r = 70 + Math.random() * 8;
      const th = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);
      starPos[i * 3] = r * Math.sin(phi) * Math.cos(th);
      starPos[i * 3 + 1] = r * Math.cos(phi);
      starPos[i * 3 + 2] = r * Math.sin(phi) * Math.sin(th);
    }
    const starGeo = new THREE.BufferGeometry();
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
    const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({
      color: 0xfff4e0, size: 0.35, sizeAttenuation: true, transparent: true, opacity: 0.55,
      blending: THREE.AdditiveBlending, depthWrite: false, fog: false,
    }));
    scene.add(stars);

    // Nébuleuse : halo doux additif teinté accent du monde
    const nebCanvas = document.createElement('canvas');
    nebCanvas.width = nebCanvas.height = 256;
    const nbg = nebCanvas.getContext('2d')!;
    const nebGrad = nbg.createRadialGradient(128, 128, 8, 128, 128, 126);
    nebGrad.addColorStop(0, 'rgba(255,255,255,0.9)');
    nebGrad.addColorStop(0.45, 'rgba(255,255,255,0.26)');
    nebGrad.addColorStop(1, 'rgba(255,255,255,0)');
    nbg.fillStyle = nebGrad;
    nbg.fillRect(0, 0, 256, 256);
    const nebTex = new THREE.CanvasTexture(nebCanvas);
    const nebMat = new THREE.SpriteMaterial({
      map: nebTex, color: ACCENT, transparent: true, opacity: 0.16,
      blending: THREE.AdditiveBlending, depthWrite: false, fog: false,
    });
    const nebula = new THREE.Sprite(nebMat);
    nebula.position.set(-26, 16, -58);
    nebula.scale.set(64, 64, 1);
    scene.add(nebula);
    const nebula2 = new THREE.Sprite(nebMat.clone());
    (nebula2.material as THREE.SpriteMaterial).color = ACCENT2.clone();
    (nebula2.material as THREE.SpriteMaterial).opacity = 0.12;
    nebula2.position.set(30, 10, -52);
    nebula2.scale.set(52, 52, 1);
    scene.add(nebula2);

    /* ================= LUMIÈRES ================= */
    scene.add(new THREE.HemisphereLight(0xffffff, 0x444444, 0.7));
    const key = new THREE.DirectionalLight(0xfff1dc, 1.4);
    key.position.set(8, 18, 8);
    key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048);
    key.shadow.camera.left = -16; key.shadow.camera.right = 16;
    key.shadow.camera.top = 16; key.shadow.camera.bottom = -16;
    key.shadow.camera.near = 1; key.shadow.camera.far = 50;
    key.shadow.bias = -0.0005;
    scene.add(key);
    const fill = new THREE.DirectionalLight(0xdfe8ff, 0.35);
    fill.position.set(-8, 6, -8);
    scene.add(fill);

    // Lumières d'ambiance orbitales (thème du monde)
    const orbitA = new THREE.PointLight(CH.accent, 30, 28, 2);
    const orbitB = new THREE.PointLight(CH.accent2, 22, 28, 2);
    scene.add(orbitA, orbitB);

    const flashLights: Array<{ l: THREE.PointLight; i: number }> = [];
    for (let fi = 0; fi < 2; fi++) {
      const fl = new THREE.PointLight(0xff6a5e, 0, 14, 2);
      scene.add(fl);
      flashLights.push({ l: fl, i: 0 });
    }

    /* ================= CARTE ================= */
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(ARENA * 2, ARENA * 2),
      new THREE.MeshStandardMaterial({
        color: new THREE.Color(0x221e19).lerp(ACCENT, 0.08),
        roughness: 0.55, metalness: 0.35,
      })
    );
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);

    // Overlay shader : grille lumineuse + anneaux pulsants + emblème central
    const floorUniforms = {
      uAccent: { value: ACCENT },
      uAccent2: { value: ACCENT2 },
      uTime: { value: 0 },
    };
    const overlayMat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      uniforms: floorUniforms,
      vertexShader:
        'varying vec2 vXY;' +
        'void main(){ vec4 wp=modelMatrix*vec4(position,1.0); vXY=wp.xz;' +
        'gl_Position=projectionMatrix*viewMatrix*wp; }',
      fragmentShader:
        'uniform vec3 uAccent; uniform vec3 uAccent2; uniform float uTime; varying vec2 vXY;' +
        'void main(){' +
        '  float d=length(vXY);' +
        '  vec2 gp=vXY*0.5;' +
        '  vec2 grid=abs(fract(gp-0.5)-0.5)/fwidth(gp);' +
        '  float line=min(grid.x,grid.y);' +
        '  float g=1.0-min(line,1.0);' +
        '  float ring=exp(-abs(fract(d*0.16-uTime*0.16)-0.5)*9.0)*0.32;' +
        '  float e1=exp(-abs(d-2.7)*7.0)*0.5;' +
        '  float e2=exp(-abs(d-4.15)*9.0)*0.3;' +
        '  float halo=exp(-d*0.42)*0.26;' +
        '  float edge=1.0-smoothstep(9.6,11.9,d);' +
        '  float a=(g*0.09+ring+e1+e2+halo)*edge;' +
        '  vec3 col=uAccent*a+uAccent2*a*0.3;' +
        '  gl_FragColor=vec4(col,1.0);' +
        '}',
    });
    const floorOverlay = new THREE.Mesh(new THREE.PlaneGeometry(ARENA * 2, ARENA * 2), overlayMat);
    floorOverlay.rotation.x = -Math.PI / 2;
    floorOverlay.position.y = 0.03;
    floorOverlay.renderOrder = 2;
    scene.add(floorOverlay);

    const wallMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(0x2e2925).lerp(ACCENT, 0.1), roughness: 0.7, metalness: 0.25,
    });
    const wallH = 3.5;
    const wallDefs: Array<{ pos: [number, number, number]; size: [number, number, number] }> = [
      { pos: [0, wallH / 2, -ARENA], size: [ARENA * 2, wallH, 0.5] },
      { pos: [0, wallH / 2, ARENA], size: [ARENA * 2, wallH, 0.5] },
      { pos: [-ARENA, wallH / 2, 0], size: [0.5, wallH, ARENA * 2] },
      { pos: [ARENA, wallH / 2, 0], size: [0.5, wallH, ARENA * 2] },
    ];
    for (const w of wallDefs) {
      const m = new THREE.Mesh(new THREE.BoxGeometry(...w.size), wallMat);
      m.position.set(...w.pos);
      m.castShadow = true;
      m.receiveShadow = true;
      scene.add(m);
    }

    // Colonnes lumineuses d'accent aux 4 coins
    const postGeo = new THREE.BoxGeometry(0.12, wallH + 0.06, 0.12);
    const postMat = new THREE.MeshBasicMaterial({ color: ACCENT, transparent: true, opacity: 0.7 });
    for (const sx of [-1, 1]) {
      for (const sz of [-1, 1]) {
        const post = new THREE.Mesh(postGeo, postMat);
        post.position.set(sx * ARENA, wallH / 2 + 0.03, sz * ARENA);
        scene.add(post);
      }
    }

    // Néons : plinthe émissive au pied des 4 murs + liseré au sommet
    const stripIn = ARENA - 0.25 - 0.06;
    const stripGeoNS = new THREE.BoxGeometry(ARENA * 2, 0.06, 0.12);
    const stripGeoEW = new THREE.BoxGeometry(0.12, 0.06, ARENA * 2);
    const stripBaseMat = new THREE.MeshBasicMaterial({ color: ACCENT, transparent: true, opacity: 0.85 });
    const stripTopMat = new THREE.MeshBasicMaterial({ color: ACCENT, transparent: true, opacity: 0.35 });
    for (const s of [-1, 1]) {
      const nsBase = new THREE.Mesh(stripGeoNS, stripBaseMat);
      nsBase.position.set(0, 0.03, s * stripIn);
      scene.add(nsBase);
      const nsTop = new THREE.Mesh(stripGeoNS, stripTopMat);
      nsTop.position.set(0, wallH, s * stripIn);
      scene.add(nsTop);
      const ewBase = new THREE.Mesh(stripGeoEW, stripBaseMat);
      ewBase.position.set(s * stripIn, 0.03, 0);
      scene.add(ewBase);
      const ewTop = new THREE.Mesh(stripGeoEW, stripTopMat);
      ewTop.position.set(s * stripIn, wallH, 0);
      scene.add(ewTop);
    }

    /* ================= OBSTACLES (layout seedé) ================= */
    interface ObGroup { g: THREE.Group; spec: ObstacleSpec; cx: number; cz: number }
    const obsGroups: ObGroup[] = [];
    const obsMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(0x4a4038).lerp(ACCENT, 0.18), roughness: 0.45, metalness: 0.4,
    });
    const obsEdgeMat = new THREE.LineBasicMaterial({ color: ACCENT, transparent: true, opacity: 0.9 });
    const obsCapMat = new THREE.MeshBasicMaterial({ color: ACCENT2, transparent: true, opacity: 0.5 });
    for (const o of layout.obstacles) {
      const g = new THREE.Group();
      const body = new THREE.Mesh(new THREE.BoxGeometry(o.w, o.h, o.d), obsMat);
      body.position.y = o.h / 2;
      body.castShadow = true;
      body.receiveShadow = true;
      const edges = new THREE.LineSegments(new THREE.EdgesGeometry(body.geometry), obsEdgeMat);
      edges.position.y = o.h / 2;
      const cap = new THREE.Mesh(new THREE.BoxGeometry(o.w + 0.04, 0.04, o.d + 0.04), obsCapMat);
      cap.position.y = o.h + 0.02;
      g.add(body, edges, cap);
      g.position.set(o.x, 0, o.z);
      scene.add(g);
      obsGroups.push({ g, spec: o, cx: o.x, cz: o.z });
    }

    /* ================= BUMPERS (flipper) ================= */
    interface BumperObj { group: THREE.Group; ring: THREE.Mesh; x: number; z: number; r: number; h: number; pop: number; phase: number }
    const bumpers: BumperObj[] = [];
    const bumperMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(0x2a2622).lerp(ACCENT2, 0.22),
      roughness: 0.35, metalness: 0.6, emissive: ACCENT2, emissiveIntensity: 0.18,
    });
    for (const b of layout.bumpers) {
      const group = new THREE.Group();
      const base = new THREE.Mesh(new THREE.CylinderGeometry(BUMPER_R, BUMPER_R * 1.12, BUMPER_H, 28), bumperMat);
      base.position.y = BUMPER_H / 2;
      base.castShadow = true;
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(BUMPER_R * 0.82, 0.06, 10, 40),
        new THREE.MeshBasicMaterial({ color: ACCENT2, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false })
      );
      ring.rotation.x = Math.PI / 2;
      ring.position.y = BUMPER_H + 0.05;
      const disc = new THREE.Mesh(
        new THREE.CircleGeometry(BUMPER_R * 0.6, 28),
        new THREE.MeshBasicMaterial({ color: ACCENT2, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false })
      );
      disc.rotation.x = -Math.PI / 2;
      disc.position.y = 0.02;
      group.add(base, ring, disc);
      group.position.set(b.x, 0, b.z);
      scene.add(group);
      bumpers.push({ group, ring, x: b.x, z: b.z, r: BUMPER_R, h: BUMPER_H, pop: 0, phase: Math.random() * Math.PI * 2 });
    }

    /* ================= PORTAIL ================= */
    interface PortalPair { a: THREE.Group; b: THREE.Group; cd: number }
    let portalPair: PortalPair | null = null;
    function buildPortal(x: number, z: number, color: THREE.Color): THREE.Group {
      const group = new THREE.Group();
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(1.25, 0.07, 12, 44),
        new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.75, blending: THREE.AdditiveBlending, depthWrite: false })
      );
      ring.rotation.x = Math.PI / 2;
      const disc = new THREE.Mesh(
        new THREE.CircleGeometry(1.1, 36),
        new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.16, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })
      );
      const light = new THREE.PointLight(color.getHex(), 8, 8, 2);
      light.position.y = 0.4;
      group.add(ring, disc, light);
      group.position.set(x, 1.15, z);
      scene.add(group);
      return group;
    }
    if (layout.portal) {
      portalPair = {
        a: buildPortal(layout.portal.ax, layout.portal.az, ACCENT),
        b: buildPortal(layout.portal.bx, layout.portal.bz, ACCENT2),
        cd: 0,
      };
    }

    // Poussière ambiante : volume de points flottants (animé en bloc)
    const DUST_N = 110;
    const dustPos = new Float32Array(DUST_N * 3);
    for (let i = 0; i < DUST_N; i++) {
      dustPos[i * 3] = (Math.random() * 2 - 1) * ARENA;
      dustPos[i * 3 + 1] = Math.random() * 7;
      dustPos[i * 3 + 2] = (Math.random() * 2 - 1) * ARENA;
    }
    const dustGeo = new THREE.BufferGeometry();
    dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPos, 3));
    const dust = new THREE.Points(dustGeo, new THREE.PointsMaterial({
      size: 0.09, color: new THREE.Color(0xd8c8a8).lerp(ACCENT, 0.4), transparent: true, opacity: 0.35, depthWrite: false,
    }));
    dust.frustumCulled = false;
    scene.add(dust);

    /* ================= BALLON ================= */
    const GRAV_BALL = GRAV * ball.gravityFactor;
    const REST = ball.restitution;

    const deform = new THREE.Group();
    scene.add(deform);

    const ballOpacity = ball.opacity ?? 1;
    const ballMat = new THREE.MeshPhysicalMaterial({
      color: ball.color,
      roughness: ball.roughness,
      metalness: ball.metalness,
      clearcoat: ball.clearcoat,
      clearcoatRoughness: ball.clearcoatRoughness,
      emissive: new THREE.Color(ball.emissive),
      emissiveIntensity: ball.emissiveIntensity,
      envMapIntensity: 1.15,
      transparent: ballOpacity < 1,
      opacity: ballOpacity,
    });
    const ballMesh = new THREE.Mesh(new THREE.SphereGeometry(R, 48, 32), ballMat);
    ballMesh.castShadow = true;
    deform.add(ballMesh);

    // Texture (fichier ou procédurale)
    (async () => {
      try {
        let tex: THREE.Texture | null = null;
        if (ball.procTex) {
          tex = new THREE.CanvasTexture(buildBallTexture(ball.procTex));
        } else if (ball.texture) {
          tex = await new THREE.TextureLoader().loadAsync(ball.texture);
        }
        if (tex) {
          tex.colorSpace = THREE.SRGBColorSpace;
          tex.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
          ballMat.map = tex;
          ballMat.color.set(0xffffff);
          ballMat.needsUpdate = true;
        }
      } catch {
        /* texture manquante : couleur unie */
      }
    })();

    // Lueur
    const glowUniforms = {
      uPower: { value: ball.glowPower },
      uColor: { value: new THREE.Color(ball.glowColor) },
    };
    const glowMat = new THREE.ShaderMaterial({
      transparent: true, blending: THREE.AdditiveBlending, depthWrite: false,
      uniforms: glowUniforms,
      vertexShader:
        'varying float vF; void main(){' +
        'vec3 n=normalize(normalMatrix*normal);' +
        'vec4 mv=modelViewMatrix*vec4(position,1.0);' +
        'vec3 vd=normalize(-mv.xyz);' +
        'vF=pow(1.0-abs(dot(n,vd)),2.2);' +
        'gl_Position=projectionMatrix*mv; }',
      fragmentShader:
        'uniform float uPower; uniform vec3 uColor; varying float vF;' +
        'void main(){ gl_FragColor=vec4(uColor, vF*uPower); }',
    });
    deform.add(new THREE.Mesh(new THREE.SphereGeometry(R * 1.16, 32, 24), glowMat));

    // Lumière interne (météore / néon)
    const innerLight = new THREE.PointLight(ball.glowColor, ball.fireParticles ? 14 : (ball.glowPower > 1 ? 8 : 0), 11, 2);
    deform.add(innerLight);

    // Ombre de contact
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = shadowCanvas.height = 128;
    const sg = shadowCanvas.getContext('2d')!;
    const rg = sg.createRadialGradient(64, 64, 4, 64, 64, 62);
    rg.addColorStop(0, 'rgba(0,0,0,0.85)');
    rg.addColorStop(1, 'rgba(0,0,0,0)');
    sg.fillStyle = rg;
    sg.fillRect(0, 0, 128, 128);
    const contactShadow = new THREE.Mesh(
      new THREE.PlaneGeometry(1, 1),
      new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(shadowCanvas), transparent: true, depthWrite: false })
    );
    contactShadow.rotation.x = -Math.PI / 2;
    contactShadow.position.y = 0.012;
    contactShadow.renderOrder = 1;
    scene.add(contactShadow);

    // Anneau de cible (souris)
    const targetRing = new THREE.Mesh(
      new THREE.RingGeometry(0.4, 0.5, 32),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.5, side: THREE.DoubleSide, depthWrite: false })
    );
    targetRing.rotation.x = -Math.PI / 2;
    targetRing.position.y = 0.02;
    scene.add(targetRing);

    /* ================= TEXTES FLOTTANTS (pool fixe) ================= */
    const TEXT_POOL = 10;
    const textPool: Array<{ sprite: THREE.Sprite; ctx: CanvasRenderingContext2D; tex: THREE.CanvasTexture; life: number }> = [];
    let textCursor = 0;
    const GO_POS = new THREE.Vector3(0, 2.5, 0);
    for (let i = 0; i < TEXT_POOL; i++) {
      const c = document.createElement('canvas');
      c.width = 256;
      c.height = 128;
      const c2d = c.getContext('2d')!;
      const tex = new THREE.CanvasTexture(c);
      tex.colorSpace = THREE.SRGBColorSpace;
      const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, fog: false }));
      sp.scale.set(2.4, 1.2, 1);
      sp.visible = false;
      scene.add(sp);
      textPool.push({ sprite: sp, ctx: c2d, tex, life: 0 });
    }
    function popText(text: string, color: string, worldPos: THREE.Vector3) {
      const item = textPool[textCursor];
      textCursor = (textCursor + 1) % TEXT_POOL;
      item.ctx.clearRect(0, 0, 256, 128);
      item.ctx.font = 'italic bold 72px system-ui, sans-serif';
      item.ctx.textAlign = 'center';
      item.ctx.textBaseline = 'middle';
      item.ctx.lineWidth = 12;
      item.ctx.strokeStyle = 'rgba(18,14,10,0.92)';
      item.ctx.strokeText(text, 128, 68);
      item.ctx.fillStyle = color;
      item.ctx.fillText(text, 128, 68);
      item.tex.needsUpdate = true;
      item.sprite.position.copy(worldPos);
      item.sprite.material.opacity = 1;
      item.life = 0;
      item.sprite.visible = true;
    }

    /* ================= PARTICULES ================= */
    const P_MAX = 220;
    const pGeo = new THREE.BufferGeometry();
    const pPos = new Float32Array(P_MAX * 3);
    const pVel = new Float32Array(P_MAX * 3);
    const pAge = new Float32Array(P_MAX);
    const pLife = new Float32Array(P_MAX);
    const pSize = new Float32Array(P_MAX);
    const pAlpha = new Float32Array(P_MAX);
    const pShade = new Float32Array(P_MAX);
    const pBase = new Float32Array(P_MAX);
    for (let i = 0; i < P_MAX; i++) { pAge[i] = 1; pLife[i] = 1; pPos[i * 3 + 1] = -50; }
    pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
    pGeo.setAttribute('aAlpha', new THREE.BufferAttribute(pAlpha, 1));
    pGeo.setAttribute('aSize', new THREE.BufferAttribute(pSize, 1));
    pGeo.setAttribute('aShade', new THREE.BufferAttribute(pShade, 1));
    const colNeutral = new THREE.Color(0.70, 0.63, 0.52);
    const colBall = new THREE.Color(ball.glowColor);
    const pMat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false,
      uniforms: { uC0: { value: colNeutral }, uC1: { value: colBall } },
      vertexShader:
        'attribute float aAlpha; attribute float aSize; attribute float aShade;' +
        'varying float vA; varying float vS;' +
        'void main(){ vA=aAlpha; vS=aShade;' +
        'vec4 mv=modelViewMatrix*vec4(position,1.0);' +
        'gl_PointSize=aSize*(150.0/-mv.z);' +
        'gl_Position=projectionMatrix*mv; }',
      fragmentShader:
        'uniform vec3 uC0; uniform vec3 uC1; varying float vA; varying float vS;' +
        'void main(){ float d=length(gl_PointCoord-0.5);' +
        'float m=smoothstep(0.5,0.1,d); float a=m*vA;' +
        'if(a<0.012) discard;' +
        'vec3 col=mix(uC0,uC1,vS);' +
        'gl_FragColor=vec4(col,a); }',
    });
    const points = new THREE.Points(pGeo, pMat);
    points.frustumCulled = false;
    scene.add(points);
    let pCursor = 0;

    const fxOn = { v: true };

    function spawnBurst(pos: THREE.Vector3, n: THREE.Vector3, power: number, shadeOverride = -1) {
      if (!fxOn.v) return;
      const count = Math.min(34, 5 + (power * 30 | 0));
      for (let i = 0; i < count; i++) {
        const idx = pCursor; pCursor = (pCursor + 1) % P_MAX;
        const a = Math.random() * Math.PI * 2;
        const up = Math.random();
        const sp = (1.0 + Math.random() * 3.0) * (0.6 + power);
        pPos[idx * 3] = pos.x + n.x * 0.05;
        pPos[idx * 3 + 1] = pos.y + n.y * 0.05;
        pPos[idx * 3 + 2] = pos.z + n.z * 0.05;
        pVel[idx * 3] = (Math.cos(a) * sp + n.x * sp * 1.4) * 0.6;
        pVel[idx * 3 + 1] = (up * sp * 1.5 + n.y * sp * 1.4) * 0.6;
        pVel[idx * 3 + 2] = (Math.sin(a) * sp + n.z * sp * 1.4) * 0.6;
        pAge[idx] = 0;
        pLife[idx] = 0.35 + Math.random() * 0.45;
        pSize[idx] = 0.12 + Math.random() * 0.18 + power * 0.1;
        pBase[idx] = 0.5 + Math.random() * 0.5;
        pShade[idx] = shadeOverride >= 0 ? shadeOverride : (Math.random() < ball.particleShade ? 1 : 0);
      }
    }
    function spawnTrail() {
      const idx = pCursor; pCursor = (pCursor + 1) % P_MAX;
      pPos[idx * 3] = ballState.p.x + (Math.random() - 0.5) * 0.2;
      pPos[idx * 3 + 1] = ballState.p.y + (Math.random() - 0.5) * 0.2;
      pPos[idx * 3 + 2] = ballState.p.z + (Math.random() - 0.5) * 0.2;
      pVel[idx * 3] = (Math.random() - 0.5) * 0.6;
      pVel[idx * 3 + 1] = ball.fireParticles ? 1.2 + Math.random() * 1.4 : 0.3;
      pVel[idx * 3 + 2] = (Math.random() - 0.5) * 0.6;
      pAge[idx] = 0;
      pLife[idx] = 0.3 + Math.random() * 0.35;
      pSize[idx] = 0.14 + Math.random() * 0.16;
      pBase[idx] = 0.7;
      pShade[idx] = ball.fireParticles ? 1 : ball.particleShade;
    }

    /* ================= AUDIO ================= */
    const audio = { ctx: null as AudioContext | null, master: null as GainNode | null, noise: null as AudioBuffer | null, on: true };
    function audioInit() {
      if (audio.ctx) { if (audio.ctx.state === 'suspended') void audio.ctx.resume(); return; }
      try {
        const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        audio.ctx = new AC();
        audio.master = audio.ctx.createGain();
        audio.master.gain.value = 0.85;
        audio.master.connect(audio.ctx.destination);
        audio.noise = audio.ctx.createBuffer(1, audio.ctx.sampleRate, audio.ctx.sampleRate);
        const d = audio.noise.getChannelData(0);
        for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      } catch { audio.ctx = null; }
    }
    function env(g: GainNode, t0: number, a: number, peak: number, dec: number) {
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.linearRampToValueAtTime(peak, t0 + a);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + a + dec);
    }
    function sndBounce(pw: number, isWall: boolean) {
      if (!audio.ctx || !audio.master || !audio.on || !audio.noise) return;
      const t = audio.ctx.currentTime;
      const o = audio.ctx.createOscillator(), g = audio.ctx.createGain();
      o.type = 'sine';
      const f0 = (isWall ? 280 : 160) + pw * 140;
      o.frequency.setValueAtTime(f0, t);
      o.frequency.exponentialRampToValueAtTime(f0 * 0.35, t + 0.16);
      env(g, t, 0.004, 0.16 + pw * 0.6, 0.16 + pw * 0.12);
      o.connect(g); g.connect(audio.master); o.start(t); o.stop(t + 0.4);
      const n = audio.ctx.createBufferSource(), ng = audio.ctx.createGain(), nf = audio.ctx.createBiquadFilter();
      n.buffer = audio.noise; nf.type = 'lowpass'; nf.frequency.value = 500 + pw * 1200;
      env(ng, t, 0.002, 0.12 + pw * 0.4, 0.10);
      n.connect(nf); nf.connect(ng); ng.connect(audio.master); n.start(t); n.stop(t + 0.2);
    }
    function sndBoost() {
      if (!audio.ctx || !audio.master || !audio.on || !audio.noise) return;
      const t = audio.ctx.currentTime;
      const n = audio.ctx.createBufferSource(), g = audio.ctx.createGain(), f = audio.ctx.createBiquadFilter();
      n.buffer = audio.noise; f.type = 'bandpass'; f.Q.value = 1.2;
      f.frequency.setValueAtTime(400, t);
      f.frequency.exponentialRampToValueAtTime(2000, t + 0.25);
      env(g, t, 0.02, 0.15, 0.25);
      n.connect(f); f.connect(g); g.connect(audio.master); n.start(t); n.stop(t + 0.35);
    }
    function sndBumper() {
      if (!audio.ctx || !audio.master || !audio.on) return;
      const t = audio.ctx.currentTime;
      const o = audio.ctx.createOscillator(), g = audio.ctx.createGain();
      o.type = 'square';
      o.frequency.setValueAtTime(220, t);
      o.frequency.exponentialRampToValueAtTime(85, t + 0.12);
      env(g, t, 0.003, 0.2, 0.14);
      o.connect(g); g.connect(audio.master); o.start(t); o.stop(t + 0.25);
    }
    function sndPortal() {
      if (!audio.ctx || !audio.master || !audio.on) return;
      const t = audio.ctx.currentTime;
      const o = audio.ctx.createOscillator(), g = audio.ctx.createGain();
      o.type = 'sine';
      o.frequency.setValueAtTime(300, t);
      o.frequency.exponentialRampToValueAtTime(1200, t + 0.16);
      o.frequency.exponentialRampToValueAtTime(420, t + 0.34);
      env(g, t, 0.01, 0.16, 0.34);
      o.connect(g); g.connect(audio.master); o.start(t); o.stop(t + 0.45);
    }
    function sndCollect() {
      if (!audio.ctx || !audio.master || !audio.on) return;
      const t = audio.ctx.currentTime;
      [660, 990].forEach((freq, i) => {
        const o = audio.ctx!.createOscillator(), g = audio.ctx!.createGain();
        o.type = 'triangle'; o.frequency.value = freq;
        env(g, t + i * 0.07, 0.004, 0.14, 0.12);
        o.connect(g); g.connect(audio.master!); o.start(t + i * 0.07); o.stop(t + i * 0.07 + 0.2);
      });
    }
    function sndWin() {
      if (!audio.ctx || !audio.master || !audio.on) return;
      const t = audio.ctx.currentTime;
      [523, 659, 784, 1047].forEach((freq, i) => {
        const o = audio.ctx!.createOscillator(), g = audio.ctx!.createGain();
        o.type = 'triangle'; o.frequency.value = freq;
        env(g, t + i * 0.11, 0.01, 0.16, 0.28);
        o.connect(g); g.connect(audio.master!); o.start(t + i * 0.11); o.stop(t + i * 0.11 + 0.45);
      });
    }
    function sndFail() {
      if (!audio.ctx || !audio.master || !audio.on) return;
      const t = audio.ctx.currentTime;
      const o = audio.ctx.createOscillator(), g = audio.ctx.createGain();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(220, t);
      o.frequency.exponentialRampToValueAtTime(70, t + 0.5);
      env(g, t, 0.01, 0.12, 0.5);
      o.connect(g); g.connect(audio.master); o.start(t); o.stop(t + 0.6);
    }

    crazyGames.setMuteHandler((muted) => {
      if (audio.master) audio.master.gain.value = muted ? 0 : 0.85;
    });

    /* ================= ÉTAT DE JEU ================= */
    const ballState = {
      p: new THREE.Vector3(0, 5, 0),
      v: new THREE.Vector3(),
      squash: 0,
      squashN: new THREE.Vector3(0, 1, 0),
    };
    const mouseTarget = new THREE.Vector3(0, R, 0);
    const phaseRef = { v: 'countdown' as Phase };
    const timeRef = { t: 0 };                 // temps de jeu écoulé (playing)
    const countRef = { t: 3.9, shown: 4 };    // compte à rebours
    const challengeRef = {
      collected: 0,
      bounces: 0,
      chain: 0,
      bestChain: 0,
      lastImpact: -99,
      restTimer: 0,
      finished: false,
      resultSent: false,
      elapsed: 0,
    };
    let targets: TargetObj[] = [];
    const targetGroup = new THREE.Group();
    scene.add(targetGroup);

    function spawnTargets() {
      for (const t of targets) targetGroup.remove(t.group);
      targets = [];
      if (level.type !== 'collect') return;
      const total = level.targets ?? 5;
      const elevated = level.elevated ?? 0;
      const specs: TargetSpec[] = [];
      const coreGeo = new THREE.SphereGeometry(0.4, 20, 14);
      const haloGeo = new THREE.TorusGeometry(0.66, 0.05, 10, 36);
      const coreMat = new THREE.MeshBasicMaterial({ color: 0xffd27a });
      const haloMat = new THREE.MeshBasicMaterial({ color: 0xffb84d, transparent: true, opacity: 0.9 });
      for (let i = 0; i < total; i++) {
        let pos = new THREE.Vector3();
        for (let tries = 0; tries < 40; tries++) {
          pos = new THREE.Vector3(
            (Math.random() * 2 - 1) * (ARENA - 2.5),
            i < elevated ? 1.7 + Math.random() * 1.6 : 0.85,
            (Math.random() * 2 - 1) * (ARENA - 2.5)
          );
          let ok = pos.length() > 2.2;
          for (const s of specs) if (ok && s.pos.distanceTo(pos) < 2.8) ok = false;
          for (const ob of obsGroups) {
            const sp = ob.spec;
            const ax = sp.axis === 'x' ? sp.amp : 0;
            const az = sp.axis === 'z' ? sp.amp : 0;
            if (ok && Math.abs(pos.x - sp.x) < sp.w / 2 + 1.2 + ax && Math.abs(pos.z - sp.z) < sp.d / 2 + 1.2 + az) ok = false;
          }
          for (const b of bumpers) {
            if (ok && Math.hypot(pos.x - b.x, pos.z - b.z) < b.r + 1.4) ok = false;
          }
          if (ok && layout.portal) {
            const pa = Math.hypot(pos.x - layout.portal.ax, pos.z - layout.portal.az);
            const pb = Math.hypot(pos.x - layout.portal.bx, pos.z - layout.portal.bz);
            if (pa < 2.2 || pb < 2.2) ok = false;
          }
          if (ok) break;
        }
        specs.push({ pos });
      }
      for (const s of specs) {
        const group = new THREE.Group();
        const core = new THREE.Mesh(coreGeo, coreMat);
        const halo = new THREE.Mesh(haloGeo, haloMat.clone());
        group.add(core, halo);
        group.position.copy(s.pos);
        targetGroup.add(group);
        targets.push({ group, halo, baseY: s.pos.y, phase: Math.random() * Math.PI * 2, dying: false, scale: 1, collected: false });
      }
    }
    spawnTargets();

    /* ================= IMPACTS / PHYSIQUE ================= */
    const UP = new THREE.Vector3(0, 1, 0);
    const tmpN = new THREE.Vector3();
    const squashQ = new THREE.Quaternion();
    const tmpQ = new THREE.Quaternion();
    const tmpV1 = new THREE.Vector3();
    const camTarget = new THREE.Vector3(0, 1, 0);

    let shake = 0;

    function impact(
      nx: number, ny: number, nz: number, speed: number,
      cx: number, cy: number, cz: number, isWall: boolean,
      flashColor?: number, soundFn?: (pw: number, isWall: boolean) => void
    ) {
      const pw = THREE.MathUtils.clamp((speed - 2) / 28, 0, 1);
      if (pw <= 0.02) return;
      ballState.squash = Math.max(ballState.squash, pw * 0.45);
      ballState.squashN.set(nx, ny, nz);
      spawnBurst(tmpV1.set(cx, cy, cz), tmpN.set(nx, ny, nz), pw);
      if (phaseRef.v === 'playing' && !challengeRef.finished) {
        challengeRef.bounces++;
        const t = challengeRef.elapsed;
        challengeRef.chain = t - challengeRef.lastImpact <= COMBO_WINDOW ? challengeRef.chain + 1 : 1;
        challengeRef.lastImpact = t;
        challengeRef.bestChain = Math.max(challengeRef.bestChain, challengeRef.chain);
        if (challengeRef.chain >= 5 && challengeRef.chain % 5 === 0) {
          popText(`CHAÎNE x${challengeRef.chain} !`, '#ff8a7d', tmpV1.set(ballState.p.x, ballState.p.y + 1, ballState.p.z));
        }
        if (level.type === 'combo' && challengeRef.chain >= (level.comboGoal ?? 999)) {
          finish(true);
        }
      }
      if (fxOn.v) {
        shake = Math.min(0.6, shake + pw * 0.2);
        const f = flashLights[0].i < flashLights[1].i ? flashLights[1] : flashLights[0];
        f.i = pw * 30;
        f.l.color.set(flashColor ?? 0xff6a5e);
        f.l.position.set(cx + nx * 0.7, cy + ny * 0.7, cz + nz * 0.7);
      }
      (soundFn ?? sndBounce)(pw, isWall);
    }

    function collidePlanes() {
      const p = ballState.p, v = ballState.v;
      if (p.y - R < 0) {
        p.y = R;
        if (v.y < 0) {
          const s = -v.y;
          if (s > 1.2) impact(UP.x, UP.y, UP.z, s, p.x, 0.02, p.z, false);
          v.y = s > 1.2 ? s * REST : 0;
          v.x *= 0.96; v.z *= 0.96;
        }
      }
    }

    function collideWalls() {
      const p = ballState.p, v = ballState.v;
      const lim = ARENA - R;
      if (p.x < -lim) { p.x = -lim; if (v.x < 0) { impact(1, 0, 0, -v.x, p.x, p.y, p.z, true); v.x = -v.x * REST; } }
      if (p.x > lim) { p.x = lim; if (v.x > 0) { impact(-1, 0, 0, v.x, p.x, p.y, p.z, true); v.x = -v.x * REST; } }
      if (p.z < -lim) { p.z = -lim; if (v.z < 0) { impact(0, 0, 1, -v.z, p.x, p.y, p.z, true); v.z = -v.z * REST; } }
      if (p.z > lim) { p.z = lim; if (v.z > 0) { impact(0, 0, -1, v.z, p.x, p.y, p.z, true); v.z = -v.z * REST; } }
    }

    function collideObstacles() {
      const p = ballState.p, v = ballState.v;
      for (const ob of obsGroups) {
        const s = ob.spec;
        const cx = THREE.MathUtils.clamp(p.x, ob.cx - s.w / 2, ob.cx + s.w / 2);
        const cy = THREE.MathUtils.clamp(p.y, 0, s.h);
        const cz = THREE.MathUtils.clamp(p.z, ob.cz - s.d / 2, ob.cz + s.d / 2);
        const dx = p.x - cx, dy = p.y - cy, dz = p.z - cz;
        const d2 = dx * dx + dy * dy + dz * dz;
        if (d2 < R * R && d2 > 0) {
          const d = Math.sqrt(d2);
          const nx = dx / d, ny = dy / d, nz = dz / d;
          p.x += nx * (R - d);
          p.y += ny * (R - d);
          p.z += nz * (R - d);
          const vn = v.x * nx + v.y * ny + v.z * nz;
          if (vn < 0) {
            v.x -= (1 + REST) * vn * nx;
            v.y -= (1 + REST) * vn * ny;
            v.z -= (1 + REST) * vn * nz;
            impact(nx, ny, nz, -vn, cx, cy, cz, true);
          }
        }
      }
    }

    function collideBumpers() {
      const p = ballState.p, v = ballState.v;
      for (const b of bumpers) {
        const dx = p.x - b.x, dz = p.z - b.z;
        const d = Math.hypot(dx, dz);
        if (d < b.r + R && p.y < b.h + R * 0.6) {
          const nx = d > 0.0001 ? dx / d : 1;
          const nz = d > 0.0001 ? dz / d : 0;
          p.x = b.x + nx * (b.r + R);
          p.z = b.z + nz * (b.r + R);
          const vn = v.x * nx + v.z * nz;
          if (vn < 0) {
            v.x -= 2.1 * vn * nx;
            v.z -= 2.1 * vn * nz;
          }
          const out = v.x * nx + v.z * nz;
          const want = 15;
          if (out < want) {
            v.x += nx * (want - out);
            v.z += nz * (want - out);
          }
          const spd = v.length();
          impact(nx, 0, nz, Math.max(spd, 14), p.x, p.y, p.z, true, CH.accent2, sndBumper);
          b.pop = 1;
        }
      }
    }

    function checkPortals() {
      if (!portalPair || !layout.portal || portalPair.cd > 0) return;
      const p = ballState.p;
      const P = layout.portal;
      const pairs: Array<[number, number, number, number]> = [
        [P.ax, P.az, P.bx, P.bz],
        [P.bx, P.bz, P.ax, P.az],
      ];
      for (const [fx, fz, tx, tz] of pairs) {
        if (Math.hypot(p.x - fx, p.z - fz) < 1.05 && p.y > 0.25 && p.y < 2.4) {
          spawnBurst(tmpV1.set(fx, 1.2, fz), UP, 0.6, 1);
          p.x = tx;
          p.z = tz;
          p.y = Math.max(p.y, 1.5);
          spawnBurst(tmpV1.set(tx, 1.2, tz), UP, 0.6, 1);
          if (fxOn.v) {
            const f = flashLights[0].i < flashLights[1].i ? flashLights[1] : flashLights[0];
            f.i = 22;
            f.l.position.set(tx, 1.6, tz);
          }
          sndPortal();
          shake = Math.min(0.5, shake + 0.22);
          portalPair.cd = 0.9;
          break;
        }
      }
    }

    function physStep(dt: number) {
      // Attraction vers la souris
      const dx = mouseTarget.x - ballState.p.x;
      const dz = mouseTarget.z - ballState.p.z;
      const dist = Math.sqrt(dx * dx + dz * dz);
      if (dist > 0.1) {
        const force = Math.min(dist * 18.0, 45.0);
        ballState.v.x += (dx / dist) * force * dt;
        ballState.v.z += (dz / dist) * force * dt;
      }
      // Gravité
      ballState.v.y -= GRAV_BALL * dt;
      // Traînée
      const drag = 1 - 0.08 * dt;
      ballState.v.x *= drag; ballState.v.y *= drag; ballState.v.z *= drag;
      // Limite
      if (ballState.v.length() > MAX_V) ballState.v.setLength(MAX_V);
      // Intégration
      ballState.p.x += ballState.v.x * dt;
      ballState.p.y += ballState.v.y * dt;
      ballState.p.z += ballState.v.z * dt;
      // Collisions
      collidePlanes();
      collideWalls();
      collideObstacles();
      collideBumpers();
      checkPortals();
      // Roulement visuel
      if (ballState.p.y <= R + 0.05) {
        const speed = Math.sqrt(ballState.v.x * ballState.v.x + ballState.v.z * ballState.v.z);
        if (speed > 0.1) {
          const axis = tmpV1.set(-ballState.v.z, 0, ballState.v.x).normalize();
          tmpQ.setFromAxisAngle(axis, (speed * dt) / R);
          ballMesh.quaternion.premultiply(tmpQ);
        }
      }
      ballState.squash *= Math.exp(-12 * dt);
      if (ballState.squash < 0.001) ballState.squash = 0;
    }

    /* ================= DÉROULEMENT DU DÉFI ================= */

    function progressLabel(): string {
      if (level.type === 'collect') return `${challengeRef.collected}/${level.targets ?? 0} cibles`;
      if (level.type === 'combo') return `Meilleure chaîne : ${challengeRef.bestChain}`;
      return `Tenu : ${challengeRef.elapsed.toFixed(1)}s`;
    }

    function finish(success: boolean) {
      if (challengeRef.finished) return;
      challengeRef.finished = true;
      phaseRef.v = 'done';
      setPhase('done');
      crazyGames.gameplayStop();
      if (success) { crazyGames.happytime(); sndWin(); } else {
        sndFail();
        popText('ÉCHEC', '#ff6a5e', tmpV1.set(ballState.p.x, ballState.p.y + 1, ballState.p.z));
      }
      onResultRef.current({
        success,
        timeMs: Math.round(challengeRef.elapsed * 1000),
        progressLabel: progressLabel(),
        stats: {
          bounces: challengeRef.bounces,
          collected: challengeRef.collected,
          bestChain: challengeRef.bestChain,
          timeLeftSec: Math.max(0, Math.round((level.timeLimit - challengeRef.elapsed) * 10) / 10),
        },
      });
    }

    function updateChallenge(dt: number) {
      challengeRef.elapsed += dt;
      const lv = level;

      if (lv.type === 'collect') {
        const remaining = lv.timeLimit - challengeRef.elapsed;
        // Collecte
        for (const t of targets) {
          if (t.collected) continue;
          const d = t.group.position.distanceTo(ballState.p);
          if (d < R + 1.05) {
            t.collected = true;
            t.dying = true;
            challengeRef.collected++;
            spawnBurst(t.group.position, UP, 0.55, 1);
            sndCollect();
            popText('+5 XP', '#ffd27a', t.group.position);
            const cfl = flashLights[0].i < flashLights[1].i ? flashLights[1] : flashLights[0];
            cfl.i = 18;
            cfl.l.color.set(0xffd27a);
            cfl.l.position.copy(t.group.position);
            if (challengeRef.collected >= (lv.targets ?? 0)) { finish(true); return; }
          }
        }
        if (remaining <= 0) { finish(false); return; }
      } else if (lv.type === 'survival') {
        const onGround = ballState.p.y <= R + 0.06 && ballState.v.length() < 1.2;
        if (challengeRef.elapsed > 1.5 && onGround) challengeRef.restTimer += dt;
        else challengeRef.restTimer = Math.max(0, challengeRef.restTimer - dt * 2);
        if (challengeRef.restTimer >= (lv.restLimit ?? 2.5)) { finish(false); return; }
        if (challengeRef.elapsed >= lv.timeLimit) { finish(true); return; }
      } else {
        // combo
        const remaining = lv.timeLimit - challengeRef.elapsed;
        if (challengeRef.elapsed - challengeRef.lastImpact > COMBO_WINDOW) challengeRef.chain = 0;
        if (remaining <= 0) { finish(false); return; }
      }

      // Traînée continue (feu / néon)
      const speed = ballState.v.length();
      if ((ball.fireParticles || ball.glowPower > 1) && speed > 4) {
        if (Math.random() < (ball.fireParticles ? 0.85 : 0.45)) spawnTrail();
      }
    }

    /* ================= ENTRÉES ================= */
    const raycaster = new THREE.Raycaster();
    const ndc = new THREE.Vector2();
    const floorPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);

    function onPointerMove(e: PointerEvent) {
      const rect = renderer.domElement.getBoundingClientRect();
      ndc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      ndc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(ndc, camera);
      const hit = raycaster.ray.intersectPlane(floorPlane, tmpV1);
      if (hit) {
        mouseTarget.set(
          THREE.MathUtils.clamp(tmpV1.x, -ARENA + R, ARENA - R),
          R,
          THREE.MathUtils.clamp(tmpV1.z, -ARENA + R, ARENA - R)
        );
      }
    }
    function onPointerDown(e: PointerEvent) {
      audioInit();
      if (phaseRef.v !== 'playing') return;
      ballState.v.y = Math.min(ballState.v.y + 13, 20);
      ballState.v.x += (Math.random() - 0.5) * 5;
      ballState.v.z += (Math.random() - 0.5) * 5;
      sndBoost();
      spawnBurst(ballState.p, UP, 0.4);
      void e;
    }
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerdown', onPointerDown);

    /* ================= BOUCLE ================= */
    let lastT = performance.now();
    let acc = 0;
    let raf = 0;
    let fpsFrames = 0, fpsTime = 0, fpsEMA = 60;
    const hudRef = {
      timeLabel: '', timeFrac: 1, timeDanger: false,
      progressMain: '', progressSub: '', restFrac: 0,
      speed: 0, height: 0, energy: 0, fps: 60,
    };

    function loop(now: number) {
      raf = requestAnimationFrame(loop);
      let rawDt = (now - lastT) / 1000;
      lastT = now;
      if (rawDt > 0.1) rawDt = 0.1;
      if (rawDt <= 0) rawDt = 0.0001;

      fpsFrames++; fpsTime += rawDt;
      if (fpsTime >= 0.5) { fpsEMA += ((fpsFrames / fpsTime) - fpsEMA) * 0.4; fpsFrames = 0; fpsTime = 0; }

      const ph = phaseRef.v;
      const gt = now / 1000;

      // Obstacles mobiles : mise à jour des positions (avant la physique)
      for (const ob of obsGroups) {
        const s = ob.spec;
        if (s.axis === 'x') {
          ob.cx = s.x + Math.sin(gt * s.speed + s.phase) * s.amp;
          ob.g.position.x = ob.cx;
        } else if (s.axis === 'z') {
          ob.cz = s.z + Math.sin(gt * s.speed + s.phase) * s.amp;
          ob.g.position.z = ob.cz;
        }
      }

      if (ph === 'countdown') {
        countRef.t -= rawDt;
        const shown = Math.max(1, Math.ceil(countRef.t - 0.9));
        if (shown !== countRef.shown) { countRef.shown = shown; setCount(shown); }
        if (countRef.t <= 0.9) {
          phaseRef.v = 'playing';
          setPhase('playing');
          crazyGames.gameplayStart();
          popText('GO !', '#ffffff', GO_POS);
        }
        // Le ballon tombe doucement pendant le décompte
        acc += rawDt;
        while (acc >= FIXED_DT) { physStep(FIXED_DT); acc -= FIXED_DT; }
      } else if (ph === 'playing') {
        acc += rawDt;
        let steps = 0;
        while (acc >= FIXED_DT && steps < 10) { physStep(FIXED_DT); acc -= FIXED_DT; steps++; }
        updateChallenge(rawDt);
      }

      // Portail : recharge + pulsations
      if (portalPair) {
        portalPair.cd = Math.max(0, portalPair.cd - rawDt);
        const pulse = 0.55 + 0.25 * Math.sin(gt * 2.4);
        for (const side of [portalPair.a, portalPair.b]) {
          side.children[0].rotation.z = gt * 0.8;
          const ringMat = (side.children[0] as THREE.Mesh).material as THREE.MeshBasicMaterial;
          ringMat.opacity = pulse;
          const s = 1 + Math.sin(gt * 2.4) * 0.05;
          side.scale.set(s, 1, s);
        }
      }

      // Bumpers : pulsations + pop d'impact
      for (const b of bumpers) {
        b.pop *= Math.exp(-8 * rawDt);
        const sc = 1 + b.pop * 0.22;
        b.group.scale.setScalar(sc);
        (b.ring.material as THREE.MeshBasicMaterial).opacity = 0.55 + 0.4 * Math.abs(Math.sin(gt * 2.2 + b.phase)) + b.pop * 0.4;
      }

      // Lumières d'ambiance orbitales
      orbitA.position.set(Math.cos(gt * 0.25) * 9, 5.5, Math.sin(gt * 0.25) * 9);
      orbitB.position.set(Math.cos(gt * 0.25 + Math.PI) * 9, 3.5, Math.sin(gt * 0.25 + Math.PI) * 9);

      // Sol : temps du shader
      floorUniforms.uTime.value = gt;

      // Cibles : animation + disparition
      for (let i = targets.length - 1; i >= 0; i--) {
        const t = targets[i];
        if (t.dying) {
          t.scale -= rawDt * 5;
          if (t.scale <= 0) { targetGroup.remove(t.group); targets.splice(i, 1); continue; }
          t.group.scale.setScalar(t.scale);
        } else if (!t.collected) {
          t.group.position.y = t.baseY + Math.sin(gt * 2 + t.phase) * 0.12;
          t.halo.rotation.x = gt * 1.3 + t.phase;
          t.halo.rotation.y = gt * 0.7;
        }
      }

      // Poussière : dérive lente (rotation Y + flottement vertical)
      dust.rotation.y = gt * 0.03;
      dust.position.y = Math.sin(gt * 0.4) * 0.15;

      // Textes flottants : montée, overshoot d'échelle puis fondu
      for (const ti of textPool) {
        if (!ti.sprite.visible) continue;
        ti.life += rawDt;
        if (ti.life >= 1.1) { ti.sprite.visible = false; continue; }
        ti.sprite.position.y += 1.6 * rawDt;
        const ts = 0.4 + 0.6 * easeOutBack(Math.min(1, ti.life / 0.12));
        ti.sprite.scale.set(2.4 * ts, 1.2 * ts, 1);
        ti.sprite.material.opacity = ti.life < 0.7 ? 1 : Math.max(0, 1 - (ti.life - 0.7) / 0.4);
      }

      // Sync visuelle du ballon
      deform.position.copy(ballState.p);
      const q = ballState.squash;
      if (q > 0.001) {
        squashQ.setFromUnitVectors(UP, ballState.squashN);
        deform.quaternion.copy(squashQ);
        deform.scale.set(1 + q, 1 - q, 1 + q);
      } else {
        deform.quaternion.identity();
        deform.scale.set(1, 1, 1);
      }
      innerLight.intensity = (ball.fireParticles ? 12 : ball.glowPower > 1 ? 7 : 0) * (0.85 + Math.sin(gt * 6) * 0.15);

      // Ballon arc-en-ciel : teintes animées
      if (ball.rainbow) {
        const hue = (gt * 0.12) % 1;
        ballMat.emissive.setHSL(hue, 0.9, 0.55);
        ballMat.emissiveIntensity = 1.1;
        glowUniforms.uColor.value.setHSL(hue, 0.85, 0.6);
        colBall.setHSL(hue, 0.85, 0.6);
        innerLight.color.setHSL(hue, 0.85, 0.6);
      }

      // Anneau de cible (pulsation et opacité liées à la vitesse de la balle)
      targetRing.position.x = mouseTarget.x;
      targetRing.position.z = mouseTarget.z;
      const spd = ballState.v.length();
      const ringScale = 1 + Math.sin(now * 0.005) * (0.06 + spd * 0.004);
      targetRing.scale.set(ringScale, ringScale, ringScale);
      (targetRing.material as THREE.MeshBasicMaterial).opacity = 0.35 + Math.min(0.3, spd * 0.02);

      // Ombre de contact
      const h = Math.max(0, ballState.p.y - R);
      const ss = 1.2 + h * 0.35;
      contactShadow.position.set(ballState.p.x, 0.012, ballState.p.z);
      contactShadow.scale.set(ss, ss, ss);
      (contactShadow.material as THREE.MeshBasicMaterial).opacity = THREE.MathUtils.clamp(0.65 - h * 0.06, 0.05, 0.65);

      // Particules
      let anyP = false;
      for (let i = 0; i < P_MAX; i++) {
        if (pAge[i] >= pLife[i]) { pAlpha[i] = 0; continue; }
        anyP = true;
        pAge[i] += rawDt;
        const lf = 1 - pAge[i] / pLife[i];
        pVel[i * 3 + 1] -= (ball.fireParticles ? -GRAV * 0.12 : GRAV * 0.4) * rawDt;
        const dr = 1 - 2.5 * rawDt;
        pVel[i * 3] *= dr; pVel[i * 3 + 1] *= dr; pVel[i * 3 + 2] *= dr;
        pPos[i * 3] += pVel[i * 3] * rawDt;
        pPos[i * 3 + 1] += pVel[i * 3 + 1] * rawDt;
        pPos[i * 3 + 2] += pVel[i * 3 + 2] * rawDt;
        if (pPos[i * 3 + 1] < 0.03) pPos[i * 3 + 1] = 0.03;
        pAlpha[i] = lf * pBase[i];
      }
      if (anyP) {
        pGeo.attributes.position.needsUpdate = true;
        pGeo.attributes.aAlpha.needsUpdate = true;
      }

      // Flashs d'impact
      for (const fo of flashLights) {
        fo.i *= Math.exp(-10 * rawDt);
        fo.l.intensity = fo.i;
      }

      // Tremblement caméra
      if (shake > 0.001) {
        camera.position.x += (Math.random() - 0.5) * shake * 0.4;
        camera.position.y += (Math.random() - 0.5) * shake * 0.3;
        camera.position.z += (Math.random() - 0.5) * shake * 0.3;
        shake *= Math.exp(-7 * rawDt);
      }
      camTarget.lerp(tmpV1.set(ballState.p.x * 0.18, 1 + ballState.p.y * 0.05, ballState.p.z * 0.18), 1 - Math.exp(-4 * rawDt));
      camera.lookAt(camTarget);

      // HUD
      const lv = level;
      if (ph === 'countdown') {
        hudRef.timeLabel = 'Prêt ?';
        hudRef.timeFrac = 1;
        hudRef.timeDanger = false;
        hudRef.progressMain = lv.type === 'collect' ? `0/${lv.targets ?? 0}`
          : lv.type === 'combo' ? `0/${lv.comboGoal ?? 0}` : `0.0s / ${lv.timeLimit}s`;
        hudRef.progressSub = '';
        hudRef.restFrac = 0;
      } else if (ph === 'playing' || ph === 'paused') {
        if (lv.type === 'collect') {
          const rem = Math.max(0, lv.timeLimit - challengeRef.elapsed);
          hudRef.timeLabel = `${Math.floor(rem / 60)}:${String(Math.floor(rem % 60)).padStart(2, '0')}`;
          hudRef.timeFrac = rem / lv.timeLimit;
          hudRef.timeDanger = rem < 10;
          hudRef.progressMain = `${challengeRef.collected}/${lv.targets ?? 0}`;
          hudRef.progressSub = 'cibles';
        } else if (lv.type === 'combo') {
          const rem = Math.max(0, lv.timeLimit - challengeRef.elapsed);
          hudRef.timeLabel = `${Math.floor(rem / 60)}:${String(Math.floor(rem % 60)).padStart(2, '0')}`;
          hudRef.timeFrac = rem / lv.timeLimit;
          hudRef.timeDanger = rem < 10;
          hudRef.progressMain = `${challengeRef.chain}`;
          hudRef.progressSub = `chaîne · record ${challengeRef.bestChain}/${lv.comboGoal ?? 0}`;
        } else {
          const el = challengeRef.elapsed;
          hudRef.timeLabel = `${el.toFixed(1)}s / ${lv.timeLimit}s`;
          hudRef.timeFrac = el / lv.timeLimit;
          hudRef.timeDanger = false;
          hudRef.progressMain = 'Survie';
          hudRef.progressSub = 'ne laissez pas le ballon reposer';
          hudRef.restFrac = THREE.MathUtils.clamp(challengeRef.restTimer / (lv.restLimit ?? 2.5), 0, 1);
        }
      }
      hudRef.speed = spd;
      hudRef.height = h;
      hudRef.energy = Math.round(0.5 * spd * spd + GRAV * h);
      hudRef.fps = Math.round(fpsEMA);

      renderer.render(scene, camera);
    }
    raf = requestAnimationFrame((t) => { lastT = t; loop(t); });

    // Sync HUD → React
    const hudTimer = window.setInterval(() => {
      setHud({ ...hudRef });
    }, 120);

    /* ================= CONTRÔLES UI ================= */
    function resetGame() {
      ballState.p.set(0, 5, 0);
      ballState.v.set(0, 0, 0);
      ballState.squash = 0;
      ballMesh.quaternion.identity();
      mouseTarget.set(0, R, 0);
      challengeRef.collected = 0;
      challengeRef.bounces = 0;
      challengeRef.chain = 0;
      challengeRef.bestChain = 0;
      challengeRef.lastImpact = -99;
      challengeRef.restTimer = 0;
      challengeRef.finished = false;
      challengeRef.elapsed = 0;
      spawnTargets();
      countRef.t = 3.9;
      countRef.shown = 4;
      acc = 0;
      phaseRef.v = 'countdown';
      setPhase('countdown');
    }

    controlsRef.current = {
      togglePause: () => {
        if (phaseRef.v === 'playing') {
          phaseRef.v = 'paused';
          setPhase('paused');
          crazyGames.gameplayStop();
        } else if (phaseRef.v === 'paused') {
          phaseRef.v = 'playing';
          setPhase('playing');
          lastT = performance.now();
          crazyGames.gameplayStart();
        }
      },
      restart: resetGame,
      setSnd: (v: boolean) => { audio.on = v; },
      setFx: (v: boolean) => { fxOn.v = v; },
    };

    /* ================= RESIZE / CLEANUP ================= */
    function onResize() {
      if (!mount) return;
      const w = mount.clientWidth, h2 = mount.clientHeight;
      renderer.setSize(w, h2);
      camera.aspect = w / h2;
      camera.updateProjectionMatrix();
    }
    window.addEventListener('resize', onResize);

    return () => {
      cancelAnimationFrame(raf);
      window.clearInterval(hudTimer);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerdown', onPointerDown);
      crazyGames.setMuteHandler(() => { /* cleanup */ });
      if (phaseRef.v === 'playing') crazyGames.gameplayStop();
      controlsRef.current = null;
      scene.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        if (mesh.geometry) mesh.geometry.dispose();
        const mat = mesh.material as THREE.Material | THREE.Material[] | undefined;
        if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
        else if (mat) mat.dispose();
      });
      for (const ti of textPool) {
        ti.tex.dispose();
        ti.sprite.material.dispose();
      }
      nebTex.dispose();
      nebMat.dispose();
      envTex.dispose();
      pmrem.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
    };

  }, [level.id, ball.id]);

  /* ---------- Actions UI (via refs posées dans l'effet) ---------- */
  const togglePause = () => controlsRef.current?.togglePause();
  const restart = () => controlsRef.current?.restart();
  const toggleSnd = () => { const v = !snd; setSnd(v); controlsRef.current?.setSnd(v); };
  const toggleFx = () => { const v = !fx; setFx(v); controlsRef.current?.setFx(v); };

  const timeBarColor = hud.timeDanger ? 'bg-red-500' : 'bg-[#d4574b]';
  const CH = CHAPTERS[Math.min(CHAPTERS.length, Math.max(1, level.chapter)) - 1] ?? CHAPTERS[0];

  return (
    <div className="absolute inset-0 overflow-hidden bg-[#1a1814]">
      <div ref={mountRef} className="absolute inset-0" />

      {/* ---------- HUD objectif ---------- */}
      <div className="pointer-events-none absolute left-1/2 top-[calc(12px+env(safe-area-inset-top,0px))] z-10 w-[min(92vw,420px)] -translate-x-1/2 rounded-2xl border border-white/15 bg-[#1e1c18]/60 p-3 text-center shadow-2xl backdrop-blur-xl">
        <div className="flex items-center justify-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.28em] text-[#e0d8c8]">
          {level.isBoss && <Crown size={12} aria-hidden className="fill-amber-300 text-amber-300" />}
          <span>Défi {level.id} · {level.name}</span>
        </div>
        <div className="mt-0.5 text-[9px] uppercase tracking-[0.2em] text-[#98907f]">
          Monde {level.chapter} — {CH.name}{level.isBoss ? ' · BOSS' : ''}
        </div>
        <div className="mt-1.5 flex items-center justify-center gap-4">
          <div className="text-2xl font-extrabold tabular-nums text-white">{hud.progressMain}</div>
          <div className="h-8 w-px bg-white/15" />
          <div className="text-2xl font-extrabold tabular-nums text-white">{hud.timeLabel}</div>
        </div>
        {hud.progressSub && (
          <div className="mt-0.5 text-[10px] uppercase tracking-[0.14em] text-[#98907f]">{hud.progressSub}</div>
        )}
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10">
          <div
            className={`h-full rounded-full transition-[width] duration-150 ${timeBarColor}`}
            style={{ width: `${Math.round(hud.timeFrac * 100)}%` }}
          />
        </div>
        {level.type === 'survival' && (
          <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/10">
            <div
              className={`h-full rounded-full ${hud.restFrac > 0.66 ? 'bg-red-500' : 'bg-amber-400'}`}
              style={{ width: `${Math.round(hud.restFrac * 100)}%` }}
            />
          </div>
        )}
      </div>

      {/* ---------- Stats ---------- */}
      <div className="pointer-events-none absolute right-3 top-[calc(12px+env(safe-area-inset-top,0px))] z-10 hidden rounded-2xl border border-white/15 bg-[#1e1c18]/55 px-4 py-3 shadow-xl backdrop-blur-xl sm:block">
        <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-right">
          <span className="text-[10px] font-bold tabular-nums text-white">{hud.speed.toFixed(1)}</span>
          <span className="text-[8px] uppercase tracking-[0.14em] text-[#98907f]">Vitesse</span>
          <span className="text-[10px] font-bold tabular-nums text-white">{hud.height.toFixed(1)}</span>
          <span className="text-[8px] uppercase tracking-[0.14em] text-[#98907f]">Hauteur</span>
          <span className="text-[10px] font-bold tabular-nums text-white">{hud.energy}</span>
          <span className="text-[8px] uppercase tracking-[0.14em] text-[#98907f]">Énergie</span>
          <span className="text-[10px] font-bold tabular-nums text-white">{hud.fps}</span>
          <span className="text-[8px] uppercase tracking-[0.14em] text-[#98907f]">FPS</span>
        </div>
      </div>

      {/* ---------- Barre d'actions ---------- */}
      <div className="absolute bottom-[calc(14px+env(safe-area-inset-bottom,0px))] left-1/2 z-10 flex max-w-[96vw] -translate-x-1/2 flex-wrap justify-center gap-2 rounded-2xl border border-white/20 bg-[#1e1c18]/60 p-2 shadow-2xl backdrop-blur-xl">
        <button onClick={togglePause} disabled={phase === 'done'}
          className="flex min-h-[44px] items-center gap-1.5 rounded-xl border border-white/20 bg-white/10 px-3.5 text-[11px] font-semibold tracking-wide text-[#e0d8c8] transition active:scale-95 disabled:opacity-40">
          {phase === 'paused' ? <Play size={14} /> : <Pause size={14} />} Pause
        </button>
        <button onClick={restart}
          className="flex min-h-[44px] items-center gap-1.5 rounded-xl border border-white/20 bg-white/10 px-3.5 text-[11px] font-semibold tracking-wide text-[#e0d8c8] transition active:scale-95">
          <RotateCcw size={14} /> Rejouer
        </button>
        <button onClick={toggleFx} aria-pressed={fx}
          className={`flex min-h-[44px] items-center gap-1.5 rounded-xl border px-3.5 text-[11px] font-semibold tracking-wide transition active:scale-95 ${fx ? 'border-[#d4574b] bg-[#d4574b] text-white shadow-[0_4px_16px_rgba(212,87,75,0.4)]' : 'border-white/20 bg-white/10 text-[#e0d8c8]'}`}>
          <Sparkles size={14} /> Effets
        </button>
        <button onClick={toggleSnd} aria-pressed={snd}
          className={`flex min-h-[44px] items-center gap-1.5 rounded-xl border px-3.5 text-[11px] font-semibold tracking-wide transition active:scale-95 ${snd ? 'border-[#d4574b] bg-[#d4574b] text-white shadow-[0_4px_16px_rgba(212,87,75,0.4)]' : 'border-white/20 bg-white/10 text-[#e0d8c8]'}`}>
          {snd ? <Volume2 size={14} /> : <VolumeX size={14} />} Son
        </button>
        <button onClick={onExit}
          className="flex min-h-[44px] items-center gap-1.5 rounded-xl border border-white/20 bg-white/10 px-3.5 text-[11px] font-semibold tracking-wide text-[#e0d8c8] transition active:scale-95">
          <DoorOpen size={14} /> Quitter
        </button>
      </div>

      {/* ---------- Astuce ---------- */}
      {phase === 'playing' && (
        <div className="pointer-events-none absolute bottom-[calc(92px+env(safe-area-inset-bottom,0px))] left-1/2 z-[9] -translate-x-1/2 whitespace-nowrap rounded-full border border-white/10 bg-black/40 px-4 py-1.5 text-[11px] text-[#c0b8a8] backdrop-blur-md">
          Déplacez la souris pour guider · Cliquez pour une impulsion
        </div>
      )}

      {/* ---------- Compte à rebours ---------- */}
      {phase === 'countdown' && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-black/45 backdrop-blur-sm">
          <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-[#98907f]">
            Monde {level.chapter} — {CH.name} · Défi {level.id}
          </div>
          <div className="text-7xl font-black tabular-nums text-white drop-shadow-[0_6px_24px_rgba(212,87,75,0.5)]">{count}</div>
          <div className="max-w-xs text-center text-[12px] leading-relaxed text-[#c0b8a8]">{level.hint}</div>
          {level.isBoss && (
            <div className="flex items-center gap-1.5 rounded-full border border-amber-400/40 bg-amber-400/15 px-4 py-1.5 text-[11px] font-black uppercase tracking-widest text-amber-300">
              <Crown size={13} aria-hidden /> Niveau BOSS — récompense majeure !
            </div>
          )}
        </div>
      )}

      {/* ---------- Pause ---------- */}
      {phase === 'paused' && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-4 bg-black/55 backdrop-blur-sm">
          <div className="text-[11px] font-bold uppercase tracking-[0.3em] text-[#98907f]">Pause</div>
          <div className="flex flex-col gap-2.5">
            <button onClick={togglePause} className="min-h-[46px] rounded-xl bg-[#d4574b] px-10 text-sm font-bold text-white shadow-lg transition active:scale-95">
              Reprendre
            </button>
            <button onClick={restart} className="min-h-[46px] rounded-xl border border-white/20 bg-white/10 px-10 text-sm font-semibold text-[#e0d8c8] transition active:scale-95">
              Recommencer
            </button>
            <button onClick={onExit} className="min-h-[46px] rounded-xl border border-white/20 bg-white/10 px-10 text-sm font-semibold text-[#e0d8c8] transition active:scale-95">
              Quitter le défi
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
