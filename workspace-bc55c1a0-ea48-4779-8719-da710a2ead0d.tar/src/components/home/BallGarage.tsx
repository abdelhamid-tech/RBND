'use client';

/* ============================================================
   BallGarage — « garage » 3D de sélection de ballons, façon
   sélecteur de véhicule dans les jeux de course : socle
   rotatif, ballon flottant que l'on fait tourner au doigt
   (avec inertie), fiches stats, achat / équipement.
   Tout le rendu Three.js est SSR-safe (dans useEffect).
============================================================ */

import { useCallback, useEffect, useRef } from 'react';
import Image from 'next/image';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { ArrowLeft, ChevronLeft, ChevronRight, Lock, Zap } from 'lucide-react';
import type { BallDef, PlayerDTO } from '@/lib/game/types';
import { buildBallTexture } from '@/lib/game/ball-textures';

export interface BallGarageProps {
  balls: BallDef[];
  /** index of the currently displayed ball (controlled by parent) */
  index: number;
  onIndexChange: (index: number) => void;
  player: PlayerDTO;
  busy: boolean;
  onBuy: (ball: BallDef) => void;
  onSelect: (ball: BallDef) => void;
  /** optionnel : affiche un bouton retour (mode plein écran) */
  onBack?: () => void;
}

/* ---------------- Réglages scène ---------------- */
const BALL_Y = 1.5; // hauteur de flottement du ballon
const AUTO_SPIN = 0.35; // rad/s — rotation automatique
const BOB_AMP = 0.06; // amplitude du flottement sinusoïdal
const POP_MS = 350; // durée du « pop » au changement de ballon
const MAX_DPR = 1.75; // pixel ratio plafonné
const DRAG_SENS = 0.012; // radians par pixel de drag

/** État Three.js partagé entre l'effet de montage et les rebuilds de ballon */
interface GarageScene {
  renderer: THREE.WebGLRenderer;
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  pmrem: THREE.PMREMGenerator;
  envTex: THREE.Texture;
  ballGroup: THREE.Group;
  shadow: THREE.Mesh<THREE.PlaneGeometry, THREE.MeshBasicMaterial>;
  ring: THREE.Mesh<THREE.TorusGeometry, THREE.MeshBasicMaterial>;
  clock: THREE.Clock;
  ballId: string | null;
  rotY: number;
  spinVel: number;
  dragging: boolean;
  /** timestamp du début du pop, -1 = inactif */
  popStart: number;
  /** compteur de génération : invalide les textures async obsolètes */
  gen: number;
  /** ballon arc-en-ciel : teintes animées */
  rainbow: boolean;
  /** matériau du ballon courant (pour l'anim arc-en-ciel) */
  mat: THREE.MeshPhysicalMaterial | null;
  /** coquille de lueur courante */
  glowUniforms: { uPower: { value: number }; uColor: { value: THREE.Color } } | null;
}

/* ---------------- Helpers de disposal ---------------- */

function disposeMaterial(mat: THREE.Material): void {
  const maybeMapped = mat as THREE.MeshPhysicalMaterial;
  if (maybeMapped.map) maybeMapped.map.dispose();
  mat.dispose();
}

function disposeTree(root: THREE.Object3D): void {
  root.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (mesh.geometry) mesh.geometry.dispose();
    const mat = mesh.material;
    if (Array.isArray(mat)) {
      for (const m of mat) disposeMaterial(m);
    } else if (mat) {
      disposeMaterial(mat);
    }
  });
}

/**
 * (Re)construit le ballon affiché depuis un BallDef — mêmes réglages
 * de matériau / texture / lueur que GameCanvas (moteur de jeu).
 */
function applyBall(ctx: GarageScene, ball: BallDef): void {
  // Libère l'ancien ballon (géométries / matériaux / textures)
  const old = [...ctx.ballGroup.children];
  ctx.ballGroup.clear();
  for (const child of old) disposeTree(child);

  ctx.gen += 1;
  const gen = ctx.gen;
  ctx.ballId = ball.id;

  const ballOpacity = ball.opacity ?? 1;
  const mat = new THREE.MeshPhysicalMaterial({
    color: ball.color,
    roughness: ball.roughness,
    metalness: ball.metalness,
    clearcoat: ball.clearcoat,
    clearcoatRoughness: ball.clearcoatRoughness,
    emissive: new THREE.Color(ball.emissive),
    emissiveIntensity: ball.emissiveIntensity,
    envMapIntensity: 1.15,
    transparent: ballOpacity < 1,
    opacity: ballOpacity,
  });
  ctx.mat = mat;
  ctx.rainbow = !!ball.rainbow;
  ctx.ballGroup.add(new THREE.Mesh(new THREE.SphereGeometry(1, 48, 32), mat));

  // Texture : procédurale (canvas) ou fichier public — chargement async
  void (async () => {
    try {
      let tex: THREE.Texture | null = null;
      if (ball.procTex) {
        tex = new THREE.CanvasTexture(buildBallTexture(ball.procTex));
      } else if (ball.texture) {
        tex = await new THREE.TextureLoader().loadAsync(ball.texture);
      }
      if (!tex) return;
      if (gen !== ctx.gen) {
        tex.dispose(); // un autre ballon a été affiché entre-temps
        return;
      }
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = Math.min(8, ctx.renderer.capabilities.getMaxAnisotropy());
      mat.map = tex;
      mat.color.set(0xffffff);
      mat.needsUpdate = true;
    } catch {
      /* texture manquante : couleur unie */
    }
  })();

  // Coquille de lueur fresnel additive — même shader que le jeu
  const glowUniforms = {
    uPower: { value: ball.glowPower },
    uColor: { value: new THREE.Color(ball.glowColor) },
  };
  ctx.glowUniforms = glowUniforms;
  const glowMat = new THREE.ShaderMaterial({
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    uniforms: glowUniforms,
    vertexShader:
      'varying float vF; void main(){ vec3 n=normalize(normalMatrix*normal); vec4 mv=modelViewMatrix*vec4(position,1.0); vec3 vd=normalize(-mv.xyz); vF=pow(1.0-abs(dot(n,vd)),2.2); gl_Position=projectionMatrix*mv; }',
    fragmentShader:
      'uniform float uPower; uniform vec3 uColor; varying float vF; void main(){ gl_FragColor=vec4(uColor, vF*uPower); }',
  });
  ctx.ballGroup.add(new THREE.Mesh(new THREE.SphereGeometry(1.16, 32, 24), glowMat));

  // Lumière interne (météore / néon) — même règle que le jeu
  ctx.ballGroup.add(
    new THREE.PointLight(ball.glowColor, ball.fireParticles ? 14 : ball.glowPower > 1 ? 8 : 0, 11, 2)
  );

  // « Pop » d'apparition (1 → 0.84 → 1)
  ctx.popStart = performance.now();
  ctx.ballGroup.scale.setScalar(1);
}

/* ============================================================ */

export default function BallGarage({
  balls,
  index,
  onIndexChange,
  player,
  busy,
  onBuy,
  onSelect,
  onBack,
}: BallGarageProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const ctxRef = useRef<GarageScene | null>(null);

  /* ---------- Montage de la scène (une seule fois) ---------- */
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const w0 = Math.max(1, container.clientWidth);
    const h0 = Math.max(1, container.clientHeight);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, MAX_DPR));
    renderer.setSize(w0, h0);
    renderer.setClearColor(0x000000, 0); // transparent : le dégradé CSS du card transparaît
    const el = renderer.domElement;
    el.style.display = 'block';
    el.style.touchAction = 'none';
    el.style.cursor = 'grab';
    el.setAttribute('aria-hidden', 'true');
    container.appendChild(el);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(36, w0 / h0, 0.1, 60);
    camera.position.set(0, 2.6, 7.2);
    camera.lookAt(0, 1.15, 0);

    // Environnement pour les reflets (métal / clearcoat) — même pattern que le jeu
    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;

    /* ---------- Lumières ---------- */
    scene.add(new THREE.HemisphereLight(0xfff4e0, 0x2a231a, 0.55));
    const key = new THREE.SpotLight(0xfff1dc, 280, 45, Math.PI / 4.5, 0.5, 2);
    key.position.set(0.5, 9.5, 3);
    key.target.position.set(0, 1.2, 0);
    scene.add(key);
    scene.add(key.target);
    const rimTerra = new THREE.PointLight(0xd4574b, 34, 20, 2);
    rimTerra.position.set(-5.2, 2.6, -3.2);
    scene.add(rimTerra);
    const rimAmber = new THREE.PointLight(0xffb35c, 26, 20, 2);
    rimAmber.position.set(4.8, 3.2, -4.2);
    scene.add(rimAmber);

    /* ---------- Socle ---------- */
    const pedestal = new THREE.Mesh(
      new THREE.CylinderGeometry(2.2, 2.42, 0.35, 56),
      new THREE.MeshStandardMaterial({ color: 0x26221c, metalness: 0.6, roughness: 0.35, envMapIntensity: 0.45 })
    );
    pedestal.position.y = 0.175;
    scene.add(pedestal);

    // Anneau émissif terracotta au bord supérieur (additif, pulsant)
    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(2.2, 0.03, 10, 72),
      new THREE.MeshBasicMaterial({
        color: 0xd4574b,
        transparent: true,
        opacity: 0.85,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.352;
    scene.add(ring);

    // Ombre de contact sous le ballon (dégradé radial canvas, comme le jeu)
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 128;
    shadowCanvas.height = 128;
    const sg = shadowCanvas.getContext('2d');
    if (sg) {
      const rg = sg.createRadialGradient(64, 64, 4, 64, 64, 62);
      rg.addColorStop(0, 'rgba(0,0,0,0.85)');
      rg.addColorStop(1, 'rgba(0,0,0,0)');
      sg.fillStyle = rg;
      sg.fillRect(0, 0, 128, 128);
    }
    const shadow = new THREE.Mesh(
      new THREE.PlaneGeometry(3.4, 3.4),
      new THREE.MeshBasicMaterial({
        map: new THREE.CanvasTexture(shadowCanvas),
        transparent: true,
        depthWrite: false,
        opacity: 0.78,
      })
    );
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.y = 0.365;
    shadow.renderOrder = 1;
    scene.add(shadow);

    const ballGroup = new THREE.Group();
    ballGroup.position.set(0, BALL_Y, 0);
    scene.add(ballGroup);

    const ctx: GarageScene = {
      renderer, scene, camera, pmrem, envTex, ballGroup, shadow, ring,
      clock: new THREE.Clock(), ballId: null, rotY: 0, spinVel: 0,
      dragging: false, popStart: -1, gen: 0, rainbow: false, mat: null, glowUniforms: null,
    };
    ctxRef.current = ctx;

    /* ---------- Drag horizontal avec inertie ---------- */
    let lastX = 0;
    let lastMoveT = 0;
    const onDown = (e: PointerEvent) => {
      ctx.dragging = true;
      lastX = e.clientX;
      el.style.cursor = 'grabbing';
      try {
        el.setPointerCapture(e.pointerId);
      } catch {
        /* pointeur déjà relâché */
      }
    };
    const onMove = (e: PointerEvent) => {
      if (!ctx.dragging) return;
      const dx = e.clientX - lastX;
      lastX = e.clientX;
      lastMoveT = performance.now();
      ctx.rotY += dx * DRAG_SENS;
      ctx.spinVel = THREE.MathUtils.clamp(dx * DRAG_SENS * 60, -8, 8);
    };
    const onUp = (e: PointerEvent) => {
      if (!ctx.dragging) return;
      ctx.dragging = false;
      el.style.cursor = 'grab';
      // arrêt net si le doigt/souris était immobile depuis un moment
      if (performance.now() - lastMoveT > 80) ctx.spinVel = 0;
      try {
        el.releasePointerCapture(e.pointerId);
      } catch {
        /* déjà relâché */
      }
    };
    el.addEventListener('pointerdown', onDown);
    el.addEventListener('pointermove', onMove);
    el.addEventListener('pointerup', onUp);
    el.addEventListener('pointercancel', onUp);

    /* ---------- Resize ---------- */
    const resize = () => {
      const w = container.clientWidth;
      const h = container.clientHeight;
      if (w < 2 || h < 2) return;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    const ro = new ResizeObserver(resize);
    ro.observe(container);

    /* ---------- Boucle de rendu ---------- */
    let raf = 0;
    const render = () => {
      const dt = Math.min(ctx.clock.getDelta(), 0.05);
      const t = ctx.clock.elapsedTime;

      // rotation : auto + inertie du drag (décroissance exponentielle)
      if (!ctx.dragging) {
        ctx.rotY += AUTO_SPIN * dt + ctx.spinVel * dt;
        ctx.spinVel *= Math.exp(-2.8 * dt);
        if (Math.abs(ctx.spinVel) < 0.02) ctx.spinVel = 0;
      }
      ctx.ballGroup.rotation.y = ctx.rotY;

      // flottement sinusoïdal ±0.06
      const bob = Math.sin(t * 1.5) * BOB_AMP;
      ctx.ballGroup.position.y = BALL_Y + bob;

      // pop d'échelle 1 → 0.84 → 1 (easing sinusoïdal)
      if (ctx.popStart >= 0) {
        const p = (performance.now() - ctx.popStart) / POP_MS;
        if (p >= 1) {
          ctx.popStart = -1;
          ctx.ballGroup.scale.setScalar(1);
        } else {
          ctx.ballGroup.scale.setScalar(1 - 0.16 * Math.sin(Math.PI * Math.max(0, p)));
        }
      }

      // l'ombre respire avec le flottement, l'anneau pulse doucement
      ctx.shadow.scale.setScalar(1 - bob * 2);
      ctx.shadow.material.opacity = 0.78 - bob * 1.8;
      ctx.ring.material.opacity = 0.6 + 0.25 * Math.sin(t * 2.4);

      // ballon arc-en-ciel : teintes animées
      if (ctx.rainbow && ctx.mat && ctx.glowUniforms) {
        const hue = (t * 0.12) % 1;
        ctx.mat.emissive.setHSL(hue, 0.9, 0.55);
        ctx.mat.emissiveIntensity = 1.1;
        ctx.glowUniforms.uColor.value.setHSL(hue, 0.85, 0.6);
      }

      renderer.render(scene, camera);
    };
    const loop = () => {
      raf = requestAnimationFrame(loop);
      if (document.hidden) return; // pause quand l'onglet est masqué
      render();
    };
    raf = requestAnimationFrame(loop);

    /* ---------- Nettoyage intégral ---------- */
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      el.removeEventListener('pointerdown', onDown);
      el.removeEventListener('pointermove', onMove);
      el.removeEventListener('pointerup', onUp);
      el.removeEventListener('pointercancel', onUp);
      ctxRef.current = null;
      disposeTree(scene);
      envTex.dispose();
      pmrem.dispose();
      renderer.dispose();
      el.remove();
    };
  }, []);

  /* ---------- Rebuild du ballon à chaque changement d'index ---------- */
  useEffect(() => {
    const ctx = ctxRef.current;
    const len = balls.length;
    if (!ctx || len === 0) return;
    const ball = balls[Math.min(Math.max(index, 0), len - 1)];
    if (ctx.ballId === ball.id) return; // déjà affiché
    applyBall(ctx, ball);
  }, [index, balls]);

  /* ---------- Navigation ---------- */
  const go = useCallback(
    (dir: 1 | -1) => {
      const len = balls.length;
      if (len === 0) return;
      onIndexChange((((index + dir) % len) + len) % len);
    },
    [balls.length, index, onIndexChange]
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target;
      if (t instanceof HTMLElement && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) {
        return;
      }
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        go(-1);
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        go(1);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [go]);

  /* ---------- Dérivés UI ---------- */
  const len = balls.length;
  if (len === 0) return null;
  const idx = Math.min(Math.max(index, 0), len - 1);
  const ball = balls[idx];
  const owned = player.ownedBalls.includes(ball.id);
  const equipped = player.selectedBall === ball.id;
  const missing = Math.max(0, ball.price - player.totalXp);
  const stats = [
    { label: 'Rebond', value: `${Math.round(ball.restitution * 100)}%` },
    { label: 'Gravité', value: `×${ball.gravityFactor.toFixed(2)}` },
    { label: 'Style', value: `${Math.round(Math.min(100, ball.glowPower * 55 + ball.particleShade * 45))}%` },
  ];

  return (
    <section className="overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-[#1e1c18] to-[#14120f] shadow-[0_18px_50px_-20px_rgba(0,0,0,0.8)] backdrop-blur">
      {/* ================= Viewport 3D ================= */}
      <div ref={containerRef} className="relative h-[340px] w-full select-none sm:h-[420px]">
        {/* Vignette décorative — le canvas alpha laisse voir le dégradé du card */}
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_50%_42%,transparent_42%,rgba(0,0,0,0.45)_100%)]" />

        {/* Bouton retour (mode plein écran) */}
        {onBack && (
          <button
            type="button"
            onClick={onBack}
            aria-label="Retour à l'accueil"
            className="pointer-events-auto absolute left-3 top-3 z-10 flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full border border-white/15 bg-black/40 text-white backdrop-blur transition hover:bg-black/60 active:scale-95"
          >
            <ArrowLeft size={18} aria-hidden />
          </button>
        )}

        {/* --------- Overlay (pointer-events-none sauf boutons) --------- */}
        <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-4 sm:p-5">
          {/* Nom + tagline + puces d'état */}
          <div className="flex items-start justify-between gap-3">
            <div className={`min-w-0 ${onBack ? 'pl-12' : ''}`}>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-lg font-black leading-tight text-white">{ball.name}</h3>
                {equipped && (
                  <span className="rounded-full bg-[#d4574b] px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white">
                    Équipé
                  </span>
                )}
              </div>
              <p className="mt-1 truncate text-[10px] uppercase tracking-[0.2em] text-[#98907f]">{ball.tagline}</p>
            </div>
            {!owned && (
              <span className="flex shrink-0 items-center gap-1.5 rounded-full border border-white/15 bg-black/40 p-2 pr-3 backdrop-blur">
                <Lock size={14} className="text-[#98907f]" aria-hidden />
                <span className={`text-xs font-bold ${missing > 0 ? 'text-[#ff8a7a]' : 'text-amber-300'}`}>
                  {ball.price} XP
                </span>
              </span>
            )}
          </div>

          {/* Indicateur d'index + stats en chips verre */}
          <div className="flex flex-col items-center gap-1.5">
            <span className="text-[10px] font-bold tabular-nums text-[#98907f]">
              {idx + 1} / {len}
            </span>
            <div className="flex gap-2">
              {stats.map((s) => (
                <div
                  key={s.label}
                  className="flex flex-col items-center rounded-lg bg-white/5 px-2.5 py-1 backdrop-blur-sm"
                >
                  <span className="text-[8px] font-semibold uppercase tracking-wider text-[#98907f]">{s.label}</span>
                  <span className="text-xs font-bold leading-tight text-white">{s.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Chevrons latéraux */}
        <button
          type="button"
          onClick={() => go(-1)}
          aria-label="Ballon précédent"
          className="pointer-events-auto absolute left-3 top-1/2 flex min-h-[44px] min-w-[44px] -translate-y-1/2 items-center justify-center rounded-full border border-white/15 bg-black/40 text-white backdrop-blur transition hover:bg-black/60 active:scale-95"
        >
          <ChevronLeft size={20} aria-hidden />
        </button>
        <button
          type="button"
          onClick={() => go(1)}
          aria-label="Ballon suivant"
          className="pointer-events-auto absolute right-3 top-1/2 flex min-h-[44px] min-w-[44px] -translate-y-1/2 items-center justify-center rounded-full border border-white/15 bg-black/40 text-white backdrop-blur transition hover:bg-black/60 active:scale-95"
        >
          <ChevronRight size={20} aria-hidden />
        </button>
      </div>

      {/* ================= Description + actions ================= */}
      <div className="px-5 pb-5 pt-4">
        <p className="text-xs leading-relaxed text-[#b5ac9c]">{ball.description}</p>
        <div className="mt-3 flex flex-wrap items-center gap-3">
          {equipped ? (
            <span className="flex min-h-[44px] items-center rounded-xl bg-white/5 px-6 text-sm font-bold text-[#98907f]">
              En jeu
            </span>
          ) : owned ? (
            <button
              type="button"
              onClick={() => onSelect(ball)}
              disabled={busy}
              className="flex min-h-[44px] items-center rounded-xl border border-emerald-400/40 bg-emerald-400/10 px-6 text-sm font-bold text-emerald-300 transition hover:bg-emerald-400/20 active:scale-95 disabled:opacity-50"
            >
              Équiper
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onBuy(ball)}
              disabled={busy || missing > 0}
              title={missing > 0 ? `Il vous manque ${missing} XP` : undefined}
              className="flex min-h-[44px] items-center gap-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 px-6 text-sm font-bold text-[#1a1814] shadow-lg transition hover:brightness-105 active:scale-95 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <Zap size={15} aria-hidden />
              Acheter · {ball.price} XP
              {missing > 0 && <span className="font-semibold opacity-70">−{missing} XP</span>}
            </button>
          )}
        </div>
      </div>

      {/* ================= Bande de vignettes ================= */}
      <div className="flex justify-start gap-2 overflow-x-auto px-5 pb-5 pt-1 sm:justify-center">
        {balls.map((b, i) => {
          const bOwned = player.ownedBalls.includes(b.id);
          const selected = i === idx;
          return (
            <button
              key={b.id}
              type="button"
              onClick={() => onIndexChange(i)}
              aria-label={b.name}
              aria-pressed={selected}
              title={b.name}
              className={`relative h-[48px] min-h-[48px] w-[48px] min-w-[48px] shrink-0 rounded-full ring-2 transition ${
                selected ? 'ring-[#d4574b]' : bOwned ? 'ring-emerald-400/50' : 'ring-white/15'
              } ${selected ? '' : 'hover:scale-105'}`}
            >
              <span
                className={`block h-full w-full overflow-hidden rounded-full ${
                  bOwned ? 'opacity-100' : 'opacity-50'
                }`}
              >
                {b.preview ? (
                  <Image src={b.preview} alt={b.name} width={96} height={96} className="h-full w-full object-cover" />
                ) : (
                  <span
                    aria-hidden
                    className="block h-full w-full"
                    style={{
                      background: `radial-gradient(circle at 32% 28%, ${b.previewColor}f2, ${b.previewColor}88 45%, #171310 100%)`,
                    }}
                  />
                )}
              </span>
              {!bOwned && (
                <span className="absolute -bottom-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full border border-white/10 bg-black/80">
                  <Lock size={11} className="text-[#98907f]" aria-hidden />
                </span>
              )}
            </button>
          );
        })}
      </div>
    </section>
  );
}
