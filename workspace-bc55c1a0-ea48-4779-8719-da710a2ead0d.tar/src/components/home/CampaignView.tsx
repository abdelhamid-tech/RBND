'use client';

/* ============================================================
   CampaignView — sous-vue plein écran de l'accueil :
   Campagne (20 mondes × 20 défis = 400 niveaux, navigateur de
   mondes + grille + briefing), Missions du jour,
   Bonus quotidien via pub rewarded (SDK CrazyGames).
   ► Refonte VISUELLE premium (typographie display, panneaux,
   pièces XP, animations) — la logique et les systèmes sont
   strictement identiques (état, handlers, données).
============================================================ */

import { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft, Check, Clapperboard, Crown, Flame, Gift, Lock, Play, RotateCcw, Sparkles, Star, Swords, Zap,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import {
  LEVELS, TOTAL_LEVELS, TOTAL_CHAPTERS, CHAPTERS, CHALLENGE_EMOJI, CHALLENGE_LABEL, tierOf,
} from '@/lib/game/levels';
import { DAILIES, dailyDone, dailyClaimable } from '@/lib/game/dailies';
import type { DailyDef, DailyState } from '@/lib/game/dailies';
import type { LevelDef, PlayerDTO } from '@/lib/game/types';

export interface CampaignViewProps {
  player: PlayerDTO;
  dailies: DailyState;
  onPlay: (lv: LevelDef) => void;
  onClaimBonus: () => void;
  onClaimDaily: (d: DailyDef) => void;
  busy: boolean;
  onBack: () => void;
}

/* ---------- Teintes des paliers de difficulté ---------- */
const TIER_CHIP: Record<string, string> = {
  Facile: 'border-emerald-400/40 bg-emerald-400/10 text-emerald-300',
  Difficile: 'border-amber-400/40 bg-amber-400/10 text-amber-300',
  'Extrême': 'border-orange-500/40 bg-orange-500/10 text-orange-300',
  Cauchemar: 'border-red-500/50 bg-red-500/10 text-red-300',
};

function fmtCountdown(iso: string): string {
  const diff = new Date(iso).getTime() - Date.now();
  if (diff <= 0) return '';
  const h = Math.floor(diff / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  if (h > 0) return `${h} h ${String(m).padStart(2, '0')} min`;
  return `${m} min`;
}

function hex(c: number): string {
  return `#${c.toString(16).padStart(6, '0')}`;
}

/* ---------- En-tête de section premium : [icône] TITRE ───── méta ---------- */
function SectionHeader({ icon: Icon, title, meta, subtitle }: { icon: LucideIcon; title: string; meta?: string; subtitle?: string }) {
  return (
    <div className="mb-4">
      <div className="flex items-center gap-3">
        <span
          aria-hidden
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-[#d4574b]/30 bg-gradient-to-b from-[#d4574b]/20 to-transparent text-[#e88a76] shadow-[inset_0_1px_0_rgba(255,255,255,0.08)]"
        >
          <Icon size={16} />
        </span>
        <h2 className="font-display text-stamp text-sm uppercase tracking-[0.18em] text-white">{title}</h2>
        <span aria-hidden className="h-px flex-1 bg-gradient-to-r from-white/15 via-white/5 to-transparent" />
        {meta && (
          <span className="hidden shrink-0 text-[10px] font-bold uppercase tracking-[0.16em] text-[#98907f] sm:block">
            {meta}
          </span>
        )}
      </div>
      {subtitle && <p className="mt-1.5 pl-12 text-xs font-medium text-[#98907f]">{subtitle}</p>}
    </div>
  );
}

/* ---------- Rangée de 3 étoiles (remplies si défi réussi) ---------- */
function Stars({ count, done, size = 9 }: { count: number; done: boolean; size?: number }) {
  return (
    <span className="inline-flex items-center gap-[3px]">
      {[1, 2, 3].map((s) => (
        <Star
          key={s}
          size={size}
          aria-hidden
          className={done && s <= count ? 'fill-amber-400 text-amber-400' : 'text-white/15'}
        />
      ))}
    </span>
  );
}

/* ---------- Pièce XP (médaillon ambre) ---------- */
function Coin({ size = 32 }: { size?: number }) {
  return (
    <span
      aria-hidden
      className="flex shrink-0 items-center justify-center rounded-full bg-gradient-to-b from-amber-300 to-amber-500 shadow-[inset_0_1px_0_rgba(255,255,255,0.55),0_4px_12px_rgba(255,201,74,0.35)] ring-1 ring-amber-200/50"
      style={{ height: size, width: size }}
    >
      <Zap size={size * 0.44} className="fill-[#4a3405] text-[#4a3405]" />
    </span>
  );
}

export default function CampaignView({ player, dailies, onPlay, onClaimBonus, onClaimDaily, busy, onBack }: CampaignViewProps) {
  /* ----- joueur / progression ----- */
  const completedCount = player.completedLevels.length;
  const xpPct = Math.min(100, Math.max(0, Math.round((player.xpIntoLevel / player.xpForNext) * 100)));
  const isDone = (id: number) => player.completedLevels.includes(id);

  const highestUnlocked = useMemo(() => {
    let n = 1;
    for (let i = 1; i <= TOTAL_LEVELS; i++) {
      if (player.completedLevels.includes(i)) n = i + 1;
      else break;
    }
    return Math.min(n, TOTAL_LEVELS);
  }, [player.completedLevels]);

  /* ----- campagne : monde sélectionné + niveau sélectionné ----- */
  const chapterOfLevel = (id: number) => Math.min(TOTAL_CHAPTERS, Math.ceil(id / 20));
  const [chapterId, setChapterId] = useState<number>(chapterOfLevel(highestUnlocked));
  const [selectedId, setSelectedId] = useState<number>(highestUnlocked);
  const stripRef = useRef<HTMLDivElement>(null);

  const chapterStart = (cid: number) => (cid - 1) * 20 + 1;
  const selectedChapter = CHAPTERS[chapterId - 1] ?? CHAPTERS[0];
  const chapterLevels: LevelDef[] = LEVELS.slice(chapterStart(chapterId) - 1, chapterStart(chapterId) + 19);

  const selectChapter = (cid: number) => {
    const start = chapterStart(cid);
    const end = start + 19;
    setChapterId(cid);
    setSelectedId(Math.min(Math.max(highestUnlocked, start), end));
  };

  // Centre la bande de mondes sur le monde sélectionné
  useEffect(() => {
    const strip = stripRef.current;
    if (!strip) return;
    const card = strip.querySelector<HTMLElement>(`[data-chapter="${chapterId}"]`);
    if (card) {
      strip.scrollTo({
        left: card.offsetLeft - strip.clientWidth / 2 + card.clientWidth / 2,
        behavior: 'smooth',
      });
    }
  }, [chapterId]);

  const selectedLv: LevelDef = LEVELS[selectedId - 1] ?? LEVELS[0];

  /* ----- briefing du défi sélectionné ----- */
  const blDone = isDone(selectedLv.id);
  const blLocked = selectedLv.id > highestUnlocked;
  const replayXp = Math.max(10, Math.floor(selectedLv.xpReward * 0.25));
  const blObjective =
    selectedLv.type === 'collect'
      ? `${selectedLv.targets ?? 0} cibles`
      : selectedLv.type === 'combo'
        ? `Chaîne de ${selectedLv.comboGoal ?? 0}`
        : `${selectedLv.timeLimit} s à tenir`;
  const metaChip = 'rounded-full border border-white/10 bg-white/[0.06] px-2.5 py-1 text-[10px] font-semibold text-[#c0b8a8]';
  const tier = tierOf(selectedLv.id);
  const chapterDoneCount = chapterLevels.filter((lv) => isDone(lv.id)).length;
  const chapterLocked = chapterStart(chapterId) > highestUnlocked;

  return (
    <div className="rbnd-scroll fixed inset-0 overflow-y-auto bg-[#14120f] text-[#e8e0d0]">
      {/* ---------- Fond décoratif : lueurs terracotta / ambre + vignette ---------- */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0"
        style={{
          background: [
            'radial-gradient(1100px 540px at 50% -12%, rgba(212,87,75,0.17), transparent 62%)',
            'radial-gradient(900px 540px at 88% 112%, rgba(255,201,74,0.10), transparent 60%)',
            'radial-gradient(720px 460px at 4% 82%, rgba(212,87,75,0.06), transparent 65%)',
            'radial-gradient(130% 105% at 50% 45%, transparent 55%, rgba(8,7,5,0.5) 100%)',
          ].join(', '),
        }}
      />

      <div className="relative mx-auto w-full max-w-6xl px-4 pb-28 sm:px-6">
        {/* ============================================================
            Barre joueur collante : retour + niveau + XP + pièce
        ============================================================ */}
        <header className="sticky top-0 z-20 -mx-4 bg-gradient-to-b from-[#14120f] via-[#14120f]/95 to-[#14120f]/70 px-4 pb-3 pt-[calc(12px+env(safe-area-inset-top,0px))] backdrop-blur-md sm:-mx-6 sm:px-6">
          <div className="panel-hi flex items-center gap-3 rounded-2xl border border-white/10 bg-[#1c1915]/85 p-2.5 pl-2.5 backdrop-blur-xl">
            <button
              type="button"
              onClick={onBack}
              aria-label="Retour à l'accueil"
              className="flex min-h-[44px] items-center gap-1.5 rounded-xl border border-white/10 bg-black/30 px-3.5 text-sm font-bold text-[#e8e0d0] transition hover:border-white/25 hover:bg-black/50 active:scale-95"
            >
              <ArrowLeft size={16} aria-hidden />
              <span className="hidden sm:inline">Accueil</span>
            </button>
            <span aria-hidden className="h-9 w-px bg-white/10" />

            {/* Médaillon niveau + barre de progression */}
            <div
              className="flex h-[46px] w-[46px] shrink-0 items-center justify-center rounded-full p-[4px] shadow-[0_8px_20px_rgba(0,0,0,0.45)] ring-1 ring-white/10"
              style={{ background: `conic-gradient(#d4574b ${xpPct}%, rgba(255,255,255,0.08) 0)` }}
              role="img"
              aria-label={`Niveau ${player.level} — progression ${xpPct}%`}
            >
              <div className="flex h-full w-full items-center justify-center rounded-full border border-white/5 bg-[#1c1a16]">
                <span className="font-display text-sm text-white">{player.level}</span>
              </div>
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline justify-between gap-2">
                <span className="font-display text-xs uppercase tracking-[0.14em] text-white">
                  Niveau {player.level}
                </span>
                <span className="text-[10px] font-bold tabular-nums text-[#98907f]">{xpPct}%</span>
              </div>
              <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                <div
                  className="bar-sheen h-full rounded-full bg-gradient-to-r from-[#d4574b] to-[#ffc94a]"
                  style={{ width: `${xpPct}%` }}
                />
              </div>
            </div>

            {/* Pièce XP */}
            <div className="flex shrink-0 items-center gap-2 rounded-full border border-amber-400/25 bg-amber-400/[0.07] py-1 pl-1.5 pr-3.5">
              <Coin size={30} />
              <span className="font-display text-sm tabular-nums text-amber-100">
                {player.totalXp.toLocaleString('fr-FR')}
              </span>
              <span className="sr-only">XP</span>
            </div>
          </div>
        </header>

        {/* ============================================================
            1. CAMPAGNE — navigateur de mondes (20 × 20 défis)
        ============================================================ */}
        <section className="mt-7" aria-label="Campagne">
          <SectionHeader
            icon={Swords}
            title="Campagne"
            meta={`${TOTAL_LEVELS} défis · ${TOTAL_CHAPTERS} mondes`}
            subtitle="Chaque monde a son ambiance, ses mécaniques et son BOSS final"
          />

          <div className="panel-hi rounded-3xl border border-white/10 bg-[#1a1814]/60 p-4 backdrop-blur-xl sm:p-5">
            {/* ----- Bande des mondes ----- */}
            <div ref={stripRef} className="rbnd-scroll overflow-x-auto pb-2">
              <div className="flex min-w-max gap-2.5 px-1">
                {CHAPTERS.map((c) => {
                  const start = (c.id - 1) * 20 + 1;
                  const locked = start > highestUnlocked;
                  const active = c.id === chapterId;
                  const doneIn = Array.from({ length: 20 }, (_, i) => start + i).filter(isDone).length;
                  const donePct = Math.round((doneIn / 20) * 100);
                  return (
                    <button
                      key={c.id}
                      type="button"
                      data-chapter={c.id}
                      onClick={() => selectChapter(c.id)}
                      disabled={locked}
                      aria-label={`Monde ${c.id} — ${c.name}${locked ? ' (verrouillé)' : ''}`}
                      aria-pressed={active}
                      className={`relative w-[148px] shrink-0 overflow-hidden rounded-2xl border p-3 text-left transition active:scale-[0.97] ${
                        active
                          ? '-translate-y-0.5 border-white/30 bg-[#241f18] shadow-[0_14px_32px_rgba(0,0,0,0.5),inset_0_1px_0_rgba(255,255,255,0.07)]'
                          : locked
                            ? 'border-white/5 bg-white/[0.02] opacity-50'
                            : 'border-white/10 bg-white/[0.04] hover:-translate-y-0.5 hover:border-white/25'
                      }`}
                    >
                      {/* liseré d'accent du monde */}
                      <span
                        aria-hidden
                        className="absolute inset-x-0 top-0 h-[3px]"
                        style={{ background: `linear-gradient(90deg, ${hex(c.accent)}, ${hex(c.accent2)})` }}
                      />
                      <div className="flex items-center justify-between">
                        <span className="text-[8px] font-bold uppercase tracking-[0.18em] text-[#98907f]">
                          Monde {c.id}
                        </span>
                        {locked ? (
                          <span aria-hidden className="flex h-6 w-6 items-center justify-center rounded-full bg-white/5">
                            <Lock size={11} className="text-[#6e675c]" />
                          </span>
                        ) : (
                          <span
                            aria-hidden
                            className="relative flex h-6 w-6 items-center justify-center rounded-full"
                            style={{ background: `conic-gradient(${hex(c.accent2)} ${donePct}%, rgba(255,255,255,0.1) 0)` }}
                          >
                            <span className="flex h-[17px] w-[17px] items-center justify-center rounded-full bg-[#1e1c18] text-[7.5px] font-bold tabular-nums text-white">
                              {doneIn}
                            </span>
                          </span>
                        )}
                      </div>
                      <div className={`mt-2 truncate font-display text-xs ${locked ? 'text-[#6e675c]' : 'text-white'}`}>
                        {c.name}
                      </div>
                      <div className="mt-2.5 h-1 w-full overflow-hidden rounded-full bg-white/10">
                        <div
                          className="h-full rounded-full transition-all"
                          style={{
                            width: `${donePct}%`,
                            background: `linear-gradient(90deg, ${hex(c.accent)}, ${hex(c.accent2)})`,
                          }}
                        />
                      </div>
                      {!locked && Array.from({ length: 20 }, (_, i) => start + i).every(isDone) && (
                        <span
                          aria-hidden
                          className="absolute bottom-2.5 right-2.5 text-[11px]"
                        >
                          🌟
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* ----- Grille des 20 niveaux du monde ----- */}
            <div className="mt-3 rounded-2xl border border-white/10 bg-[#1e1c18]/80 p-4">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <span
                    aria-hidden
                    className="h-3 w-3 rounded-full ring-2 ring-white/10"
                    style={{ background: `linear-gradient(135deg, ${hex(selectedChapter.accent)}, ${hex(selectedChapter.accent2)})` }}
                  />
                  <span className="font-display text-xs uppercase tracking-[0.12em] text-white">
                    Monde {selectedChapter.id} — {selectedChapter.name}
                  </span>
                </div>
                <div className="flex items-center gap-2.5">
                  <span className="text-[10px] font-semibold uppercase tracking-widest text-[#98907f]">
                    {selectedChapter.tagline}
                  </span>
                  <span className="rounded-full border border-white/10 bg-white/[0.06] px-2.5 py-0.5 text-[10px] font-bold tabular-nums text-[#c0b8a8]">
                    {chapterDoneCount}/20
                  </span>
                </div>
              </div>

              {chapterLocked ? (
                <div className="flex flex-col items-center gap-2.5 py-8 text-center">
                  <span aria-hidden className="flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-white/5">
                    <Lock size={18} aria-hidden className="text-[#6e675c]" />
                  </span>
                  <p className="text-xs font-semibold text-[#98907f]">
                    Terminez les défis du monde {chapterId - 1} pour débloquer ce monde
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-5 gap-2.5 sm:grid-cols-10">
                  {chapterLevels.map((lv) => {
                    const done = isDone(lv.id);
                    const locked = lv.id > highestUnlocked;
                    const current = lv.id === highestUnlocked && !done;
                    const selected = selectedId === lv.id;
                    return (
                      <button
                        key={lv.id}
                        type="button"
                        onClick={() => setSelectedId(lv.id)}
                        aria-label={`Défi ${lv.id} — ${lv.name}${locked ? ' (verrouillé)' : done ? ' (réussi)' : ' (à jouer)'}`}
                        aria-pressed={selected}
                        className={`relative flex aspect-square items-center justify-center rounded-xl border font-display text-sm transition active:scale-95 ${
                          locked
                            ? 'border-white/10 bg-white/5 text-[#6e675c] opacity-60'
                            : done
                              ? 'border-emerald-400/40 bg-gradient-to-b from-emerald-400/25 to-emerald-700/10 text-emerald-100 shadow-[inset_0_1px_0_rgba(255,255,255,0.12)] hover:border-emerald-400/70'
                              : lv.isBoss
                                ? 'border-amber-400/70 bg-gradient-to-b from-amber-400/30 to-amber-700/15 text-amber-100 shadow-[0_0_18px_rgba(255,201,74,0.35),inset_0_1px_0_rgba(255,255,255,0.2)]'
                                : 'border-[#ff9a7e]/50 bg-gradient-to-b from-[#e56a56] to-[#bd3e2d] text-white shadow-[0_0_18px_rgba(212,87,75,0.45),inset_0_1px_0_rgba(255,255,255,0.3)]'
                        } ${selected ? 'ring-2 ring-[#ffc94a]/70 ring-offset-2 ring-offset-[#1e1c18]' : ''}`}
                      >
                        {current && (
                          <span
                            aria-hidden
                            className="pointer-events-none absolute -inset-[4px] animate-pulse rounded-xl border-2 border-[#d4574b]/60"
                          />
                        )}
                        {locked ? (
                          <Lock size={14} aria-hidden />
                        ) : done ? (
                          <span aria-hidden className="text-base leading-none">
                            {CHALLENGE_EMOJI[lv.type]}
                          </span>
                        ) : (
                          lv.id
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Briefing mission (carte de détail) */}
            <div className="panel-hi mt-3 overflow-hidden rounded-2xl border border-white/10 bg-[#1e1c18]/80">
              <div
                aria-hidden
                className="h-1 w-full"
                style={{ background: `linear-gradient(90deg, ${hex(selectedChapter.accent)}, ${hex(selectedChapter.accent2)})` }}
              />
              <div className="flex flex-col gap-5 p-4 sm:p-5 lg:flex-row lg:items-center">
                <div className="flex min-w-0 flex-1 items-start gap-4">
                  <div
                    aria-hidden
                    className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl border border-white/10 shadow-[inset_0_1px_0_rgba(255,255,255,0.1)]"
                    style={
                      blLocked
                        ? undefined
                        : blDone
                          ? { background: 'linear-gradient(160deg, rgba(52,211,153,0.3), rgba(6,78,59,0.35))' }
                          : { background: `linear-gradient(160deg, ${hex(selectedChapter.accent)}55, rgba(20,18,15,0.6))` }
                    }
                  >
                    {blLocked ? (
                      <Lock size={24} aria-hidden className="text-[#6e675c]" />
                    ) : (
                      <span aria-hidden className="text-3xl leading-none">
                        {CHALLENGE_EMOJI[selectedLv.type]}
                      </span>
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="text-[9px] font-bold uppercase tracking-[0.3em] text-[#98907f]">
                      Défi {selectedLv.id} · Monde {selectedChapter.id}
                    </div>
                    <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-1">
                      <h3 className="font-display text-lg text-white sm:text-xl">{selectedLv.name}</h3>
                      <Stars count={selectedLv.stars} done={blDone} size={12} />
                      {selectedLv.isBoss && (
                        <span className="flex items-center gap-1 rounded-full border border-amber-400/50 bg-amber-400/15 px-2.5 py-1 text-[10px] font-black uppercase tracking-wider text-amber-300">
                          <Crown size={11} aria-hidden /> Boss
                        </span>
                      )}
                    </div>
                    <p className="mt-1.5 text-xs leading-relaxed text-[#b5ac9c]">{selectedLv.description}</p>
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      <span className={metaChip}>{CHALLENGE_LABEL[selectedLv.type]}</span>
                      <span className={metaChip}>{blObjective}</span>
                      {selectedLv.type !== 'survival' && <span className={metaChip}>Limite {selectedLv.timeLimit} s</span>}
                      <span className={metaChip}>Obstacles : {selectedLv.obstacleCount}</span>
                      <span className={`rounded-full border px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider ${TIER_CHIP[tier]}`}>
                        {tier}
                      </span>
                    </div>
                    {blLocked && (
                      <p className="mt-2.5 flex items-center gap-1.5 text-[11px] font-semibold text-[#98907f]">
                        <Lock size={12} aria-hidden /> Terminez le défi {selectedLv.id - 1} pour le débloquer
                      </p>
                    )}
                  </div>
                </div>

                {/* Récompense + CTA */}
                <div className="flex shrink-0 flex-col items-stretch gap-3 lg:w-56">
                  <div className="rounded-xl border border-amber-400/25 bg-gradient-to-b from-amber-400/[0.14] to-transparent p-3">
                    <div className="text-[8px] font-bold uppercase tracking-[0.3em] text-amber-300/80">
                      Récompense
                    </div>
                    <div className="mt-1.5 flex items-center gap-2.5">
                      <Coin size={30} />
                      <span className="font-display text-xl tabular-nums text-amber-100">
                        +{blDone ? replayXp : selectedLv.xpReward}
                      </span>
                      <span className="text-[10px] font-bold uppercase tracking-widest text-amber-200/70">XP</span>
                    </div>
                    {blDone && (
                      <p className="mt-1 text-[10px] font-semibold text-emerald-200/70">
                        Première réussite : +{selectedLv.xpReward} XP
                      </p>
                    )}
                  </div>
                  {blLocked ? (
                    <button
                      type="button"
                      disabled
                      className="flex min-h-[44px] cursor-not-allowed items-center justify-center gap-2 rounded-xl bg-white/5 px-4 text-xs font-bold text-[#6e675c]"
                    >
                      <Lock size={14} aria-hidden /> Terminez le défi {selectedLv.id - 1}
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => onPlay(selectedLv)}
                      disabled={busy}
                      className="btn-shine flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-gradient-to-b from-[#e56a56] to-[#bd3e2d] px-6 font-display text-sm uppercase tracking-[0.14em] text-white shadow-[0_10px_28px_rgba(212,87,75,0.4),inset_0_1px_0_rgba(255,255,255,0.35)] ring-1 ring-[#ff9a7e]/40 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
                    >
                      {blDone ? <RotateCcw size={15} aria-hidden /> : <Play size={15} aria-hidden />}
                      {blDone ? 'Rejouer' : 'Jouer'}
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ============================================================
            2. MISSIONS DU JOUR
        ============================================================ */}
        <section className="mt-10" aria-label="Missions du jour">
          <SectionHeader
            icon={Flame}
            title="Missions du jour"
            meta={`${DAILIES.filter((d) => dailyClaimable(d, dailies) && !dailies.claimed.includes(d.id)).length} prête(s)`}
          />
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {DAILIES.map((def) => {
              const prog = Math.min(dailies.progress[def.id], def.target);
              const pct = Math.min(100, Math.round((prog / def.target) * 100));
              const done = dailyDone(def, dailies);
              const claimable = dailyClaimable(def, dailies);
              const claimed = dailies.claimed.includes(def.id);
              return (
                <article
                  key={def.id}
                  className={`relative flex flex-col gap-3 overflow-hidden rounded-2xl border p-4 backdrop-blur-xl transition ${
                    claimable
                      ? 'glow-pulse border-amber-400/50 bg-[#241f16]/85 shadow-[0_0_36px_rgba(255,201,74,0.12)]'
                      : claimed
                        ? 'border-emerald-400/25 bg-[#1c1a16]/75'
                        : 'border-white/10 bg-[#1e1c18]/75'
                  }`}
                >
                  {claimable && (
                    <span className="pop-in absolute right-3 top-3 rounded-full bg-gradient-to-r from-amber-400 to-amber-500 px-2 py-0.5 text-[8px] font-black uppercase tracking-[0.14em] text-[#3a2c05] shadow-[0_4px_12px_rgba(255,201,74,0.4)]">
                      Prêt
                    </span>
                  )}
                  <div className="flex items-center gap-3">
                    <span
                      aria-hidden
                      className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-gradient-to-b from-white/10 to-transparent text-lg shadow-[inset_0_1px_0_rgba(255,255,255,0.1)]"
                    >
                      {def.emoji}
                    </span>
                    <div className="min-w-0 pr-12">
                      <div className="text-[8px] font-bold uppercase tracking-[0.25em] text-[#98907f]">Mission</div>
                      <span className="block text-xs font-bold leading-snug text-white">{def.label}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/10">
                      <div
                        className={`h-full rounded-full transition-all ${
                          claimed ? 'bg-emerald-400' : claimable ? 'bar-sheen bg-[#ffc94a]' : 'bg-gradient-to-r from-[#d4574b] to-[#ffc94a]'
                        }`}
                        style={{ width: `${done ? 100 : pct}%` }}
                      />
                    </div>
                    <span className="text-[10px] font-bold tabular-nums text-[#98907f]">
                      {prog}/{def.target}
                    </span>
                  </div>
                  <div className="mt-auto flex items-center justify-between gap-2">
                    <span className="flex items-center gap-1.5 text-[11px] font-bold tabular-nums text-amber-300">
                      <Zap size={11} aria-hidden className="fill-amber-300" />+{def.xp} XP
                    </span>
                    {claimable ? (
                      <button
                        type="button"
                        onClick={() => onClaimDaily(def)}
                        disabled={busy}
                        className="btn-shine min-h-[40px] rounded-lg bg-gradient-to-b from-amber-300 to-amber-500 px-4 font-display text-[11px] uppercase tracking-[0.12em] text-[#3a2c05] shadow-[0_6px_18px_rgba(255,201,74,0.35),inset_0_1px_0_rgba(255,255,255,0.5)] transition hover:brightness-105 active:scale-95 disabled:opacity-50"
                      >
                        Réclamer
                      </button>
                    ) : claimed ? (
                      <span className="flex min-h-[40px] items-center gap-1 rounded-lg border border-emerald-400/30 bg-emerald-400/10 px-3 text-[11px] font-bold text-emerald-300">
                        <Check size={13} aria-hidden /> Reçu
                      </span>
                    ) : (
                      <span className="flex min-h-[40px] items-center rounded-lg bg-white/5 px-3 text-[11px] font-semibold text-[#98907f]">
                        En cours
                      </span>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
          <p className="mt-3 text-center text-[10px] uppercase tracking-[0.18em] text-[#6e675c]">
            Les missions se renouvellent chaque jour
          </p>
        </section>

        {/* ============================================================
            3. BONUS QUOTIDIEN (pub rewarded)
        ============================================================ */}
        <section className="mt-10" aria-label="Bonus quotidien">
          <SectionHeader icon={Sparkles} title="Bonus quotidien" />
          <div className="panel-hi relative overflow-hidden rounded-3xl border border-amber-400/25">
            <div aria-hidden className="absolute inset-0 bg-gradient-to-r from-[#2e2617] via-[#241f16] to-[#1a1713]" />
            <div
              aria-hidden
              className="absolute inset-0 opacity-40"
              style={{ background: 'radial-gradient(500px 220px at 12% 0%, rgba(255,201,74,0.25), transparent 60%)' }}
            />
            <span
              aria-hidden
              className="absolute inset-y-0 left-0 w-1.5 bg-gradient-to-b from-amber-300 via-[#d4574b]/70 to-transparent"
            />
            <div className="relative flex flex-col gap-4 p-5 pl-6 sm:flex-row sm:items-center sm:justify-between sm:p-6">
              <div className="flex items-center gap-4">
                <div className="float-soft glow-pulse flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-b from-amber-300/25 to-amber-600/10 text-amber-300 ring-1 ring-amber-300/40">
                  <Gift size={24} aria-hidden />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-display text-base text-white">Cadeau du labo</span>
                    <span className="rounded-full border border-amber-400/30 bg-amber-400/10 px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest text-amber-300">
                      1× / jour
                    </span>
                  </div>
                  <p className="mt-0.5 text-xs text-[#b5ac9c]">
                    Regardez une publicité CrazyGames et recevez <span className="font-bold text-amber-300">+60 XP</span>{' '}
                    immédiatement.
                  </p>
                </div>
              </div>
              {player.canClaimAdBonus ? (
                <button
                  type="button"
                  onClick={onClaimBonus}
                  disabled={busy}
                  className="btn-shine flex min-h-[44px] shrink-0 items-center justify-center gap-2 rounded-xl bg-gradient-to-b from-amber-300 to-amber-500 px-6 font-display text-sm uppercase tracking-[0.12em] text-[#3a2c05] shadow-[0_8px_24px_rgba(255,201,74,0.35),inset_0_1px_0_rgba(255,255,255,0.5)] transition hover:brightness-105 active:scale-95 disabled:opacity-50"
                >
                  <Clapperboard size={16} aria-hidden /> Regarder la pub
                </button>
              ) : (
                <div className="flex min-h-[44px] shrink-0 items-center gap-2 rounded-xl border border-white/10 bg-black/30 px-5 text-xs font-semibold text-[#98907f]">
                  Reviens dans {player.nextAdBonusAt ? fmtCountdown(player.nextAdBonusAt) : '—'}
                </div>
              )}
            </div>
          </div>
        </section>

        {/* ---------- Note publicitaires ---------- */}
        <div className="mt-10 flex items-center justify-center gap-3">
          <span aria-hidden className="h-px w-16 bg-gradient-to-r from-transparent to-white/10" />
          <p className="text-center text-[10px] uppercase tracking-[0.2em] text-[#6e675c]">
            Publicités fournies exclusivement par le SDK CrazyGames
          </p>
          <span aria-hidden className="h-px w-16 bg-gradient-to-l from-transparent to-white/10" />
        </div>
      </div>
    </div>
  );
}
