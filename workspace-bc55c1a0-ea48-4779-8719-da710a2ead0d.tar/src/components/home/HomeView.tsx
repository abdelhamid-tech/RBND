'use client';

/* ============================================================
   Accueil — orchestrateur de sous-vues plein écran.
   Vue par défaut : HeroHome (arène 3D héro plein écran).
   Sous-vues : Garage 3D, Campagne (défis + missions + bonus),
   Multijoueur. Même contrat de props qu'avant : page.tsx ne
   change pas.
============================================================ */

import { useEffect, useMemo, useState } from 'react';
import HeroHome from '@/components/home/HeroHome';
import CampaignView from '@/components/home/CampaignView';
import BallGarage from '@/components/home/BallGarage';
import MultiplayerView from '@/components/multiplayer/MultiplayerView';
import { BALLS } from '@/lib/game/balls';
import { LEVELS, TOTAL_LEVELS } from '@/lib/game/levels';
import type { DailyDef, DailyState } from '@/lib/game/dailies';
import type { BallDef, LevelDef, PlayerDTO } from '@/lib/game/types';

interface Props {
  player: PlayerDTO;
  dailies: DailyState;
  onPlay: (level: LevelDef) => void;
  onBuy: (ball: BallDef) => void;
  onSelect: (ball: BallDef) => void;
  onClaimBonus: () => void;
  onClaimDaily: (d: DailyDef) => void;
  busy: boolean;
}

type SubView = null | 'shop' | 'campaign' | 'multiplayer';

export default function HomeView({ player, dailies, onPlay, onBuy, onSelect, onClaimBonus, onClaimDaily, busy }: Props) {
  const [subView, setSubView] = useState<SubView>(null);

  /* ----- ballon équipé + niveau de défi accessible ----- */
  const equippedBall: BallDef = useMemo(
    () => BALLS.find((b) => b.id === player.selectedBall) ?? BALLS[0],
    [player.selectedBall]
  );
  const highestUnlocked = useMemo(() => {
    let n = 1;
    for (let i = 1; i <= TOTAL_LEVELS; i++) {
      if (player.completedLevels.includes(i)) n = i + 1;
      else break;
    }
    return Math.min(n, TOTAL_LEVELS);
  }, [player.completedLevels]);
  const nextLevel: LevelDef = LEVELS[highestUnlocked - 1] ?? LEVELS[0];

  /* ----- garage : index synchronisé avec le ballon équipé ----- */
  const syncedIndex = useMemo(() => {
    const i = BALLS.findIndex((b) => b.id === player.selectedBall);
    return i >= 0 ? i : 0;
  }, [player.selectedBall]);
  const [garageIndex, setGarageIndex] = useState<number>(syncedIndex);
  useEffect(() => {
    // synchronisation différée au frame suivant (évite un rendu en cascade)
    const raf = requestAnimationFrame(() => setGarageIndex(syncedIndex));
    return () => cancelAnimationFrame(raf);
  }, [syncedIndex]);

  /* ---------------- Multijoueur ---------------- */
  if (subView === 'multiplayer') {
    return (
      <MultiplayerView
        ball={equippedBall}
        playerName={`Joueur-${player.id.slice(0, 4).toUpperCase()}`}
        onExit={() => setSubView(null)}
      />
    );
  }

  /* ---------------- Campagne + missions + bonus ---------------- */
  if (subView === 'campaign') {
    return (
      <CampaignView
        player={player}
        dailies={dailies}
        onPlay={onPlay}
        onClaimBonus={onClaimBonus}
        onClaimDaily={onClaimDaily}
        busy={busy}
        onBack={() => setSubView(null)}
      />
    );
  }

  /* ---------------- Garage 3D plein écran ---------------- */
  if (subView === 'shop') {
    return (
      <div className="fixed inset-0 overflow-y-auto bg-[#14120f] text-[#e8e0d0]">
        <div
          aria-hidden
          className="pointer-events-none fixed inset-0"
          style={{
            background: [
              'radial-gradient(1100px 540px at 50% -12%, rgba(212,87,75,0.17), transparent 62%)',
              'radial-gradient(900px 540px at 88% 112%, rgba(255,201,74,0.10), transparent 60%)',
              'radial-gradient(130% 105% at 50% 45%, transparent 55%, rgba(8,7,5,0.5) 100%)',
            ].join(', '),
          }}
        />
        <div className="relative mx-auto flex min-h-full w-full max-w-2xl flex-col justify-center px-4 py-[calc(24px+env(safe-area-inset-top,0px))] pb-[calc(24px+env(safe-area-inset-bottom,0px))] sm:px-6">
          <BallGarage
            balls={BALLS}
            index={garageIndex}
            onIndexChange={setGarageIndex}
            player={player}
            busy={busy}
            onBuy={onBuy}
            onSelect={onSelect}
            onBack={() => setSubView(null)}
          />
        </div>
      </div>
    );
  }

  /* ---------------- Héro 3D plein écran ---------------- */
  return (
    <HeroHome
      player={player}
      onPlay={() => onPlay(nextLevel)}
      onOpenShop={() => setSubView('shop')}
      onOpenCampaign={() => setSubView('campaign')}
      onOpenMultiplayer={() => setSubView('multiplayer')}
      busy={busy}
    />
  );
}
