'use client';

/* ============================================================
   HeroHome — page d'accueil « héro » : l'arène 3D occupe TOUT
   l'écran de bord en bord (aucun panneau ne la masque), le
   ballon du joueur en vedette au centre, gros bouton JOUER,
   nav par icônes en haut.
   Recette de rendu (BallGarage / GameCanvas) : renderer opaque,
   FogExp2 léger, cylindre de fond dégradé, sol brillant +
   grille shader à anneaux pulsants, cônes de lumière fresnel,
   poussière douce, anneau de base, drag-to-spin avec inertie,
   dispose intégral, RAF en pause si document.hidden, DPR ≤ 1.75.
============================================================ */

import { useEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Cylinder, Map, Play, Target, Users, Zap } from 'lucide-react';
import type { BallDef, PlayerDTO } from '@/lib/game/types';
import { BALLS } from '@/lib/game/balls';
import { buildBallTexture } from '@/lib/game/ball-textures';
import { CHALLENGE_EMOJI, LEVELS, TOTAL_LEVELS } from '@/lib/game/levels';

export interface HeroHomeProps {
  player: PlayerDTO;
  onPlay: () => void;
  onOpenShop: () => void;
  onOpenCampaign: () => void;
  onOpenMultiplayer: () => void;
  busy: boolean;
}

/* ---------------- Réglages scène ---------------- */
const BALL_R = 1.35; // rayon du ballon héros
const BALL_Y = 1.55; // hauteur de flottement
const AUTO_SPIN = 0.35; // rad/s — rotation automatique
const BOB_AMP = 0.07; // amplitude du flottement sinusoïdal
const MAX_DPR = 1.75; // pixel ratio plafonné
const DRAG_SENS = 0.012; // radians par pixel de drag
const POP_MS = 350; // durée du « pop » au changement de ballon

/* Cônes de lumière fresnel — répartis PLUS LARGE pour habiller la salle */
const BEAMS: Array<{
  x: number;
  z: number;
  rb: number; // rayon bas
  intensity: number;
  color: number;
  speed: number;
  phase: number;
}> = [
  { x: -5.2, z: -4.5, rb: 2.0, intensity: 0.2, color: 0xfff1dc, speed: 1.3, phase: 0.0 },
  { x: 5.4, z: -3.6, rb: 2.6, intensity: 0.16, color: 0xffb35c, speed: 1.7, phase: 1.4 },
  { x: -1.2, z: -8.2, rb: 3.4, intensity: 0.14, color: 0xd4574b, speed: 1.1, phase: 2.6 },
  { x: 3.4, z: -2.4, rb: 4.2, intensity: 0.18, color: 0xfff1dc, speed: 1.9, phase: 4.1 },
];

/** État Three.js partagé entre l'effet de montage et les rebuilds de ballon */
interface HeroScene {
  renderer: THREE.WebGLRenderer;
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  pmrem: THREE.PMREMGenerator;
  envTex: THREE.Texture;
  ballGroup: THREE.Group;
  shadow: THREE.Mesh<THREE.PlaneGeometry, THREE.MeshBasicMaterial>;
  ring: THREE.Mesh<THREE.TorusGeometry, THREE.MeshBasicMaterial>;
  gridUniforms: {
    uGrid: { value: THREE.Color };
    uGlow: { value: THREE.Color };
    uTime: { value: number };
  };
  beams: Array<{ mat: THREE.ShaderMaterial; base: number; speed: number; phase: number }>;
  clock: THREE.Clock;
  ballId: string | null;
  rotY: number;
  spinVel: number;
  dragging: boolean;
  /** timestamp du début du pop, -1 = inactif */
  popStart: number;
  /** compteur de génération : invalide les textures async obsolètes */
  gen: number;
  /** ballon arc-en-ciel : teintes animées */
  rainbow: boolean;
  /** matériau du ballon courant (pour l'anim arc-en-ciel) */
  mat: THREE.MeshPhysicalMaterial | null;
  /** coquille de lueur courante */
  glowUniforms: { uPower: { value: number }; uColor: { value: THREE.Color } } | null;
}

/* ---------------- Helpers de disposal ---------------- */

function disposeMaterial(mat: THREE.Material): void {
  const maybeMapped = mat as THREE.MeshPhysicalMaterial;
  if (maybeMapped.map) maybeMapped.map.dispose();
  mat.dispose();
}

function disposeTree(root: THREE.Object3D): void {
  root.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (mesh.geometry) mesh.geometry.dispose();
    const mat = mesh.material;
    if (Array.isArray(mat)) {
      for (const m of mat) disposeMaterial(m);
    } else if (mat) {
      disposeMaterial(mat);
    }
  });
}

/** Texture douce (dégradé radial) pour les sprites de poussière */
function makeSoftTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 32;
  c.height = 32;
  const g = c.getContext('2d');
  if (g) {
    const rg = g.createRadialGradient(16, 16, 1, 16, 16, 15);
    rg.addColorStop(0, 'rgba(255,255,255,0.9)');
    rg.addColorStop(0.5, 'rgba(255,255,255,0.35)');
    rg.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = rg;
    g.fillRect(0, 0, 32, 32);
  }
  return new THREE.CanvasTexture(c);
}

/**
 * (Re)construit le ballon héros depuis un BallDef — mêmes réglages
 * de matériau / texture / lueur que GameCanvas et BallGarage.
 */
function applyBall(ctx: HeroScene, ball: BallDef): void {
  // Libère l'ancien ballon (géométries / matériaux / textures)
  const old = [...ctx.ballGroup.children];
  ctx.ballGroup.clear();
  for (const child of old) disposeTree(child);

  ctx.gen += 1;
  const gen = ctx.gen;
  ctx.ballId = ball.id;

  const ballOpacity = ball.opacity ?? 1;
  const mat = new THREE.MeshPhysicalMaterial({
    color: ball.color,
    roughness: ball.roughness,
    metalness: ball.metalness,
    clearcoat: ball.clearcoat,
    clearcoatRoughness: ball.clearcoatRoughness,
    emissive: new THREE.Color(ball.emissive),
    emissiveIntensity: ball.emissiveIntensity,
    envMapIntensity: 1.15,
    transparent: ballOpacity < 1,
    opacity: ballOpacity,
  });
  ctx.mat = mat;
  ctx.rainbow = !!ball.rainbow;
  ctx.ballGroup.add(new THREE.Mesh(new THREE.SphereGeometry(BALL_R, 48, 32), mat));

  // Texture : procédurale (canvas) ou fichier public — chargement async
  void (async () => {
    try {
      let tex: THREE.Texture | null = null;
      if (ball.procTex) {
        tex = new THREE.CanvasTexture(buildBallTexture(ball.procTex));
      } else if (ball.texture) {
        tex = await new THREE.TextureLoader().loadAsync(ball.texture);
      }
      if (!tex) return;
      if (gen !== ctx.gen) {
        tex.dispose(); // un autre ballon a été affiché entre-temps
        return;
      }
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = Math.min(8, ctx.renderer.capabilities.getMaxAnisotropy());
      mat.map = tex;
      mat.color.set(0xffffff);
      mat.needsUpdate = true;
    } catch {
      /* texture manquante : couleur unie */
    }
  })();

  // Coquille de lueur fresnel additive — même shader que le jeu
  const glowUniforms = {
    uPower: { value: ball.glowPower },
    uColor: { value: new THREE.Color(ball.glowColor) },
  };
  ctx.glowUniforms = glowUniforms;
  const glowMat = new THREE.ShaderMaterial({
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    uniforms: glowUniforms,
    vertexShader:
      'varying float vF; void main(){ vec3 n=normalize(normalMatrix*normal); vec4 mv=modelViewMatrix*vec4(position,1.0); vec3 vd=normalize(-mv.xyz); vF=pow(1.0-abs(dot(n,vd)),2.2); gl_Position=projectionMatrix*mv; }',
    fragmentShader:
      'uniform float uPower; uniform vec3 uColor; varying float vF; void main(){ gl_FragColor=vec4(uColor, vF*uPower); }',
  });
  ctx.ballGroup.add(new THREE.Mesh(new THREE.SphereGeometry(BALL_R * 1.16, 32, 24), glowMat));

  // Lumière interne (météore / néon) — même règle que le jeu
  ctx.ballGroup.add(
    new THREE.PointLight(ball.glowColor, ball.fireParticles ? 14 : ball.glowPower > 1 ? 8 : 0, 14, 2)
  );

  // « Pop » d'apparition (1 → 0.84 → 1)
  ctx.popStart = performance.now();
  ctx.ballGroup.scale.setScalar(1);
}

/* ============================================================ */

export default function HeroHome({ player, onPlay, onOpenShop, onOpenCampaign, onOpenMultiplayer, busy }: HeroHomeProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const ctxRef = useRef<HeroScene | null>(null);

  /* ---------- Montage de la scène (une seule fois) ---------- */
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const w0 = Math.max(1, container.clientWidth);
    const h0 = Math.max(1, container.clientHeight);

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.06;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, MAX_DPR));
    renderer.setSize(w0, h0);
    renderer.setClearColor(0x0a0807, 1); // opaque : la scène remplit tout l'écran
    const el = renderer.domElement;
    el.style.display = 'block';
    el.style.touchAction = 'none';
    el.style.cursor = 'grab';
    el.setAttribute('aria-hidden', 'true');
    container.appendChild(el);

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x0a0807, 0.032); // plus léger qu'en garage : la salle respire
    const camera = new THREE.PerspectiveCamera(56, w0 / h0, 0.1, 120);

    // Environnement pour les reflets (métal / clearcoat) — même pattern que le jeu
    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;

    /* ---------- Lumières ---------- */
    scene.add(new THREE.HemisphereLight(0xfff4e0, 0x2a231a, 0.5));
    const key = new THREE.SpotLight(0xfff1dc, 300, 60, Math.PI / 4.5, 0.5, 2);
    key.position.set(0.5, 10, 4);
    key.target.position.set(0, 1.2, 0);
    scene.add(key);
    scene.add(key.target);
    const rimTerra = new THREE.PointLight(0xd4574b, 40, 30, 2);
    rimTerra.position.set(-6.5, 3, -4);
    scene.add(rimTerra);
    const rimAmber = new THREE.PointLight(0xffb35c, 30, 30, 2);
    rimAmber.position.set(6, 3.4, -5);
    scene.add(rimAmber);

    /* ---------- Cylindre de fond (dégradé vertical, BackSide) ---------- */
    const bgMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        uBottom: { value: new THREE.Color('#1a1410') },
        uTop: { value: new THREE.Color('#070606') },
      },
      vertexShader:
        'varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader:
        'uniform vec3 uBottom; uniform vec3 uTop; varying vec2 vUv;' +
        'void main(){ gl_FragColor=vec4(mix(uBottom, uTop, smoothstep(0.0, 1.0, vUv.y)), 1.0); }',
    });
    const backdrop = new THREE.Mesh(new THREE.CylinderGeometry(46, 46, 30, 48, 1, true), bgMat);
    backdrop.position.y = 8;
    scene.add(backdrop);

    /* ---------- Sol brillant ---------- */
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(150, 150),
      new THREE.MeshStandardMaterial({ color: 0x151210, roughness: 0.55, metalness: 0.35, envMapIntensity: 0.35 })
    );
    floor.rotation.x = -Math.PI / 2;
    scene.add(floor);

    /* ---------- Grille shader : lignes + anneaux pulsants, fondu de bord étendu ---------- */
    const gridUniforms = {
      uGrid: { value: new THREE.Color('#cbb79a') },
      uGlow: { value: new THREE.Color('#d4574b') },
      uTime: { value: 0 },
    };
    const gridMat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      uniforms: gridUniforms,
      vertexShader:
        'varying vec2 vXY;' +
        'void main(){ vec4 wp=modelMatrix*vec4(position,1.0); vXY=wp.xz; gl_Position=projectionMatrix*viewMatrix*wp; }',
      fragmentShader:
        'uniform vec3 uGrid; uniform vec3 uGlow; uniform float uTime; varying vec2 vXY;' +
        'void main(){' +
        '  float d=length(vXY);' +
        '  vec2 gp=vXY*0.5;' +
        '  vec2 gv=abs(fract(gp-0.5)-0.5)/fwidth(gp);' +
        '  float g=1.0-min(min(gv.x,gv.y),1.0);' +
        '  float r1=exp(-abs(d-2.8)*6.0)*(0.38+0.14*sin(uTime*2.1));' +
        '  float r2=exp(-abs(d-6.4)*5.0)*(0.26+0.10*sin(uTime*1.7+1.9));' +
        '  float halo=exp(-d*0.30)*0.20;' +
        '  float edge=1.0-smoothstep(16.0,36.0,d);' +
        '  vec3 col=uGrid*(g*0.11*edge)+uGlow*((r1+r2+halo)*edge);' +
        '  gl_FragColor=vec4(col,1.0);' +
        '}',
    });
    const grid = new THREE.Mesh(new THREE.PlaneGeometry(130, 130), gridMat);
    grid.rotation.x = -Math.PI / 2;
    grid.position.y = 0.025;
    grid.renderOrder = 2;
    scene.add(grid);

    /* ---------- 4 cônes de lumière fresnel (volumétriques) ---------- */
    const beams: HeroScene['beams'] = [];
    const beamVert =
      'varying float vF; varying vec2 vUv;' +
      'void main(){ vUv=uv; vec3 n=normalize(normalMatrix*normal); vec4 mv=modelViewMatrix*vec4(position,1.0); vec3 vd=normalize(-mv.xyz); vF=pow(1.0-abs(dot(n,vd)),1.6); gl_Position=projectionMatrix*mv; }';
    const beamFrag =
      'uniform vec3 uColor; uniform float uIntensity; varying float vF; varying vec2 vUv;' +
      'void main(){ float a=vF*uIntensity*(0.3+0.7*vUv.y); gl_FragColor=vec4(uColor, a); }';
    for (const b of BEAMS) {
      const mat = new THREE.ShaderMaterial({
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.DoubleSide,
        uniforms: {
          uColor: { value: new THREE.Color(b.color) },
          uIntensity: { value: b.intensity },
        },
        vertexShader: beamVert,
        fragmentShader: beamFrag,
      });
      const cone = new THREE.Mesh(new THREE.CylinderGeometry(b.rb * 0.38, b.rb, 14, 24, 1, true), mat);
      cone.position.set(b.x, 7, b.z);
      scene.add(cone);
      beams.push({ mat, base: b.intensity, speed: b.speed, phase: b.phase });
    }

    /* ---------- Poussière douce (sprites, dérive lente) ---------- */
    const dustCount = 260;
    const dustPos = new Float32Array(dustCount * 3);
    for (let i = 0; i < dustCount; i++) {
      dustPos[i * 3] = (Math.random() * 2 - 1) * 15; // spread x 30
      dustPos[i * 3 + 1] = Math.random() * 9; // spread y 9
      dustPos[i * 3 + 2] = (Math.random() * 2 - 1) * 10; // spread z 20
    }
    const dustGeo = new THREE.BufferGeometry();
    dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPos, 3));
    const dustMat = new THREE.PointsMaterial({
      map: makeSoftTexture(),
      color: 0xd8c8a8,
      size: 0.22,
      transparent: true,
      opacity: 0.4,
      depthWrite: false,
      sizeAttenuation: true,
      blending: THREE.AdditiveBlending,
    });
    const dust = new THREE.Points(dustGeo, dustMat);
    scene.add(dust);

    /* ---------- Anneau de base pulsant sous le ballon ---------- */
    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(3.3, 0.03, 10, 96),
      new THREE.MeshBasicMaterial({
        color: 0xd4574b,
        transparent: true,
        opacity: 0.7,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.035;
    ring.renderOrder = 3;
    scene.add(ring);

    /* ---------- Ombre de contact sous le ballon (dégradé radial canvas) ---------- */
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 128;
    shadowCanvas.height = 128;
    const sg = shadowCanvas.getContext('2d');
    if (sg) {
      const rg = sg.createRadialGradient(64, 64, 4, 64, 64, 62);
      rg.addColorStop(0, 'rgba(0,0,0,0.85)');
      rg.addColorStop(1, 'rgba(0,0,0,0)');
      sg.fillStyle = rg;
      sg.fillRect(0, 0, 128, 128);
    }
    const shadow = new THREE.Mesh(
      new THREE.PlaneGeometry(5.2, 5.2),
      new THREE.MeshBasicMaterial({
        map: new THREE.CanvasTexture(shadowCanvas),
        transparent: true,
        depthWrite: false,
        opacity: 0.62,
      })
    );
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.y = 0.015;
    shadow.renderOrder = 1;
    scene.add(shadow);

    /* ---------- Ballon héros ---------- */
    const ballGroup = new THREE.Group();
    ballGroup.position.set(0, BALL_Y, 0);
    scene.add(ballGroup);

    const ctx: HeroScene = {
      renderer, scene, camera, pmrem, envTex, ballGroup, shadow, ring,
      gridUniforms, beams, clock: new THREE.Clock(), ballId: null, rotY: 0, spinVel: 0,
      dragging: false, popStart: -1, gen: 0, rainbow: false, mat: null, glowUniforms: null,
    };
    ctxRef.current = ctx;

    /* ---------- Caméra : recule ET élargit (portrait vs paysage) ---------- */
    const layoutCamera = () => {
      const w = Math.max(1, container.clientWidth);
      const h = Math.max(1, container.clientHeight);
      if (w < 2 || h < 2) return;
      camera.aspect = w / h;
      if (camera.aspect < 0.95) camera.position.set(0, 2.7, 8.6); // portrait
      else camera.position.set(0, 2.2, 9.6); // paysage : reculé pour montrer la salle
      camera.lookAt(0, 1.05, 0);
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    layoutCamera();

    /* ---------- Drag horizontal avec inertie ---------- */
    let lastX = 0;
    let lastMoveT = 0;
    const onDown = (e: PointerEvent) => {
      ctx.dragging = true;
      lastX = e.clientX;
      el.style.cursor = 'grabbing';
      try {
        el.setPointerCapture(e.pointerId);
      } catch {
        /* pointeur déjà relâché */
      }
    };
    const onMove = (e: PointerEvent) => {
      if (!ctx.dragging) return;
      const dx = e.clientX - lastX;
      lastX = e.clientX;
      lastMoveT = performance.now();
      ctx.rotY += dx * DRAG_SENS;
      ctx.spinVel = THREE.MathUtils.clamp(dx * DRAG_SENS * 60, -8, 8);
    };
    const onUp = (e: PointerEvent) => {
      if (!ctx.dragging) return;
      ctx.dragging = false;
      el.style.cursor = 'grab';
      // arrêt net si le doigt/souris était immobile depuis un moment
      if (performance.now() - lastMoveT > 80) ctx.spinVel = 0;
      try {
        el.releasePointerCapture(e.pointerId);
      } catch {
        /* déjà relâché */
      }
    };
    el.addEventListener('pointerdown', onDown);
    el.addEventListener('pointermove', onMove);
    el.addEventListener('pointerup', onUp);
    el.addEventListener('pointercancel', onUp);

    /* ---------- Resize ---------- */
    const ro = new ResizeObserver(layoutCamera);
    ro.observe(container);

    /* ---------- Boucle de rendu ---------- */
    let raf = 0;
    const render = () => {
      const dt = Math.min(ctx.clock.getDelta(), 0.05);
      const t = ctx.clock.elapsedTime;

      // rotation : auto + inertie du drag (décroissance exponentielle)
      if (!ctx.dragging) {
        ctx.rotY += AUTO_SPIN * dt + ctx.spinVel * dt;
        ctx.spinVel *= Math.exp(-2.8 * dt);
        if (Math.abs(ctx.spinVel) < 0.02) ctx.spinVel = 0;
      }
      ctx.ballGroup.rotation.y = ctx.rotY;

      // flottement sinusoïdal ±0.07
      const bob = Math.sin(t * 1.5) * BOB_AMP;
      ctx.ballGroup.position.y = BALL_Y + bob;

      // pop d'échelle 1 → 0.84 → 1 (easing sinusoïdal)
      if (ctx.popStart >= 0) {
        const p = (performance.now() - ctx.popStart) / POP_MS;
        if (p >= 1) {
          ctx.popStart = -1;
          ctx.ballGroup.scale.setScalar(1);
        } else {
          ctx.ballGroup.scale.setScalar(1 - 0.16 * Math.sin(Math.PI * Math.max(0, p)));
        }
      }

      // l'ombre respire avec le flottement, l'anneau et les anneaux de grille pulsent
      ctx.shadow.scale.setScalar(1 - bob * 2);
      ctx.shadow.material.opacity = 0.62 - bob * 1.6;
      ctx.ring.material.opacity = 0.5 + 0.3 * Math.sin(t * 2.4);
      ctx.gridUniforms.uTime.value = t;

      // flicker sinusoïdal des cônes de lumière
      for (const b of ctx.beams) {
        b.mat.uniforms.uIntensity.value = b.base * (0.82 + 0.18 * Math.sin(t * b.speed + b.phase));
      }

      // poussière : dérive lente (rotation + flottement en bloc, zéro écriture d'attribut)
      dust.rotation.y = t * 0.012;
      dust.position.y = Math.sin(t * 0.13) * 0.4;

      // ballon arc-en-ciel : teintes animées
      if (ctx.rainbow && ctx.mat && ctx.glowUniforms) {
        const hue = (t * 0.12) % 1;
        ctx.mat.emissive.setHSL(hue, 0.9, 0.55);
        ctx.mat.emissiveIntensity = 1.1;
        ctx.glowUniforms.uColor.value.setHSL(hue, 0.85, 0.6);
      }

      renderer.render(scene, camera);
    };
    const loop = () => {
      raf = requestAnimationFrame(loop);
      if (document.hidden) return; // pause quand l'onglet est masqué
      render();
    };
    raf = requestAnimationFrame(loop);

    /* ---------- Nettoyage intégral ---------- */
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      el.removeEventListener('pointerdown', onDown);
      el.removeEventListener('pointermove', onMove);
      el.removeEventListener('pointerup', onUp);
      el.removeEventListener('pointercancel', onUp);
      ctxRef.current = null;
      disposeTree(scene);
      dustMat.map?.dispose();
      dustMat.dispose();
      dustGeo.dispose();
      envTex.dispose();
      pmrem.dispose();
      renderer.dispose();
      el.remove();
    };
  }, []);

  /* ---------- Rebuild du ballon quand le ballon équipé change ---------- */
  const equippedBall: BallDef = useMemo(
    () => BALLS.find((b) => b.id === player.selectedBall) ?? BALLS[0],
    [player.selectedBall]
  );
  useEffect(() => {
    const ctx = ctxRef.current;
    if (!ctx) return;
    if (ctx.ballId === equippedBall.id) return; // déjà affiché
    applyBall(ctx, equippedBall);
  }, [equippedBall]);

  /* ---------- Dérivés UI ---------- */
  const completedCount = player.completedLevels.length;
  const xpPct = Math.min(100, Math.max(0, Math.round((player.xpIntoLevel / player.xpForNext) * 100)));
  const highestUnlocked = useMemo(() => {
    let n = 1;
    for (let i = 1; i <= TOTAL_LEVELS; i++) {
      if (player.completedLevels.includes(i)) n = i + 1;
      else break;
    }
    return Math.min(n, TOTAL_LEVELS);
  }, [player.completedLevels]);
  const nextLevel = LEVELS[highestUnlocked - 1] ?? LEVELS[0];
  const campaignPct = Math.min(100, Math.round((completedCount / TOTAL_LEVELS) * 100));

  const nav = [
    { key: 'shop', label: 'Garage', Icon: Cylinder, action: onOpenShop },
    { key: 'campaign', label: 'Campagne', Icon: Map, action: onOpenCampaign },
    { key: 'multiplayer', label: 'Multijoueur', Icon: Users, action: onOpenMultiplayer },
    { key: 'missions', label: 'Missions', Icon: Target, action: onOpenCampaign },
  ] as const;

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#0a0807] text-[#e8e0d0]">
      {/* ================= Arène 3D plein écran ================= */}
      <div ref={containerRef} className="absolute inset-0 select-none" />

      {/* Vignette cinéma très légère — l'arène doit dominer */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_58%,rgba(0,0,0,0.35)_100%)]"
      />

      {/* ================= UI flottante (le 3D reste dominant) ================= */}
      <div className="pointer-events-none absolute inset-0 flex flex-col justify-between px-4 pb-[calc(18px+env(safe-area-inset-bottom,0px))] pt-[calc(14px+env(safe-area-inset-top,0px))] sm:px-6">
        {/* ---------- Haut : médaillons + wordmark + nav ---------- */}
        <div className="relative flex justify-center">
          {/* Médaillon niveau (haut gauche) */}
          <div className="absolute left-0 top-0.5">
            <div
              className="flex h-[48px] w-[48px] items-center justify-center rounded-full p-[4px] shadow-[0_8px_24px_rgba(0,0,0,0.5)] ring-1 ring-white/10"
              style={{ background: `conic-gradient(#d4574b ${xpPct}%, rgba(255,255,255,0.08) 0)` }}
              role="img"
              aria-label={`Niveau ${player.level} — progression ${xpPct}%`}
            >
              <div className="flex h-full w-full items-center justify-center rounded-full border border-white/5 bg-[#1c1a16]">
                <span className="font-display text-sm text-white">{player.level}</span>
              </div>
            </div>
          </div>

          {/* Pièce XP (haut droite) */}
          <div className="absolute right-0 top-1 flex items-center gap-2.5 rounded-full border border-amber-400/25 bg-black/40 py-1 pl-1.5 pr-4 backdrop-blur-md">
            <span
              aria-hidden
              className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-b from-amber-300 to-amber-500 shadow-[inset_0_1px_0_rgba(255,255,255,0.55),0_4px_12px_rgba(255,201,74,0.35)] ring-1 ring-amber-200/50"
            >
              <Zap size={14} className="fill-[#4a3405] text-[#4a3405]" />
            </span>
            <span className="font-display text-sm tabular-nums text-amber-100">
              {player.totalXp.toLocaleString('fr-FR')}
            </span>
            <span className="sr-only">XP</span>
          </div>

          {/* Wordmark + nav */}
          <div className="flex flex-col items-center">
            <h1 className="font-display title-3d bg-gradient-to-b from-[#f6efe0] via-[#e8e0d0] to-[#a89e8c] bg-clip-text text-center text-[clamp(2.8rem,9vw,5.2rem)] leading-none tracking-[0.16em] text-transparent">
              RBND
            </h1>
            <div className="mt-2 flex items-center gap-2.5">
              <span aria-hidden className="h-px w-7 bg-gradient-to-r from-transparent to-white/25" />
              <p className="text-center text-[9px] font-bold uppercase tracking-[0.42em] text-[#a89e8c] sm:text-[10px]">
                Laboratoire de physique
              </p>
              <span aria-hidden className="h-px w-7 bg-gradient-to-l from-transparent to-white/25" />
            </div>

            {/* Nav par icônes */}
            <nav aria-label="Navigation principale" className="mt-4 flex items-start justify-center gap-3 sm:gap-6">
              {nav.map((item) => (
                <button
                  key={item.key}
                  type="button"
                  onClick={item.action}
                  disabled={busy}
                  aria-label={item.label}
                  className="pointer-events-auto group flex min-h-[44px] flex-col items-center gap-1.5 transition active:scale-95 disabled:opacity-50"
                >
                  <span className="flex h-[48px] min-h-[48px] w-[48px] min-w-[48px] items-center justify-center rounded-2xl border border-white/10 bg-black/35 text-[#e8e0d0] shadow-[inset_0_1px_0_rgba(255,255,255,0.08),0_10px_24px_rgba(0,0,0,0.35)] backdrop-blur-md transition-all duration-200 group-hover:-translate-y-0.5 group-hover:border-[#d4574b]/50 group-hover:bg-black/55 group-hover:text-white group-hover:shadow-[0_12px_28px_rgba(212,87,75,0.25)]">
                    <item.Icon size={20} aria-hidden />
                  </span>
                  <span className="font-display text-[8px] uppercase tracking-[0.24em] text-[#b5ac9c] transition group-hover:text-white">
                    {item.label}
                  </span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* ---------- Bas : JOUER + billet « prochain défi » ---------- */}
        <div className="flex flex-col items-center gap-3">
          <div className="relative">
            {/* Halo pulsant sous le bouton */}
            <span
              aria-hidden
              className="opacity-glow pointer-events-none absolute -inset-3 rounded-[28px] bg-[#d4574b]/35 blur-xl"
            />
            <button
              type="button"
              onClick={onPlay}
              disabled={busy}
              className="btn-shine pointer-events-auto relative flex min-h-[64px] items-center gap-3 rounded-2xl bg-gradient-to-b from-[#e56a56] to-[#bd3e2d] px-14 text-2xl font-display uppercase tracking-[0.14em] text-white shadow-[0_16px_44px_rgba(212,87,75,0.5),inset_0_1px_0_rgba(255,255,255,0.4)] ring-1 ring-[#ff9a7e]/40 transition hover:brightness-110 active:scale-95 disabled:opacity-50"
            >
              <Play size={24} aria-hidden className="fill-white drop-shadow" />
              Jouer
            </button>
          </div>

          {/* Billet « prochain défi » */}
          <div className="panel-hi pointer-events-none flex max-w-[92vw] items-center gap-3 rounded-2xl border border-white/10 bg-black/40 py-2 pl-2.5 pr-4 backdrop-blur-md sm:gap-4 sm:py-2.5">
            <span
              aria-hidden
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-gradient-to-b from-white/10 to-transparent text-xl"
            >
              {CHALLENGE_EMOJI[nextLevel.type]}
            </span>
            <span aria-hidden className="hidden h-9 w-px bg-white/10 sm:block" />
            <div className="min-w-0 text-left">
              <div className="text-[8px] font-bold uppercase tracking-[0.3em] text-[#ffc94a] sm:text-[9px]">
                Prochain défi — Monde {nextLevel.chapter}
              </div>
              <div className="font-display truncate text-sm leading-tight text-white sm:text-base">
                {nextLevel.name}
              </div>
            </div>
            <span
              aria-hidden
              className="hidden items-center gap-1 rounded-full border border-amber-400/25 bg-amber-400/10 px-2.5 py-1 text-[11px] font-bold tabular-nums text-amber-200 sm:flex"
            >
              <Zap size={11} className="fill-amber-300 text-amber-300" />+{nextLevel.xpReward} XP
            </span>
            <span aria-hidden className="hidden h-9 w-px bg-white/10 sm:block" />
            <div
              className="flex shrink-0 flex-col items-start gap-1.5"
              role="progressbar"
              aria-valuenow={completedCount}
              aria-valuemin={0}
              aria-valuemax={TOTAL_LEVELS}
              aria-label={`${completedCount} défis réussis sur ${TOTAL_LEVELS}`}
            >
              <div className="flex items-center gap-1.5">
                <div className="h-1.5 w-20 overflow-hidden rounded-full bg-white/10 sm:w-24">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-[#d4574b] to-[#ffc94a]"
                    style={{ width: `${campaignPct}%` }}
                  />
                </div>
                <span className="text-[10px] font-bold tabular-nums text-[#c0b8a8]">
                  {completedCount}/{TOTAL_LEVELS}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
