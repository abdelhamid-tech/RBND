'use client';

/* ============================================================
   MultiplayerView — multijoueur RBND (carte ouverte)
   Machine à états : gate (porte CrazyGames) → menu (salles) → arène.

   Arène : terrain 280×280 bruité, lac shader animé, forêts/rochers
   instanciés, lucioles, ciel dégradé + brouillard, bord du monde
   (poteaux lumineux + rappel douce), joueur local (physique maison,
   recette ballon GameCanvas), joueurs distants lissés (snaps 15 Hz),
   étiquettes pseudo + bulles de chat, HUD React (chat/report, salle,
   latence, quit) — socket.io unique via /?XTransformPort=3003.
============================================================ */

import { useCallback, useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { io } from 'socket.io-client';
import {
  Check, ChevronDown, ChevronUp, ChevronsUp, Copy, DoorOpen, Flag, Globe,
  KeyRound, Loader2, Lock, MessageCircle, Send,
} from 'lucide-react';
import type { BallDef } from '@/lib/game/types';
import { ballExists, getBall } from '@/lib/game/balls';
import { buildBallTexture } from '@/lib/game/ball-textures';
import { crazyGames } from '@/lib/crazygames';
import { useToast } from '@/hooks/use-toast';
import {
  MP_PUBLIC_ROOM,
  type CreateAck,
  type JoinAck,
  type MpChatPayload,
  type MpJoinedPayload,
  type MpPlayerState,
  type MpSnapTuple,
  type MpSocket,
  type MpSysPayload,
  MP_WORLD_HALF,
} from '@/lib/multiplayer/protocol';

/* ============================================================
   Constantes de la carte ouverte
============================================================ */

const R = 0.9;                 // rayon du ballon joueur
const ACCEL = 34;              // u/s²
const FRICTION = 3.2;          // décroissance exp(-FRICTION·dt)
const GRAV = 26;               // u/s²
const JUMP_V = 9.5;            // u/s
const LIMIT = 116;             // soft clamp (|x|,|z| > 116 → rappel)
const HARD_LIMIT = MP_WORLD_HALF - 2; // clamp dur (±118)
const WATER_Y = -0.55;         // niveau du lac
const LAKE_CX = 34;            // centre du lac
const LAKE_CZ = -30;
const LAKE_HALF = 45;          // lac 90×90
const TREE_COUNT = 130;
const ROCK_COUNT = 26;
const FIRE_COUNT = 180;
const PYLON_COUNT = 18;
const MOVE_MS = 66;            // ~15 Hz
const PING_MS = 5000;
const SNAP_MAX_AGE = 10000;    // ms

/* ============================================================
   Helpers module (déterministes / réutilisables)
============================================================ */

/** Hauteur du terrain — fonction déterministe EXPOSÉE (module). */
export function terrainHeight(x: number, z: number): number {
  return 0.9 * Math.sin(x * 0.045) * Math.cos(z * 0.038) + 0.5 * Math.sin(x * 0.11 + 1.7) * Math.cos(z * 0.09);
}

/** true si la position est dans la zone d'eau du lac. */
function isWater(x: number, z: number): boolean {
  return Math.abs(x - LAKE_CX) < LAKE_HALF && Math.abs(z - LAKE_CZ) < LAKE_HALF && terrainHeight(x, z) < WATER_Y;
}

/** RNG déterministe (mulberry32). */
function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function clamp(v: number, lo: number, hi: number): number {
  return v < lo ? lo : v > hi ? hi : v;
}

/** Copie presse-papiers avec fallback execCommand. */
async function copyText(t: string): Promise<boolean> {
  try {
    if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(t);
      return true;
    }
  } catch { /* fallback */ }
  try {
    const ta = document.createElement('textarea');
    ta.value = t;
    ta.style.cssText = 'position:fixed;opacity:0;pointer-events:none;';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  } catch {
    return false;
  }
}

/** Socket multijoueur — recette examples/websocket : JAMAIS d'URL absolue
    ni de port dans l'URL, uniquement /?XTransformPort=3003 (path par défaut). */
function createMpSocket(): MpSocket {
  return io('/?XTransformPort=3003', {
    transports: ['websocket', 'polling'],
    forceNew: true,
    reconnection: true,
    reconnectionAttempts: 5,
    reconnectionDelay: 1000,
    timeout: 10000,
  });
}

/* ============================================================
   Rendu d'un ballon (recette GameCanvas) — local + distants
============================================================ */

interface BallVisualOpts {
  color: number;
  roughness: number;
  metalness: number;
  clearcoat: number;
  clearcoatRoughness: number;
  emissive: number;
  emissiveIntensity: number;
  glowColor: number;
  glowPower: number;
  opacity?: number;
  procTex?: BallDef['procTex'];
  texture?: string | null;
  rainbow?: boolean;
  fire?: boolean;
  radius: number;
  maxAniso: number;
}

interface BallVisual {
  group: THREE.Group;
  mesh: THREE.Mesh;
  mat: THREE.MeshPhysicalMaterial;
  light: THREE.PointLight;
  tick: (t: number) => void;
  dispose: () => void;
}

function buildBallVisual(o: BallVisualOpts): BallVisual {
  const group = new THREE.Group();
  const opacity = o.opacity ?? 1;

  const mat = new THREE.MeshPhysicalMaterial({
    color: o.color,
    roughness: o.roughness,
    metalness: o.metalness,
    clearcoat: o.clearcoat,
    clearcoatRoughness: o.clearcoatRoughness,
    emissive: new THREE.Color(o.emissive),
    emissiveIntensity: o.emissiveIntensity,
    envMapIntensity: 1.15,
    transparent: opacity < 1,
    opacity,
  });
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(o.radius, 40, 28), mat);
  group.add(mesh);

  // Coquille de lueur fresnel (même shader que GameCanvas)
  const glowUniforms = {
    uPower: { value: o.glowPower },
    uColor: { value: new THREE.Color(o.glowColor) },
  };
  const glowMat = new THREE.ShaderMaterial({
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    uniforms: glowUniforms,
    vertexShader:
      'varying float vF; void main(){' +
      'vec3 n=normalize(normalMatrix*normal);' +
      'vec4 mv=modelViewMatrix*vec4(position,1.0);' +
      'vec3 vd=normalize(-mv.xyz);' +
      'vF=pow(1.0-abs(dot(n,vd)),2.2);' +
      'gl_Position=projectionMatrix*mv; }',
    fragmentShader:
      'uniform float uPower; uniform vec3 uColor; varying float vF;' +
      'void main(){ gl_FragColor=vec4(uColor, vF*uPower); }',
  });
  group.add(new THREE.Mesh(new THREE.SphereGeometry(o.radius * 1.16, 28, 20), glowMat));

  // Lumière interne si feu / forte lueur
  const light = new THREE.PointLight(o.glowColor, o.fire ? 12 : o.glowPower > 1 ? 7 : 0, 10, 2);
  group.add(light);

  // Texture (procédurale ou fichier) — garde anti-course si dispose
  let dead = false;
  const pendingTex: THREE.Texture[] = [];
  void (async () => {
    try {
      let tex: THREE.Texture | null = null;
      if (o.procTex) tex = new THREE.CanvasTexture(buildBallTexture(o.procTex));
      else if (o.texture) tex = await new THREE.TextureLoader().loadAsync(o.texture);
      if (!tex) return;
      if (dead) { tex.dispose(); return; }
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = Math.min(8, o.maxAniso);
      pendingTex.push(tex);
      mat.map = tex;
      mat.color.set(0xffffff);
      mat.needsUpdate = true;
    } catch { /* texture manquante : couleur unie */ }
  })();

  const tick = (t: number) => {
    if (o.rainbow) {
      const hue = (t * 0.1) % 1;
      mat.emissive.setHSL(hue, 0.85, 0.55);
      mat.emissiveIntensity = Math.max(o.emissiveIntensity, 0.9);
      (glowUniforms.uColor.value as THREE.Color).setHSL(hue, 0.85, 0.6);
      light.color.setHSL(hue, 0.85, 0.6);
    }
  };

  const dispose = () => {
    dead = true;
    mesh.geometry.dispose();
    (glowMat as THREE.ShaderMaterial).dispose();
    (mesh.material as THREE.MeshPhysicalMaterial).dispose();
    group.children.forEach((ch) => {
      if (ch instanceof THREE.Mesh) {
        if (ch !== mesh && ch.geometry) ch.geometry.dispose();
      }
    });
    for (const tex of pendingTex) tex.dispose();
    mat.dispose();
    light.dispose();
  };

  return { group, mesh, mat, light, tick, dispose };
}

/** Opts de rendu pour un joueur distant (BallDef si connu, sinon couleur brute). */
function remoteVisualOpts(ballId: string, rawColor: number, maxAniso: number): BallVisualOpts {
  const def = ballExists(ballId) ? getBall(ballId) : null;
  if (def) {
    return {
      color: def.color,
      roughness: def.roughness,
      metalness: def.metalness,
      clearcoat: def.clearcoat,
      clearcoatRoughness: def.clearcoatRoughness,
      emissive: def.emissive,
      emissiveIntensity: def.emissiveIntensity,
      glowColor: def.glowColor,
      glowPower: def.glowPower,
      opacity: def.opacity,
      procTex: def.procTex,
      texture: def.texture,
      rainbow: def.rainbow,
      fire: def.fireParticles,
      radius: R,
      maxAniso,
    };
  }
  return {
    color: rawColor,
    roughness: 0.35,
    metalness: 0.05,
    clearcoat: 0.6,
    clearcoatRoughness: 0.3,
    emissive: rawColor,
    emissiveIntensity: 0.15,
    glowColor: rawColor,
    glowPower: 0.5,
    radius: R,
    maxAniso,
  };
}

/* ============================================================
   Sprites : étiquette pseudo + bulle de chat (canvas)
============================================================ */

function buildLabel(text: string, tint: string): { sprite: THREE.Sprite; tex: THREE.CanvasTexture } {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 64;
  const g = c.getContext('2d');
  const t = (text || 'Joueur').slice(0, 16);
  if (g) {
    g.font = `bold ${t.length > 10 ? 26 : 34}px system-ui, -apple-system, sans-serif`;
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.lineJoin = 'round';
    g.lineWidth = 9;
    g.strokeStyle = 'rgba(14,11,8,0.92)';
    g.strokeText(t, 128, 34);
    g.fillStyle = tint;
    g.fillText(t, 128, 34);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, fog: false }));
  sprite.scale.set(2.2, 0.55, 1);
  sprite.position.y = 1.75;
  return { sprite, tex };
}

interface Bubble {
  ctx: CanvasRenderingContext2D;
  tex: THREE.CanvasTexture;
  sprite: THREE.Sprite;
  life: number;
}

function roundRectPath(g: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  g.beginPath();
  g.moveTo(x + r, y);
  g.arcTo(x + w, y, x + w, y + h, r);
  g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r);
  g.arcTo(x, y, x + w, y, r);
  g.closePath();
}

function createBubble(): Bubble {
  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 224;
  const ctx = c.getContext('2d');
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, fog: false, opacity: 0 }));
  sprite.scale.set(3.4, 1.49, 1);
  sprite.position.y = 2.9;
  sprite.visible = false;
  return { ctx: ctx as CanvasRenderingContext2D, tex, sprite, life: 0 };
}

/** Dessine une bulle arrondie + queue, texte blanc max 3 lignes. */
function drawBubble(b: Bubble, text: string) {
  const g = b.ctx;
  const W = 512;
  const maxW = W - 96;
  g.clearRect(0, 0, W, 224);
  g.font = '600 30px system-ui, -apple-system, sans-serif';
  g.textAlign = 'left';
  g.textBaseline = 'middle';

  const words = text.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let line = '';
  let truncated = false;
  for (const w of words) {
    const test = line ? `${line} ${w}` : w;
    if (g.measureText(test).width > maxW && line) {
      lines.push(line);
      line = w;
      if (lines.length === 3) { truncated = true; break; }
    } else {
      line = test;
    }
  }
  if (!truncated && line) lines.push(line);
  if (truncated && lines.length === 3) {
    let last = lines[2];
    while (g.measureText(`${last}…`).width > maxW && last.length > 1) last = last.slice(0, -1);
    lines[2] = `${last}…`;
  }
  if (lines.length === 0) lines.push('…');

  const lineH = 40;
  const padX = 26;
  const padTop = 20;
  const widest = Math.max(...lines.map((l) => g.measureText(l).width));
  const boxW = Math.min(W - 48, widest + padX * 2);
  const boxH = lines.length * lineH + padTop + 14;
  const bx = (W - boxW) / 2;
  const by = 224 - 36 - boxH;

  roundRectPath(g, bx, by, boxW, boxH, 18);
  g.fillStyle = 'rgba(20,18,14,0.92)';
  g.fill();
  g.lineWidth = 2;
  g.strokeStyle = 'rgba(255,255,255,0.10)';
  g.stroke();

  g.beginPath();
  g.moveTo(W / 2 - 14, by + boxH - 1);
  g.lineTo(W / 2 + 14, by + boxH - 1);
  g.lineTo(W / 2, by + boxH + 16);
  g.closePath();
  g.fillStyle = 'rgba(20,18,14,0.92)';
  g.fill();

  g.fillStyle = '#fff4e4';
  lines.forEach((l, i) => {
    g.fillText(l, bx + padX, by + padTop + lineH * i + lineH / 2);
  });
  b.tex.needsUpdate = true;
  b.sprite.visible = true;
  b.life = 6;
  b.sprite.material.opacity = 1;
}

/** Fade de la bulle (appelé chaque frame). */
function tickBubble(b: Bubble, dt: number) {
  if (b.life <= 0) return;
  b.life -= dt;
  const o = b.life > 5.4 ? Math.min(1, (6 - b.life) / 0.6) : Math.min(1, Math.max(0, b.life) / 0.8);
  b.sprite.material.opacity = o;
  if (b.life <= 0) b.sprite.visible = false;
}

/* ============================================================
   Composant principal
============================================================ */

interface Props {
  ball: BallDef;
  playerName: string;
  onExit: () => void;
}

type Stage = 'gate' | 'menu' | 'arena';

interface ChatMsg {
  key: number;
  id: string;
  /** id socket de l'auteur (undefined pour les messages système) */
  from?: string;
  name: string;
  text: string;
  sys: boolean;
}

interface RemotePlayer {
  group: THREE.Group;
  visual: BallVisual;
  blob: THREE.Mesh;
  blobMat: THREE.MeshBasicMaterial;
  labelTex: THREE.CanvasTexture;
  labelMat: THREE.SpriteMaterial;
  bubble: Bubble;
  bubbleMat: THREE.SpriteMaterial;
  target: THREE.Vector3;
  prevPos: THREE.Vector3;
  name: string;
  ballId: string;
  color: number;
  rainbow: boolean;
  lastTs: number;
}

export default function MultiplayerView({ ball, playerName, onExit }: Props) {
  const { toast } = useToast();

  const [stage, setStage] = useState<Stage>('gate');
  const [gateLocked, setGateLocked] = useState(false);
  const [gateChecking, setGateChecking] = useState(true);
  const [connecting, setConnecting] = useState(false);
  const [joinError, setJoinError] = useState<string | null>(null);
  const [codeInput, setCodeInput] = useState('');
  const [createdCode, setCreatedCode] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);
  const [room, setRoom] = useState<string | null>(null);
  const [youId, setYouId] = useState<string | null>(null);
  const [playerCount, setPlayerCount] = useState(1);
  const [latency, setLatency] = useState<number | null>(null);
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [chatDraft, setChatDraft] = useState('');
  const [chatOpen, setChatOpen] = useState(true);
  const [copiedPill, setCopiedPill] = useState(false);

  const mountRef = useRef<HTMLDivElement>(null);
  const joyRef = useRef<HTMLDivElement>(null);
  const joyThumbRef = useRef<HTMLDivElement>(null);
  const chatListRef = useRef<HTMLDivElement>(null);
  const socketRef = useRef<MpSocket | null>(null);
  const roomRef = useRef<string>('');
  const ballRef = useRef<BallDef>(ball);
  ballRef.current = ball;
  const nameRef = useRef<string>(playerName);
  nameRef.current = playerName;
  const onExitRef = useRef(onExit);
  onExitRef.current = onExit;
  const enterTimerRef = useRef<number | null>(null);
  const mutedRef = useRef<Set<string>>(new Set());
  const msgKeyRef = useRef(0);
  const jumpRef = useRef(false);

  /* ---------------- Gate CrazyGames ---------------- */

  const activateGate = useCallback(() => {
    void crazyGames.init().then(async (ok) => {
      // filet de sécurité : si l'init a expiré mais que le SDK finit par
      // s'initialiser (chargement lent du script), on ne verrouille pas
      // immédiatement — on sonde isReady() quelques secondes de plus.
      for (let i = 0; !ok && i < 12 && !crazyGames.isReady(); i++) {
        await new Promise((r) => setTimeout(r, 500));
        ok = crazyGames.isReady();
      }
      setGateChecking(false);
      if (ok) setStage('menu');
      else setGateLocked(true);
    });
  }, []);

  useEffect(() => {
    activateGate();
  }, [activateGate]);

  /* ---------------- Flux de connexion (menu) ---------------- */

  const ensureSocket = useCallback((): MpSocket => {
    if (socketRef.current) return socketRef.current;
    const s = createMpSocket();
    socketRef.current = s;
    return s;
  }, []);

  const dropSocket = useCallback(() => {
    const s = socketRef.current;
    if (s) {
      s.removeAllListeners();
      s.disconnect();
      socketRef.current = null;
    }
  }, []);

  const withAck = <A,>(s: MpSocket, emit: (ack: (a: A) => void) => void, ms = 10000): Promise<A> =>
    new Promise<A>((resolve, reject) => {
      const timer = window.setTimeout(() => reject(new Error('ack-timeout')), ms);
      emit((a: A) => {
        window.clearTimeout(timer);
        resolve(a);
      });
    });

  const startJoin = useCallback(async (targetRoom: string) => {
    if (connecting) return;
    setConnecting(true);
    setJoinError(null);
    const b = ballRef.current;
    const name = (nameRef.current || 'Joueur').slice(0, 24);
    try {
      const s = ensureSocket();
      const ack = await withAck<JoinAck>(s, (ack2) =>
        s.emit('mp:join', { room: targetRoom, name, ballId: b.id, color: b.color }, ack2)
      );
      if (ack.ok) {
        roomRef.current = ack.room;
        setRoom(ack.room);
        setStage('arena');
      } else if (targetRoom === MP_PUBLIC_ROOM) {
        toast({ title: 'Connexion refusée', description: ack.error, variant: 'destructive' });
        dropSocket();
      } else {
        setJoinError(ack.error || 'Salle introuvable.');
        dropSocket();
      }
    } catch {
      toast({ title: 'Serveur injoignable', description: 'Réessaie dans un instant.', variant: 'destructive' });
      dropSocket();
    } finally {
      setConnecting(false);
    }
  }, [connecting, ensureSocket, dropSocket, toast]);

  const startCreate = useCallback(async () => {
    if (connecting) return;
    setConnecting(true);
    const b = ballRef.current;
    const name = (nameRef.current || 'Joueur').slice(0, 24);
    try {
      const s = ensureSocket();
      const ack = await withAck<CreateAck>(s, (ack2) =>
        s.emit('mp:create', { name, ballId: b.id, color: b.color }, ack2)
      );
      if (ack.ok) {
        roomRef.current = ack.room;
        setRoom(ack.room);
        setCreatedCode(ack.room);
        setCopiedCode(false);
        if (enterTimerRef.current) window.clearTimeout(enterTimerRef.current);
        enterTimerRef.current = window.setTimeout(() => setStage('arena'), 3200);
      } else {
        toast({ title: 'Création impossible', description: 'Le serveur a refusé la création de la salle.', variant: 'destructive' });
        dropSocket();
      }
    } catch {
      toast({ title: 'Serveur injoignable', description: 'Réessaie dans un instant.', variant: 'destructive' });
      dropSocket();
    } finally {
      setConnecting(false);
    }
  }, [connecting, ensureSocket, dropSocket, toast]);

  const copyCreated = useCallback(async () => {
    if (!createdCode) return;
    const ok = await copyText(createdCode);
    setCopiedCode(ok);
    if (ok) window.setTimeout(() => setCopiedCode(false), 2000);
  }, [createdCode]);

  const copyPill = useCallback(async () => {
    if (!room || room === MP_PUBLIC_ROOM) return;
    const ok = await copyText(room);
    setCopiedPill(ok);
    if (ok) window.setTimeout(() => setCopiedPill(false), 2000);
  }, [room]);

  const quit = useCallback(() => {
    if (enterTimerRef.current) {
      window.clearTimeout(enterTimerRef.current);
      enterTimerRef.current = null;
    }
    setStage('menu');
    setCreatedCode(null);
    onExitRef.current();
  }, []);

  const reportPlayer = useCallback((m: ChatMsg) => {
    if (m.from) mutedRef.current.add(m.from);
    toast({ title: 'Joueur signalé', description: `${m.name} est masqué localement.` });
  }, [toast]);

  const sendChat = useCallback(() => {
    const text = chatDraft.trim().slice(0, 200);
    if (!text) return;
    socketRef.current?.emit('mp:chat', { text });
    setChatDraft('');
  }, [chatDraft]);

  /* ---------------- Auto-scroll du chat ---------------- */

  useEffect(() => {
    const el = chatListRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, chatOpen]);

  /* ---------------- Nettoyage global ---------------- */

  useEffect(() => {
    return () => {
      if (enterTimerRef.current) window.clearTimeout(enterTimerRef.current);
      const s = socketRef.current;
      if (s) {
        s.removeAllListeners();
        s.disconnect();
        socketRef.current = null;
      }
    };
  }, []);

  /* ============================================================
     ARÈNE — toute la logique Three.js + socket
  ============================================================ */

  useEffect(() => {
    if (stage !== 'arena') return;
    const mount = mountRef.current;
    if (!mount) return;

    /* ---------------- Socket (unique, réutilisée ou recréée) ---------------- */

    const myBall = ballRef.current;
    const myName = (nameRef.current || 'Joueur').slice(0, 24);

    let socket: MpSocket;
    if (socketRef.current) {
      socket = socketRef.current;
    } else {
      socket = createMpSocket();
      socketRef.current = socket;
    }

    const rejoin = () => {
      if (!roomRef.current) return;
      socket.emit(
        'mp:join',
        { room: roomRef.current, name: myName, ballId: myBall.id, color: myBall.color },
        (ack: JoinAck) => {
          if (!ack.ok) pushSys(ack.error || 'Reconnexion refusée.');
        }
      );
      setLatency(null);
    };
    socket.on('connect', rejoin);
    socket.on('disconnect', () => pushSys('Connexion perdue — reconnexion…'));

    /* ---------------- Renderer / scène ---------------- */

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    mount.appendChild(renderer.domElement);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.touchAction = 'none';

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b0a08);
    scene.fog = new THREE.FogExp2(0x2b241a, 0.011);

    const camera = new THREE.PerspectiveCamera(55, mount.clientWidth / mount.clientHeight, 0.1, 700);
    camera.position.set(0, 8, 10);

    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;

    /* ---------------- Ciel + lune + lumières ---------------- */

    const skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      uniforms: {
        cTop: { value: new THREE.Color(0x0b0a08) },
        cBot: { value: new THREE.Color(0x3d3428) },
      },
      vertexShader:
        'varying vec3 vP; void main(){ vP=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader:
        'varying vec3 vP; uniform vec3 cTop; uniform vec3 cBot;' +
        'void main(){ float h=clamp(normalize(vP).y*0.5+0.5,0.0,1.0);' +
        'vec3 c=mix(cBot,cTop,pow(h,0.75)); gl_FragColor=vec4(c,1.0); }',
    });
    const sky = new THREE.Mesh(new THREE.SphereGeometry(320, 24, 16), skyMat);
    scene.add(sky);

    // Lune (halo chaud)
    const moonCanvas = document.createElement('canvas');
    moonCanvas.width = moonCanvas.height = 256;
    const mctx = moonCanvas.getContext('2d');
    if (mctx) {
      const grad = mctx.createRadialGradient(128, 128, 10, 128, 128, 126);
      grad.addColorStop(0, 'rgba(255,242,220,1)');
      grad.addColorStop(0.32, 'rgba(255,236,200,0.9)');
      grad.addColorStop(0.5, 'rgba(255,220,170,0.28)');
      grad.addColorStop(1, 'rgba(255,210,150,0)');
      mctx.fillStyle = grad;
      mctx.fillRect(0, 0, 256, 256);
    }
    const moonTex = new THREE.CanvasTexture(moonCanvas);
    const moon = new THREE.Sprite(new THREE.SpriteMaterial({
      map: moonTex, transparent: true, opacity: 0.95, depthWrite: false, fog: false,
    }));
    moon.position.set(-120, 95, -170);
    moon.scale.set(34, 34, 1);
    scene.add(moon);

    scene.add(new THREE.HemisphereLight(0xffefd8, 0x2e2a1e, 0.85));
    const dir = new THREE.DirectionalLight(0xffe4bd, 0.9);
    dir.position.set(60, 90, 30);
    scene.add(dir);

    /* ---------------- Terrain 280×280 ---------------- */

    const T_SIZE = 280;
    const terrainGeo = new THREE.PlaneGeometry(T_SIZE, T_SIZE, 96, 96);
    terrainGeo.rotateX(-Math.PI / 2);
    const tPos = terrainGeo.attributes.position as THREE.BufferAttribute;
    const tColors = new Float32Array(tPos.count * 3);
    for (let i = 0; i < tPos.count; i++) {
      const x = tPos.getX(i);
      const z = tPos.getZ(i);
      const h = terrainHeight(x, z);
      tPos.setY(i, h);
      const v = clamp(0.84 + ((h + 1.4) / 2.8) * 0.34, 0.8, 1.18);
      tColors[i * 3] = v * 1.02;
      tColors[i * 3 + 1] = v;
      tColors[i * 3 + 2] = v * 0.94;
    }
    terrainGeo.setAttribute('color', new THREE.BufferAttribute(tColors, 3));
    terrainGeo.computeVertexNormals();
    const terrain = new THREE.Mesh(
      terrainGeo,
      new THREE.MeshStandardMaterial({ color: 0x3a4229, roughness: 0.9, metalness: 0, vertexColors: true })
  );
    scene.add(terrain);

    /* ---------------- Lac d'eau (shader) ---------------- */

    const waterUniforms = THREE.UniformsUtils.merge([
      THREE.UniformsLib.fog,
      { uTime: { value: 0 } },
    ]);
    const waterMat = new THREE.ShaderMaterial({
      transparent: true,
      fog: true,
      depthWrite: false,
      uniforms: waterUniforms,
      vertexShader: `
        #include <fog_pars_vertex>
        uniform float uTime;
        varying vec2 vUv;
        void main(){
          vUv = uv;
          vec3 p = position;
          p.z += sin(p.x*0.32+uTime*1.4)*0.085 + cos(p.y*0.27+uTime*1.05)*0.065 + sin((p.x+p.y)*0.18+uTime*0.7)*0.05;
          vec4 mvPosition = modelViewMatrix*vec4(p,1.0);
          gl_Position = projectionMatrix*mvPosition;
          #include <fog_vertex>
        }`,
      fragmentShader: `
        #include <fog_pars_fragment>
        uniform float uTime;
        varying vec2 vUv;
        void main(){
          vec3 deep  = vec3(0.122,0.435,0.400);  // #1f6f66
          vec3 shore = vec3(0.165,0.561,0.502);  // #2a8f80
          float g = 0.5 + 0.5*sin(vUv.x*12.0+uTime*0.6)*sin(vUv.y*10.0-uTime*0.45);
          vec3 col = mix(deep, shore, clamp(0.35 + 0.4*vUv.y + 0.15*g, 0.0, 1.0));
          float sparkle = smoothstep(0.86,1.0, sin(vUv.x*40.0+uTime*1.3)*sin(vUv.y*36.0-uTime*1.1))*0.18;
          col += sparkle;
          gl_FragColor = vec4(col, 0.78);
          #include <fog_fragment>
        }`,
    });
    const water = new THREE.Mesh(new THREE.PlaneGeometry(90, 90, 48, 48), waterMat);
    water.rotation.x = -Math.PI / 2;
    water.position.set(LAKE_CX, WATER_Y, LAKE_CZ);
    water.renderOrder = 1;
    scene.add(water);

    /* ---------------- Forêts + rochers (déterministe, seed 2024) ---------------- */

    const rng = mulberry32(2024);
    interface TreeSpec { x: number; z: number; s: number; rot: number }
    const trees: TreeSpec[] = [];
    interface RockSpec { x: number; z: number; wy: number; sx: number; sy: number; sz: number; rot: number }
    const rocks: RockSpec[] = [];

    let guard = 0;
    while (trees.length < TREE_COUNT && guard++ < 4000) {
      const x = (rng() * 2 - 1) * 132;
      const z = (rng() * 2 - 1) * 132;
      if (Math.hypot(x, z) < 16) continue; // zone de spawn dégagée
      if (Math.abs(x - LAKE_CX) < LAKE_HALF + 5 && Math.abs(z - LAKE_CZ) < LAKE_HALF + 5) continue; // lac
      if (terrainHeight(x, z) < -0.35) continue; // sous l'eau
      let ok = true;
      for (const t of trees) {
        if (Math.hypot(t.x - x, t.z - z) < 4.2) { ok = false; break; }
      }
      if (!ok) continue;
      trees.push({ x, z, s: 0.8 + rng() * 0.9, rot: rng() * Math.PI * 2 });
    }

    guard = 0;
    while (rocks.length < ROCK_COUNT && guard++ < 2000) {
      const x = (rng() * 2 - 1) * 128;
      const z = (rng() * 2 - 1) * 128;
      if (Math.hypot(x, z) < 14) continue;
      if (Math.abs(x - LAKE_CX) < LAKE_HALF + 3 && Math.abs(z - LAKE_CZ) < LAKE_HALF + 3) continue;
      if (terrainHeight(x, z) < -0.35) continue;
      let ok = true;
      for (const t of trees) {
        if (Math.hypot(t.x - x, t.z - z) < 3.2) { ok = false; break; }
      }
      for (const r0 of rocks) {
        if (Math.hypot(r0.x - x, r0.z - z) < 5) { ok = false; break; }
      }
      if (!ok) continue;
      const sx = 0.7 + rng() * 1.5;
      const sy = sx * (0.55 + rng() * 0.5);
      rocks.push({ x, z, wy: terrainHeight(x, z) + sy * 0.35, sx, sy, sz: sx * (0.8 + rng() * 0.4), rot: rng() * Math.PI * 2 });
    }

    const trunkGeo = new THREE.CylinderGeometry(0.22, 0.34, 2.6, 7);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x4a3527, roughness: 0.95 });
    const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, Math.max(1, trees.length));
    const foliGeo = new THREE.ConeGeometry(1.55, 3.6, 8);
    const foliMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9 });
    const folis = new THREE.InstancedMesh(foliGeo, foliMat, Math.max(1, trees.length));

    const m4 = new THREE.Matrix4();
    const q4 = new THREE.Quaternion();
    const v4 = new THREE.Vector3();
    const sc4 = new THREE.Vector3();
    const col4 = new THREE.Color();
    trees.forEach((t, i) => {
      const h = terrainHeight(t.x, t.z);
      q4.setFromAxisAngle(v4.set(0, 1, 0), t.rot);
      m4.compose(v4.set(t.x, h + 1.3 * t.s, t.z), q4, sc4.set(t.s, t.s * (0.85 + rng() * 0.5), t.s));
      trunks.setMatrixAt(i, m4);
      m4.compose(v4.set(t.x, h + 3.4 * t.s, t.z), q4, sc4.set(t.s, t.s * (0.9 + rng() * 0.45), t.s));
      folis.setMatrixAt(i, m4);
      col4.setHSL(0.23 + rng() * 0.06, 0.34 + rng() * 0.16, 0.2 + rng() * 0.08);
      folis.setColorAt(i, col4);
    });
    trunks.instanceMatrix.needsUpdate = true;
    folis.instanceMatrix.needsUpdate = true;
    if (folis.instanceColor) folis.instanceColor.needsUpdate = true;
    trunks.computeBoundingSphere();
    folis.computeBoundingSphere();
    scene.add(trunks, folis);

    const rockGeo = new THREE.DodecahedronGeometry(1, 0);
    const rockMat = new THREE.MeshStandardMaterial({ color: 0x6a6258, roughness: 0.85, metalness: 0.05 });
    const rockMesh = new THREE.InstancedMesh(rockGeo, rockMat, Math.max(1, rocks.length));
    rocks.forEach((r0, i) => {
      q4.setFromAxisAngle(v4.set(0, 1, 0), r0.rot);
      m4.compose(v4.set(r0.x, r0.wy, r0.z), q4, sc4.set(r0.sx, r0.sy, r0.sz));
      rockMesh.setMatrixAt(i, m4);
    });
    rockMesh.instanceMatrix.needsUpdate = true;
    rockMesh.computeBoundingSphere();
    scene.add(rockMesh);

    /* ---------------- Lucioles ---------------- */

    const fireBase = new Float32Array(FIRE_COUNT * 3);
    const firePhase = new Float32Array(FIRE_COUNT);
    for (let i = 0; i < FIRE_COUNT; i++) {
      const x = (rng() * 2 - 1) * 130;
      const z = (rng() * 2 - 1) * 130;
      fireBase[i * 3] = x;
      fireBase[i * 3 + 1] = Math.max(terrainHeight(x, z), WATER_Y) + 0.6 + rng() * 2.4;
      fireBase[i * 3 + 2] = z;
      firePhase[i] = rng() * Math.PI * 2;
    }
    const fireGeo = new THREE.BufferGeometry();
    const firePos = new Float32Array(fireBase);
    fireGeo.setAttribute('position', new THREE.BufferAttribute(firePos, 3).setUsage(THREE.DynamicDrawUsage));
    const fireflies = new THREE.Points(fireGeo, new THREE.PointsMaterial({
      color: 0xffd98a, size: 0.22, transparent: true, opacity: 0.75,
      blending: THREE.AdditiveBlending, depthWrite: false,
    }));
    fireflies.frustumCulled = false;
    scene.add(fireflies);

    /* ---------------- Bord du monde : 18 poteaux lumineux ---------------- */

    const pylonGeo = new THREE.CylinderGeometry(0.65, 0.95, 5.2, 7);
    const pylonMat = new THREE.MeshStandardMaterial({ color: 0x57504a, roughness: 0.9 });
    const capGeo = new THREE.CylinderGeometry(0.68, 0.68, 0.24, 7);
    const capMat = new THREE.MeshBasicMaterial({ color: 0xff8a5e, transparent: true, opacity: 0.9 });
    for (let i = 0; i < PYLON_COUNT; i++) {
      const a = (i / PYLON_COUNT) * Math.PI * 2;
      const x = Math.cos(a) * 124;
      const z = Math.sin(a) * 124;
      const h = terrainHeight(x, z);
      const pylon = new THREE.Mesh(pylonGeo, pylonMat);
      pylon.position.set(x, h + 2.6, z);
      scene.add(pylon);
      const cap = new THREE.Mesh(capGeo, capMat);
      cap.position.set(x, h + 5.35, z);
      scene.add(cap);
    }

    /* ---------------- Ombre de contact (blob partagé) ---------------- */

    const blobCanvas = document.createElement('canvas');
    blobCanvas.width = blobCanvas.height = 128;
    const bctx = blobCanvas.getContext('2d');
    if (bctx) {
      const grad = bctx.createRadialGradient(64, 64, 4, 64, 64, 62);
      grad.addColorStop(0, 'rgba(0,0,0,0.7)');
      grad.addColorStop(1, 'rgba(0,0,0,0)');
      bctx.fillStyle = grad;
      bctx.fillRect(0, 0, 128, 128);
    }
    const blobTex = new THREE.CanvasTexture(blobCanvas);
    const blobGeo = new THREE.PlaneGeometry(1, 1);

    const makeBlob = (): { mesh: THREE.Mesh; mat: THREE.MeshBasicMaterial } => {
      const mat = new THREE.MeshBasicMaterial({ map: blobTex, transparent: true, depthWrite: false, opacity: 0.4 });
      const mesh = new THREE.Mesh(blobGeo, mat);
      mesh.rotation.x = -Math.PI / 2;
      mesh.renderOrder = 1;
      mesh.scale.setScalar(2.6);
      return { mesh, mat };
    };

    /* ---------------- Joueur local ---------------- */

    const visual = buildBallVisual({
      color: myBall.color,
      roughness: myBall.roughness,
      metalness: myBall.metalness,
      clearcoat: myBall.clearcoat,
      clearcoatRoughness: myBall.clearcoatRoughness,
      emissive: myBall.emissive,
      emissiveIntensity: myBall.emissiveIntensity,
      glowColor: myBall.glowColor,
      glowPower: myBall.glowPower,
      opacity: myBall.opacity,
      procTex: myBall.procTex,
      texture: myBall.texture,
      rainbow: myBall.rainbow,
      fire: myBall.fireParticles,
      radius: R,
      maxAniso: renderer.capabilities.getMaxAnisotropy(),
    });
    const localLabel = buildLabel(myName, '#ffd98a');
    visual.group.add(localLabel.sprite);
    const localBubble = createBubble();
    visual.group.add(localBubble.sprite);
    scene.add(visual.group);

    const localBlob = makeBlob();
    scene.add(localBlob.mesh);

    const p = new THREE.Vector3(0, terrainHeight(0, 0) + R, 0);
    const vel = new THREE.Vector3();
    let yawCam = Math.PI; // caméra derrière le joueur, regard vers -z
    let camDist = 7.2;
    let camDistTarget = 7.2;
    let grounded = false;
    let lastInputAt = 0;

    /* ---------------- Joueurs distants ---------------- */

    const remotes = new Map<string, RemotePlayer>();
    let youLocal = socket.id ?? '';

    const addRemote = (ps: MpPlayerState) => {
      if (remotes.has(ps.id) || ps.id === youLocal) return;
      const rvis = buildBallVisual(remoteVisualOpts(ps.ballId, ps.color, renderer.capabilities.getMaxAnisotropy()));
      const label = buildLabel(ps.name, '#ffffff');
      rvis.group.add(label.sprite);
      const bubble = createBubble();
      rvis.group.add(bubble.sprite);
      rvis.group.position.set(ps.x, ps.y, ps.z);
      const blob = makeBlob();
      scene.add(rvis.group, blob.mesh);
      remotes.set(ps.id, {
        group: rvis.group,
        visual: rvis,
        blob: blob.mesh,
        blobMat: blob.mat,
        labelTex: label.tex,
        labelMat: label.sprite.material as THREE.SpriteMaterial,
        bubble,
        bubbleMat: bubble.sprite.material as THREE.SpriteMaterial,
        target: new THREE.Vector3(ps.x, ps.y, ps.z),
        prevPos: new THREE.Vector3(ps.x, ps.y, ps.z),
        name: ps.name,
        ballId: ps.ballId,
        color: ps.color,
        rainbow: ballExists(ps.ballId) && getBall(ps.ballId).rainbow === true,
        lastTs: performance.now(),
      });
    };

    const removeRemote = (id: string) => {
      const rp = remotes.get(id);
      if (!rp) return;
      scene.remove(rp.group, rp.blob);
      rp.visual.dispose();
      rp.labelTex.dispose();
      rp.labelMat.dispose();
      rp.bubble.tex.dispose();
      rp.bubbleMat.dispose();
      rp.blobMat.dispose();
      remotes.delete(id);
    };

    const clearRemotes = () => {
      for (const id of Array.from(remotes.keys())) removeRemote(id);
    };

    /* ---------------- Chat / messages (refs vers React) ---------------- */

    // Déclarations hoistées : utilisables depuis `rejoin` ci-dessus
    function pushMsg(m: Omit<ChatMsg, 'key'>) {
      msgKeyRef.current += 1;
      const msg: ChatMsg = { ...m, key: msgKeyRef.current };
      setMessages((prev) => {
        const next = [...prev, msg];
        return next.length > 80 ? next.slice(next.length - 80) : next;
      });
    }
    function pushSys(text: string) {
      pushMsg({ id: 'sys', name: '', text, sys: true });
    }

    const onJoined = (d: MpJoinedPayload) => {
      youLocal = d.you;
      setYouId(d.you);
      clearRemotes();
      for (const ps of d.players) {
        if (ps.id !== d.you) addRemote(ps);
      }
      // le serveur inclut le joueur local dans `players`
      setPlayerCount(d.players.length);
      pushSys(
        roomRef.current === MP_PUBLIC_ROOM
          ? 'Connecté — Salle publique.'
          : `Connecté — salle ${roomRef.current}.`
      );
    };
    const onPlayerJoined = (d: { player: MpPlayerState }) => {
      if (d.player.id === youLocal) return;
      addRemote(d.player);
      setPlayerCount((c) => c + 1);
    };
    const onPlayerLeft = (d: { id: string; name: string }) => {
      removeRemote(d.id);
      setPlayerCount((c) => Math.max(1, c - 1));
    };
    const onSnap = (d: { p: MpSnapTuple[] }) => {
      const now = performance.now();
      for (const tup of d.p) {
        const rp = remotes.get(tup[0]);
        if (!rp) continue;
        rp.target.set(tup[1], tup[2], tup[3]);
        rp.lastTs = now;
      }
    };
    const onChat = (d: MpChatPayload) => {
      // d.id = id du message · d.from = id socket de l'auteur
      const mine = d.from === youLocal;
      if (mutedRef.current.has(d.from)) {
        pushMsg({ id: d.id, from: d.from, name: d.name, text: '[masqué]', sys: false });
        return;
      }
      pushMsg({ id: d.id, from: d.from, name: d.name, text: d.text, sys: false });
      if (mine) drawBubble(localBubble, d.text);
      else {
        const rp = remotes.get(d.from);
        if (rp) drawBubble(rp.bubble, d.text);
      }
    };
    const onSys = (d: MpSysPayload) => {
      // n'affiche pas son propre message d'arrivée
      const myName = (nameRef.current || 'Joueur').trim().slice(0, 16);
      if (d.text === `${myName} a rejoint la salle`) return;
      pushSys(d.text);
    };

    socket.on('mp:joined', onJoined);
    socket.on('mp:player-joined', onPlayerJoined);
    socket.on('mp:player-left', onPlayerLeft);
    socket.on('mp:snap', onSnap);
    socket.on('mp:chat', onChat);
    socket.on('mp:sys', onSys);
    if (socket.connected && remotes.size === 0) {
      // déjà connecté (flux normal) : le mp:joined initial est arrivé avant
      // le montage de l'effet — on resynchronise joueurs + salle
      rejoin();
    }

    /* ---------------- Envoi position + ping ---------------- */

    const lastSent = new THREE.Vector3(Infinity, Infinity, Infinity);
    const moveTimer = window.setInterval(() => {
      if (p.distanceTo(lastSent) > 0.05) {
        lastSent.copy(p);
        socket.emit('mp:move', {
          x: Math.round(p.x * 100) / 100,
          y: Math.round(p.y * 100) / 100,
          z: Math.round(p.z * 100) / 100,
        });
      }
    }, MOVE_MS);

    const pingTimer = window.setInterval(() => {
      const t0 = performance.now();
      socket.emit('mp:ping', (t: { t: number }) => {
        void t;
        setLatency(Math.max(1, Math.round(performance.now() - t0)));
      });
    }, PING_MS);

    /* ---------------- Entrées : clavier ---------------- */

    const keys = new Set<string>();
    const inputAt = () => { lastInputAt = performance.now(); };
    const isEditable = (el: Element | null): boolean =>
      !!el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || ('isContentEditable' in el && (el as HTMLElement).isContentEditable));

    const onKeyDown = (e: KeyboardEvent) => {
      if (isEditable(document.activeElement)) return;
      if (e.code === 'Space') {
        e.preventDefault();
        jumpRef.current = true;
        inputAt();
      }
      if (e.code === 'KeyW' || e.code === 'KeyA' || e.code === 'KeyS' || e.code === 'KeyD' || e.code.startsWith('Arrow')) {
        e.preventDefault();
        inputAt();
      }
      keys.add(e.code);
    };
    const onKeyUp = (e: KeyboardEvent) => { keys.delete(e.code); };
    const onBlur = () => { keys.clear(); };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);

    /* ---------------- Entrées : pointeur (joystick + orbite) + molette ---------------- */

    const canvas = renderer.domElement;
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());

    const orbiters = new Map<number, { x: number; y: number }>();
    let joyPointerId: number | null = null;
    const joyBase = { x: 0, y: 0 };
    const joyVec = { x: 0, y: 0 };

    const showJoy = (cx: number, cy: number) => {
      const el = joyRef.current;
      if (!el) return;
      el.style.display = 'block';
      el.style.left = `${cx - 60}px`;
      el.style.top = `${cy - 60}px`;
      if (joyThumbRef.current) joyThumbRef.current.style.transform = 'translate(-50%, -50%)';
    };
    const hideJoy = () => {
      if (joyRef.current) joyRef.current.style.display = 'none';
    };

    const onPointerDown = (e: PointerEvent) => {
      inputAt();
      canvas.setPointerCapture(e.pointerId);
      if (e.pointerType !== 'mouse' && e.clientX < window.innerWidth * 0.5 && joyPointerId === null) {
        joyPointerId = e.pointerId;
        joyBase.x = e.clientX;
        joyBase.y = e.clientY;
        joyVec.x = 0;
        joyVec.y = 0;
        showJoy(e.clientX, e.clientY);
      } else {
        orbiters.set(e.pointerId, { x: e.clientX, y: e.clientY });
      }
    };
    const onPointerMove = (e: PointerEvent) => {
      if (e.pointerId === joyPointerId) {
        let dx = e.clientX - joyBase.x;
        let dy = e.clientY - joyBase.y;
        const d = Math.hypot(dx, dy);
        const max = 44;
        if (d > max) { dx = (dx / d) * max; dy = (dy / d) * max; }
        joyVec.x = dx / max;
        joyVec.y = dy / max;
        if (joyThumbRef.current) {
          joyThumbRef.current.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
        }
        inputAt();
        return;
      }
      const prev = orbiters.get(e.pointerId);
      if (prev) {
        yawCam -= (e.clientX - prev.x) * 0.0055;
        prev.x = e.clientX;
        prev.y = e.clientY;
        inputAt();
      }
    };
    const onPointerUp = (e: PointerEvent) => {
      if (e.pointerId === joyPointerId) {
        joyPointerId = null;
        joyVec.x = 0;
        joyVec.y = 0;
        hideJoy();
      }
      orbiters.delete(e.pointerId);
    };
    canvas.addEventListener('pointerdown', onPointerDown);
    canvas.addEventListener('pointermove', onPointerMove);
    canvas.addEventListener('pointerup', onPointerUp);
    canvas.addEventListener('pointercancel', onPointerUp);

    const onWheel = (e: WheelEvent) => {
      camDistTarget = clamp(camDistTarget + e.deltaY * 0.006, 5, 11);
      inputAt();
    };
    canvas.addEventListener('wheel', onWheel, { passive: true });

    /* ---------------- Resize ---------------- */

    const onResize = () => {
      const w = mount.clientWidth || window.innerWidth;
      const h = mount.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    /* ---------------- Boucle ---------------- */

    const clock = new THREE.Clock();
    let raf = 0;
    const axis = new THREE.Vector3();
    const rollQ = new THREE.Quaternion();
    const camDesired = new THREE.Vector3();
    const lookTarget = new THREE.Vector3(0, 1.4, 0);
    const tmpV = new THREE.Vector3();

    const loop = () => {
      raf = requestAnimationFrame(loop);
      if (document.hidden) {
        clock.getDelta();
        return;
      }
      const dt = Math.min(clock.getDelta(), 0.05);
      const t = clock.elapsedTime;

      /* ----- input ----- */
      let ix = 0;
      let iy = 0;
      if (keys.has('KeyW') || keys.has('ArrowUp')) iy += 1;
      if (keys.has('KeyS') || keys.has('ArrowDown')) iy -= 1;
      if (keys.has('KeyD') || keys.has('ArrowRight')) ix += 1;
      if (keys.has('KeyA') || keys.has('ArrowLeft')) ix -= 1;
      ix += joyVec.x;
      iy -= joyVec.y;
      const ilen = Math.hypot(ix, iy);
      if (ilen > 1) { ix /= ilen; iy /= ilen; }
      const sprint = keys.has('ShiftLeft') || keys.has('ShiftRight') ? 1.5 : 1;

      /* ----- physique ----- */
      const wet = isWater(p.x, p.z);
      const fx = -Math.sin(yawCam);
      const fz = -Math.cos(yawCam);
      const rx = -fz;
      const rz = fx;
      const accel = ACCEL * sprint * (wet ? 0.45 : 1);
      vel.x += (fx * iy + rx * ix) * accel * dt;
      vel.z += (fz * iy + rz * ix) * accel * dt;
      const fr = Math.exp(-(FRICTION + (wet ? 2.2 : 0)) * dt);
      vel.x *= fr;
      vel.z *= fr;
      if (wet) {
        const floatY = Math.max(terrainHeight(p.x, p.z), -0.35) + R * 0.6;
        vel.y += ((floatY - p.y) * 7.0 - vel.y * 2.4) * dt;
      } else {
        vel.y -= GRAV * dt;
      }
      p.addScaledVector(vel, dt);

      // sol
      const groundY = terrainHeight(p.x, p.z) + R;
      if (!wet && p.y <= groundY) {
        p.y = groundY;
        if (vel.y < 0) vel.y = 0;
        grounded = true;
      } else {
        grounded = false;
      }
      if (wet && p.y < Math.max(terrainHeight(p.x, p.z), -0.35) + R * 0.6 - 0.25) {
        p.y = Math.max(terrainHeight(p.x, p.z), -0.35) + R * 0.6 - 0.25;
      }

      // collisions arbres (cylindres)
      for (let i = 0; i < trees.length; i++) {
        const tr = trees[i];
        const dx = p.x - tr.x;
        const dz = p.z - tr.z;
        if (dx > 3 || dx < -3 || dz > 3 || dz < -3) continue;
        const minD = 0.55 * tr.s + R;
        const d2 = dx * dx + dz * dz;
        if (d2 < minD * minD && d2 > 1e-6) {
          const d = Math.sqrt(d2);
          const nx = dx / d;
          const nz = dz / d;
          p.x = tr.x + nx * minD;
          p.z = tr.z + nz * minD;
          const vn = vel.x * nx + vel.z * nz;
          if (vn < 0) {
            vel.x -= vn * nx * 1.35;
            vel.z -= vn * nz * 1.35;
          }
        }
      }
      // collisions rochers (sphères)
      for (let i = 0; i < rocks.length; i++) {
        const rk = rocks[i];
        const dx = p.x - rk.x;
        const dz = p.z - rk.z;
        if (dx > 4 || dx < -4 || dz > 4 || dz < -4) continue;
        const dy = p.y - rk.wy;
        const minD = Math.max(rk.sx, rk.sz) * 0.85 + R;
        const d = Math.sqrt(dx * dx + dz * dz + dy * dy);
        if (d < minD && d > 1e-6) {
          const nx = dx / d;
          const ny = dy / d;
          const nz = dz / d;
          p.x = rk.x + nx * minD;
          p.y = rk.wy + ny * minD;
          p.z = rk.z + nz * minD;
          const vn = vel.x * nx + vel.y * ny + vel.z * nz;
          if (vn < 0) {
            vel.x -= vn * nx * 1.3;
            vel.y -= vn * ny * 1.3;
            vel.z -= vn * nz * 1.3;
          }
        }
      }

      // bord du monde : rappel douce + clamp
      const overX = Math.abs(p.x) > LIMIT ? Math.abs(p.x) - LIMIT : 0;
      const overZ = Math.abs(p.z) > LIMIT ? Math.abs(p.z) - LIMIT : 0;
      if (overX > 0) vel.x -= Math.sign(p.x) * Math.min(overX, 4) * 6 * dt;
      if (overZ > 0) vel.z -= Math.sign(p.z) * Math.min(overZ, 4) * 6 * dt;
      p.x = clamp(p.x, -HARD_LIMIT, HARD_LIMIT);
      p.z = clamp(p.z, -HARD_LIMIT, HARD_LIMIT);

      // saut
      if (grounded && jumpRef.current) {
        vel.y = JUMP_V;
        grounded = false;
        jumpRef.current = false;
      }

      // roulement local (axe = up × vel)
      const sp = Math.hypot(vel.x, vel.z);
      if (sp > 0.05) {
        axis.set(vel.z / sp, 0, -vel.x / sp);
        rollQ.setFromAxisAngle(axis, (sp * dt) / R);
        visual.mesh.quaternion.premultiply(rollQ);
      }

      visual.group.position.copy(p);
      visual.tick(t);

      // ombre locale
      localBlob.mesh.position.set(p.x, terrainHeight(p.x, p.z) + 0.03, p.z);
      const hAbove = p.y - R - terrainHeight(p.x, p.z);
      localBlob.mat.opacity = clamp(0.5 - hAbove * 0.07, 0.08, 0.5);

      tickBubble(localBubble, dt);

      /* ----- joueurs distants ----- */
      const k = 1 - Math.exp(-9 * dt);
      for (const rp of remotes.values()) {
        rp.group.position.lerp(rp.target, k);
        tmpV.subVectors(rp.group.position, rp.prevPos);
        const dLen = Math.hypot(tmpV.x, tmpV.z);
        if (dLen > 0.002) {
          axis.set(tmpV.z / dLen, 0, -tmpV.x / dLen);
          rollQ.setFromAxisAngle(axis, dLen / R);
          rp.visual.mesh.quaternion.premultiply(rollQ);
        }
        rp.prevPos.copy(rp.group.position);
        rp.blob.position.set(rp.group.position.x, terrainHeight(rp.group.position.x, rp.group.position.z) + 0.03, rp.group.position.z);
        rp.blobMat.opacity = clamp(0.45 - (rp.group.position.y - terrainHeight(rp.group.position.x, rp.group.position.z) - R) * 0.07, 0.08, 0.45);
        tickBubble(rp.bubble, dt);
        if (rp.rainbow) rp.visual.tick(t);
      }

      /* ----- caméra ----- */
      camDist += (camDistTarget - camDist) * (1 - Math.exp(-6 * dt));
      if (performance.now() - lastInputAt > 4000) yawCam += 0.12 * dt; // orbite lente auto
      const cx = p.x + Math.sin(yawCam) * camDist;
      const cz = p.z + Math.cos(yawCam) * camDist;
      camDesired.set(cx, Math.max(p.y + 4.4, terrainHeight(cx, cz) + 1.6), cz);
      camera.position.lerp(camDesired, 1 - Math.exp(-4.5 * dt));
      lookTarget.lerp(tmpV.set(p.x, p.y + 1.2, p.z), 1 - Math.exp(-6 * dt));
      camera.lookAt(lookTarget);

      /* ----- ambiance ----- */
      waterMat.uniforms.uTime.value = t;
      capMat.opacity = 0.72 + 0.28 * Math.sin(t * 1.8);
      for (let i = 0; i < FIRE_COUNT; i++) {
        const ph = firePhase[i];
        firePos[i * 3] = fireBase[i * 3] + Math.sin(t * 0.21 + ph * 1.7) * 1.2;
        firePos[i * 3 + 1] = fireBase[i * 3 + 1] + Math.sin(t * 0.47 + ph) * 0.5;
        firePos[i * 3 + 2] = fireBase[i * 3 + 2] + Math.cos(t * 0.17 + ph * 2.3) * 1.2;
      }
      (fireGeo.attributes.position as THREE.BufferAttribute).needsUpdate = true;

      renderer.render(scene, camera);
    };
    raf = requestAnimationFrame(loop);

    crazyGames.gameplayStart();

    /* ---------------- Cleanup intégral ---------------- */

    return () => {
      window.clearInterval(moveTimer);
      window.clearInterval(pingTimer);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
      canvas.removeEventListener('pointerdown', onPointerDown);
      canvas.removeEventListener('pointermove', onPointerMove);
      canvas.removeEventListener('pointerup', onPointerUp);
      canvas.removeEventListener('pointercancel', onPointerUp);
      canvas.removeEventListener('wheel', onWheel);

      socket.off('connect', rejoin);
      socket.off('disconnect');
      socket.off('mp:joined', onJoined);
      socket.off('mp:player-joined', onPlayerJoined);
      socket.off('mp:player-left', onPlayerLeft);
      socket.off('mp:snap', onSnap);
      socket.off('mp:chat', onChat);
      socket.off('mp:sys', onSys);
      socket.emit('mp:leave');
      socket.removeAllListeners();
      socket.disconnect();
      socketRef.current = null;

      crazyGames.gameplayStop();

      window.cancelAnimationFrame(raf);
      clearRemotes();
      scene.remove(visual.group, localBlob.mesh, terrain, water, sky, moon, fireflies, trunks, folis, rockMesh);
      visual.dispose();
      localLabel.tex.dispose();
      (localLabel.sprite.material as THREE.SpriteMaterial).dispose();
      localBubble.tex.dispose();
      (localBubble.sprite.material as THREE.SpriteMaterial).dispose();
      localBlob.mat.dispose();
      terrain.geometry.dispose();
      (terrain.material as THREE.MeshStandardMaterial).dispose();
      water.geometry.dispose();
      waterMat.dispose();
      sky.geometry.dispose();
      skyMat.dispose();
      (moon.material as THREE.SpriteMaterial).map?.dispose();
      (moon.material as THREE.SpriteMaterial).dispose();
      fireGeo.dispose();
      (fireflies.material as THREE.PointsMaterial).dispose();
      trunks.geometry.dispose();
      trunkMat.dispose();
      folis.geometry.dispose();
      foliMat.dispose();
      rockMesh.geometry.dispose();
      rockMat.dispose();
      pylonGeo.dispose();
      pylonMat.dispose();
      capGeo.dispose();
      capMat.dispose();
      blobTex.dispose();
      blobGeo.dispose();
      scene.clear();
      envTex.dispose();
      pmrem.dispose();
      renderer.dispose();
      if (renderer.domElement.parentElement === mount) mount.removeChild(renderer.domElement);
    };
  }, [stage]);

  /* ============================================================
     Rendu JSX
  ============================================================ */

  /* ---------- Gate / Menu ---------- */

  if (stage !== 'arena') {
    return (
      <div className="relative flex min-h-[100dvh] w-full items-center justify-center overflow-hidden bg-[#12100d] p-4 text-[#efe7d8]">
        {/* Fond : lueurs chaudes */}
        <div aria-hidden className="pointer-events-none absolute inset-0">
          <div className="absolute -top-32 left-1/2 h-[420px] w-[420px] -translate-x-1/2 rounded-full bg-[#d4574b]/15 blur-[110px]" />
          <div className="absolute -bottom-24 right-0 h-[360px] w-[360px] rounded-full bg-[#ffc94a]/10 blur-[120px]" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_35%,rgba(10,9,7,0.8)_100%)]" />
        </div>

        <div className="relative z-10 w-full max-w-md rounded-3xl border border-white/10 bg-[#1e1c18]/90 p-6 shadow-2xl backdrop-blur sm:p-8">
          {/* Gate */}
          {stage === 'gate' && (
            <div className="flex flex-col items-center gap-5 py-6 text-center">
              {gateLocked ? (
                <>
                  <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[#d4574b]/15 text-[#ff8a7d]">
                    <Lock size={30} />
                  </div>
                  <h1 className="text-xl font-black tracking-tight">Multijoueur verrouillé</h1>
                  <p className="max-w-xs text-[13px] leading-relaxed text-[#c0b8a8]">
                    Désolé, mais le multijoueur est disponible uniquement sur CrazyGames.
                  </p>
                  <button
                    onClick={() => onExitRef.current()}
                    className="mt-2 min-h-[48px] w-full rounded-xl bg-[#d4574b] px-6 text-sm font-bold text-white shadow-[0_6px_20px_rgba(212,87,75,0.35)] transition hover:bg-[#e06a5e] active:scale-[0.98]"
                  >
                    Retour
                  </button>
                </>
              ) : (
                <>
                  <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[#ffc94a]/12 text-[#ffc94a]">
                    <Globe size={30} />
                  </div>
                  <h1 className="text-xl font-black tracking-tight">Multijoueur RBND</h1>
                  <p className="max-w-xs text-[13px] leading-relaxed text-[#c0b8a8]">
                    {gateChecking
                      ? 'Activation du multijoueur…'
                      : 'Prêt ! Choisis une salle pour rejoindre la carte ouverte.'}
                  </p>
                  <button
                    onClick={activateGate}
                    disabled={gateChecking}
                    className="mt-2 flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-[#d4574b] px-6 text-sm font-bold text-white shadow-[0_6px_20px_rgba(212,87,75,0.35)] transition hover:bg-[#e06a5e] active:scale-[0.98] disabled:opacity-60"
                  >
                    {gateChecking && <Loader2 size={15} className="animate-spin" />}
                    Activer le multijoueur
                  </button>
                </>
              )}
            </div>
          )}

          {/* Menu */}
          {stage === 'menu' && (
            <>
              <div className="text-center">
                <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-[#d4574b]">Carte ouverte</p>
                <h1 className="mt-1.5 text-2xl font-black tracking-tight">RBND — Multijoueur</h1>
                <p className="mt-1.5 text-[13px] text-[#c0b8a8]">
                  Explore une carte ouverte avec les autres joueurs
                </p>
              </div>

              <div className="mt-5 flex items-center justify-between rounded-xl border border-white/10 bg-black/25 px-3 py-2">
                <span className="flex items-center gap-2 text-[12px] text-[#c0b8a8]">
                  <span className="text-base leading-none">{ball.emoji}</span>
                  {ball.name}
                </span>
                <span className="max-w-[45%] truncate text-[12px] font-semibold text-[#efe7d8]">
                  {playerName || 'Anonyme'}
                </span>
              </div>

              <div className="mt-5 space-y-3">
                {connecting && (
                  <div className="flex items-center justify-center gap-2 rounded-xl border border-[#ffc94a]/25 bg-[#ffc94a]/10 py-2.5 text-[12px] font-semibold text-[#ffc94a]">
                    <Loader2 size={14} className="animate-spin" />
                    Connexion au serveur…
                  </div>
                )}

                {!createdCode ? (
                  <>
                    <button
                      onClick={() => startJoin(MP_PUBLIC_ROOM)}
                      disabled={connecting}
                      className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-[#d4574b] px-4 text-[14px] font-bold text-white shadow-[0_6px_20px_rgba(212,87,75,0.35)] transition hover:bg-[#e06a5e] active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <Globe size={16} />
                      Rejoindre le serveur public
                    </button>

                    <button
                      onClick={startCreate}
                      disabled={connecting}
                      className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl border border-white/20 bg-white/5 px-4 text-[13px] font-semibold text-[#e0d8c8] transition hover:bg-white/10 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <KeyRound size={15} />
                      Créer une salle privée
                    </button>

                    <div className="rounded-xl border border-white/10 bg-black/25 p-3">
                      <p className="mb-2 text-[10px] font-bold uppercase tracking-[0.2em] text-[#98907f]">
                        Rejoindre avec un code
                      </p>
                      <div className="flex gap-2">
                        <input
                          value={codeInput}
                          onChange={(e) => setCodeInput(e.target.value.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 4))}
                          maxLength={4}
                          placeholder="ABCD"
                          aria-label="Code de la salle"
                          autoCapitalize="characters"
                          className="h-12 min-w-0 flex-1 rounded-xl border border-white/15 bg-black/40 text-center text-lg font-black tracking-[0.4em] text-[#efe7d8] outline-none placeholder:text-[#5c554a] focus:border-[#d4574b]/70"
                        />
                        <button
                          onClick={() => startJoin(codeInput)}
                          disabled={codeInput.length !== 4 || connecting}
                          className="min-h-[48px] rounded-xl bg-[#ffc94a] px-5 text-[13px] font-bold text-[#241c0c] transition hover:bg-[#ffd76a] active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40"
                        >
                          Rejoindre
                        </button>
                      </div>
                      {joinError && (
                        <p className="mt-2 text-[11px] font-semibold text-[#ff8a7d]">{joinError}</p>
                      )}
                    </div>
                  </>
                ) : (
                  /* Grande carte code de salle */
                  <div className="rounded-2xl border border-[#ffc94a]/30 bg-black/30 p-5 text-center">
                    <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#98907f]">
                      Salle privée créée
                    </p>
                    <p className="mt-3 text-[13px] text-[#c0b8a8]">Code de la salle :</p>
                    <p className="mt-1 text-4xl font-black tracking-[0.28em] text-[#ffc94a]">{createdCode}</p>
                    <button
                      onClick={copyCreated}
                      className="mt-4 inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/10 px-4 text-[13px] font-semibold text-[#e0d8c8] transition hover:bg-white/15 active:scale-[0.98]"
                    >
                      {copiedCode ? <Check size={15} className="text-[#8fe08f]" /> : <Copy size={15} />}
                      {copiedCode ? 'Copié !' : 'Copier le code'}
                    </button>
                    <p className="mt-3 flex items-center justify-center gap-2 text-[11px] text-[#98907f]">
                      <Loader2 size={12} className="animate-spin" />
                      Entrée dans l&rsquo;arène…
                    </p>
                  </div>
                )}

                <button
                  onClick={quit}
                  disabled={connecting}
                  className="min-h-[44px] w-full rounded-xl px-4 text-[12px] font-semibold text-[#98907f] transition hover:text-[#c0b8a8] active:scale-[0.98] disabled:opacity-40"
                >
                  Retour
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    );
  }

  /* ---------- Arène ---------- */

  return (
    <div className="fixed inset-0 z-40 select-none bg-[#12100d] text-[#efe7d8]">
      <div ref={mountRef} className="absolute inset-0" />

      {/* Joystick virtuel tactile */}
      <div ref={joyRef} className="pointer-events-none absolute z-10 hidden" style={{ width: 120, height: 120 }}>
        <div className="h-full w-full rounded-full border-2 border-white/25 bg-black/30 backdrop-blur-sm" />
        <div
          ref={joyThumbRef}
          className="absolute left-1/2 top-1/2 h-12 w-12 rounded-full bg-[#d4574b]/85 shadow-lg"
          style={{ transform: 'translate(-50%, -50%)' }}
        />
      </div>

      {/* ---------- HUD ---------- */}
      <div className="pointer-events-none absolute inset-0 z-10">
        {/* Haut gauche : chat + signalement */}
        <div className="pointer-events-auto absolute left-3 top-[calc(12px+env(safe-area-inset-top,0px))] w-[260px] max-w-[calc(100vw-190px)]">
          <div className="overflow-hidden rounded-2xl border border-white/10 bg-black/45 shadow-xl backdrop-blur-md">
            <div className="flex items-center justify-between px-3 py-2">
              <span className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.18em] text-[#98907f]">
                <MessageCircle size={12} />
                Discussion
              </span>
              <button
                onClick={() => setChatOpen((o) => !o)}
                aria-label={chatOpen ? 'Réduire le chat' : 'Déplier le chat'}
                className="rounded-md p-1 text-[#c0b8a8] transition hover:bg-white/10 active:scale-90"
              >
                {chatOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
              </button>
            </div>
            {chatOpen && (
              <>
                <div
                  ref={chatListRef}
                  className="max-h-40 space-y-1 overflow-y-auto px-3 pb-1 text-[11px] leading-snug [&::-webkit-scrollbar]:w-1 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-white/15 [&::-webkit-scrollbar-track]:bg-transparent"
                >
                  {messages.length === 0 && (
                    <p className="py-2 text-center text-[10px] italic text-[#7a7264]">
                      Aucun message — dis bonjour !
                    </p>
                  )}
                  {messages.map((m) =>
                    m.sys ? (
                      <p key={m.key} className="italic text-[#98907f]">{m.text}</p>
                    ) : (
                      <p key={m.key} className="text-[#d8d0c0]">
                        <span
                          className="font-semibold"
                          style={{ color: m.id === youId ? '#ffc94a' : '#c0b8a8' }}
                        >
                          {m.name}
                        </span>
                        <span className="text-[#8a8274]"> : </span>
                        <span>{m.text}</span>
                        {m.from && m.from !== youId && (
                          <button
                            onClick={() => reportPlayer(m)}
                            title="Signaler et masquer ce joueur"
                            aria-label={`Signaler ${m.name}`}
                            className="ml-1.5 inline-flex rounded p-0.5 align-middle text-[#8a8274] transition hover:bg-[#d4574b]/25 hover:text-[#ff8a7d]"
                          >
                            <Flag size={11} />
                          </button>
                        )}
                      </p>
                    )
                  )}
                </div>
                <form
                  onSubmit={(e) => { e.preventDefault(); sendChat(); }}
                  className="flex items-center gap-1.5 p-2 pt-1"
                >
                  <input
                    value={chatDraft}
                    onChange={(e) => setChatDraft(e.target.value.slice(0, 200))}
                    maxLength={200}
                    placeholder="Message…"
                    aria-label="Écrire un message"
                    className="h-8 min-w-0 flex-1 rounded-lg border border-white/10 bg-black/40 px-2.5 text-[11px] text-[#efe7d8] outline-none placeholder:text-[#7a7264] focus:border-[#d4574b]/60"
                  />
                  <button
                    type="submit"
                    disabled={!chatDraft.trim()}
                    aria-label="Envoyer le message"
                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#d4574b] text-white transition active:scale-90 disabled:opacity-40"
                  >
                    <Send size={13} />
                  </button>
                </form>
              </>
            )}
          </div>
        </div>

        {/* Haut centre : salle + joueurs + latence */}
        <div className="absolute left-1/2 top-[calc(12px+env(safe-area-inset-top,0px))] flex max-w-[92vw] -translate-x-1/2 flex-wrap items-center justify-center gap-2">
          <div className="flex items-center gap-2.5 rounded-full border border-white/10 bg-black/45 px-3.5 py-1.5 text-[11px] font-semibold backdrop-blur-md">
            <span className="text-[#c0b8a8]">
              {room === MP_PUBLIC_ROOM ? 'Salle publique' : `Salle ${room ?? ''}`}
            </span>
            {room && room !== MP_PUBLIC_ROOM && (
              <button
                onClick={copyPill}
                aria-label="Copier le code de la salle"
                className="rounded p-0.5 text-[#98907f] transition hover:text-[#efe7d8] active:scale-90"
              >
                {copiedPill ? <Check size={12} className="text-[#8fe08f]" /> : <Copy size={12} />}
              </button>
            )}
            <span className="tabular-nums text-[#c0b8a8]">👥 {playerCount}</span>
            <span className="tabular-nums text-[#ffc94a]">
              {latency !== null ? `${latency} ms` : '— ms'}
            </span>
          </div>
        </div>

        {/* Haut droite : quitter */}
        <button
          onClick={quit}
          className="pointer-events-auto absolute right-3 top-[calc(12px+env(safe-area-inset-top,0px))] flex min-h-[44px] items-center gap-1.5 rounded-2xl border border-white/10 bg-black/45 px-4 text-[12px] font-semibold text-[#e0d8c8] backdrop-blur-md transition hover:bg-[#d4574b]/80 active:scale-95"
        >
          <DoorOpen size={15} />
          Quitter
        </button>

        {/* Bas gauche : aide contrôles (desktop) */}
        <div className="absolute bottom-3 left-3 hidden rounded-full border border-white/10 bg-black/40 px-3 py-1.5 text-[10px] text-[#c0b8a8] backdrop-blur-md sm:block">
          WASD / ZQSD se déplacer · Espace sauter · Maj sprint · Molette zoom
        </div>

        {/* Bas droite : bouton saut (tactile) */}
        <button
          onPointerDown={() => { jumpRef.current = true; }}
          aria-label="Sauter"
          className="pointer-events-auto absolute bottom-[calc(24px+env(safe-area-inset-bottom,0px))] right-5 hidden h-16 w-16 items-center justify-center rounded-full border border-white/20 bg-[#d4574b]/85 text-white shadow-xl backdrop-blur-md transition active:scale-90 [@media(pointer:coarse)]:flex"
        >
          <ChevronsUp size={26} />
        </button>
      </div>
    </div>
  );
}
