/* ============================================================
   Wrapper SDK CrazyGames v3
   - Toutes les pubs (rewarded / midgame) passent par le SDK.
   - gameplayStart/Stop + happytime pour l'intégration CrazyGames.
   - Fallback : si le SDK n'est pas disponible (aperçu local hors
     CrazyGames), une pub simulée plein écran est affichée pour que
     le flux complet reste testable. En production sur CrazyGames,
     le vrai SDK est utilisé.
============================================================ */

export type AdType = 'rewarded' | 'midgame';

export interface AdCallbacks {
  adStarted: () => void;
  adFinished: () => void;
  adError: (error: unknown) => void;
}

type SdkGame = {
  gameplayStart: () => void;
  gameplayStop: () => void;
  happytime: () => void;
  loadingStart?: () => void;
  loadingStop?: () => void;
};

type CrazySdk = {
  init: () => Promise<void>;
  environment?: string;
  game: SdkGame;
  ad: {
    requestAd: (type: AdType, callbacks: AdCallbacks) => void;
    hasAdblock?: () => Promise<boolean>;
  };
};

declare global {
  interface Window {
    CrazyGames?: {
      SDK?: CrazySdk;
    };
  }
}

const SDK_URL = 'https://sdk.crazygames.com/crazygames-sdk-v3.js';
const INIT_TIMEOUT_MS = 12000;

class CrazyGamesService {
  private sdk: CrazySdk | null = null;
  private ready = false;
  private initPromise: Promise<boolean> | null = null;
  /** silence audio pendant les pubs */
  private muteHandler: ((muted: boolean) => void) | null = null;

  setMuteHandler(fn: (muted: boolean) => void) {
    this.muteHandler = fn;
  }

  /** Injecte le script SDK et tente l'init. Résout false si indisponible. */
  init(): Promise<boolean> {
    if (this.initPromise) return this.initPromise;
    this.initPromise = this.doInit().catch(() => false);
    return this.initPromise;
  }

  private doInit(): Promise<boolean> {
    return new Promise((resolve) => {
      if (typeof window === 'undefined') return resolve(false);
      if (window.CrazyGames?.SDK) {
        this.finishInit(window.CrazyGames.SDK, resolve);
        return;
      }
      const script = document.createElement('script');
      script.src = SDK_URL;
      script.async = true;
      const timeout = setTimeout(() => resolve(false), INIT_TIMEOUT_MS);
      script.onload = () => {
        if (window.CrazyGames?.SDK) {
          this.finishInit(window.CrazyGames.SDK, (ok) => {
            clearTimeout(timeout);
            resolve(ok);
          });
        } else {
          clearTimeout(timeout);
          resolve(false);
        }
      };
      script.onerror = () => {
        clearTimeout(timeout);
        resolve(false);
      };
      document.head.appendChild(script);
    });
  }

  private finishInit(sdk: CrazySdk, resolve: (ok: boolean) => void) {
    sdk.init()
      .then(() => {
        this.sdk = sdk;
        this.ready = true;
        console.log('[CrazyGames] SDK initialisé, environnement :', sdk.environment ?? 'inconnu');
        resolve(true);
      })
      .catch((err) => {
        console.warn('[CrazyGames] init() a échoué, mode simulation :', err);
        resolve(false);
      });
  }

  isReady(): boolean {
    return this.ready;
  }

  /* ---------------- Événements de gameplay ---------------- */

  gameplayStart() {
    if (this.ready) {
      try { this.sdk!.game.gameplayStart(); } catch { /* noop */ }
    }
  }

  gameplayStop() {
    if (this.ready) {
      try { this.sdk!.game.gameplayStop(); } catch { /* noop */ }
    }
  }

  happytime() {
    if (this.ready) {
      try { this.sdk!.game.happytime(); } catch { /* noop */ }
    }
  }

  /* ---------------- Publicités ---------------- */

  /**
   * Demande une pub au SDK CrazyGames.
   * rewarded → récompensée (x2 XP, bonus quotidien…)
   * midgame  → obligatoire (aucune récompense)
   * Fallback local : pub simulée (compte à rebours) pour garder le flux.
   */
  requestAd(type: AdType, callbacks: AdCallbacks) {
    if (this.ready) {
      let started = false;
      try {
        this.sdk!.ad.requestAd(type, {
          adStarted: () => {
            started = true;
            this.muteHandler?.(true);
            callbacks.adStarted();
          },
          adFinished: () => {
            this.muteHandler?.(false);
            callbacks.adFinished();
          },
          adError: (error) => {
            if (started) this.muteHandler?.(false);
            callbacks.adError(error);
          },
        });
        return;
      } catch (err) {
        console.warn('[CrazyGames] requestAd a échoué, simulation :', err);
      }
    }
    this.simulateAd(type, callbacks);
  }

  /** Pub simulée (uniquement quand le SDK est indisponible). */
  private simulateAd(type: AdType, callbacks: AdCallbacks) {
    if (typeof document === 'undefined') return;
    const duration = type === 'rewarded' ? 5 : 3;
    const label = type === 'rewarded' ? 'Publicité récompensée' : 'Publicité obligatoire';
    const overlay = document.createElement('div');
    overlay.style.cssText = `position:fixed;inset:0;z-index:9999;background:rgba(10,9,7,0.96);
      display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;
      color:#e0d8c8;font-family:system-ui,-apple-system,sans-serif;text-align:center;padding:24px;`;
    overlay.innerHTML = `
      <div style="font-size:13px;letter-spacing:.3em;text-transform:uppercase;color:#98907f;">${label}</div>
      <div style="font-size:52px;font-weight:800;font-variant-numeric:tabular-nums;" id="cg-count">${duration}</div>
      <div style="max-width:420px;font-size:12px;line-height:1.7;color:#98907f;">
        Pub simulée — le SDK CrazyGames n'est pas disponible dans cet aperçu local.<br/>
        Sur CrazyGames, une vraie publicité sera diffusée ici.
      </div>
      <div style="margin-top:6px;width:220px;height:6px;border-radius:3px;background:rgba(255,255,255,.12);overflow:hidden;">
        <div id="cg-bar" style="height:100%;width:0%;background:#d4574b;transition:width .95s linear;"></div>
      </div>`;
    document.body.appendChild(overlay);
    this.muteHandler?.(true);
    callbacks.adStarted();

    let remain = duration;
    const bar = overlay.querySelector('#cg-bar') as HTMLElement | null;
    if (bar) bar.style.width = '100%';
    const timer = setInterval(() => {
      remain -= 1;
      const count = overlay.querySelector('#cg-count');
      if (count) count.textContent = String(Math.max(0, remain));
      if (remain <= 0) {
        clearInterval(timer);
        overlay.remove();
        this.muteHandler?.(false);
        callbacks.adFinished();
      }
    }, 1000);
  }
}

export const crazyGames = new CrazyGamesService();
