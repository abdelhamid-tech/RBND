/* ============================================================
   Types partagés — Laboratoire de Physique
   Contrat unique entre frontend et backend.
============================================================ */

/** Types de défis jouables */
export type ChallengeType = 'collect' | 'survival' | 'combo';

/** Définition d'un niveau/défi (400 niveaux générés de façon déterministe) */
export interface LevelDef {
  id: number;
  /** monde (chapitre) 1..20 — 20 niveaux par monde */
  chapter: number;
  name: string;
  type: ChallengeType;
  description: string;
  /** Astuce affichée avant le départ */
  hint: string;
  /** collect : nombre de cibles à collecter */
  targets?: number;
  /** collect : dont ce nombre de cibles en hauteur (à atteindre en rebondissant) */
  elevated?: number;
  /** combo : objectif d'enchaînement de rebonds */
  comboGoal?: number;
  /** survival / combo / collect : durée en secondes (survival = durée à survivre, autres = limite) */
  timeLimit: number;
  /** survival : temps de repos au sol toléré en continu (secondes) */
  restLimit?: number;
  /** nombre d'obstacles actifs dans l'arène (0 à 12) */
  obstacleCount: number;
  /** nombre de bumpers (butées de flipper) dans l'arène */
  bumpers: number;
  /** nombre d'obstacles mobiles (oscillants) */
  movers: number;
  /** true : un portail de téléportation est présent */
  portals: boolean;
  /** true : niveau BOSS de fin de monde (récompense majorée) */
  isBoss: boolean;
  /** XP gagné à la première complétion */
  xpReward: number;
  /** difficulté 1 à 3 étoiles */
  stars: 1 | 2 | 3;
}

/** Définition statique d'un ballon de la boutique */
export interface BallDef {
  id: string;
  name: string;
  emoji: string;
  /** prix en XP (0 = gratuit) */
  price: number;
  description: string;
  /** texture équirectangulaire publique (/balls/xxx.jpg) ou null */
  texture: string | null;
  /** texture procédurale générée au runtime (canvas) */
  procTex?: 'soccer' | 'basketball' | 'beach' | 'tennis' | 'golf' | 'bowling' | 'eight' | 'disco' | 'galaxy' | 'lava' | 'candy' | 'moon';
  /** vignette de la boutique (/balls/xxx.jpg) ou null = rendu CSS */
  preview: string | null;
  /** couleur de base (hex number) */
  color: number;
  roughness: number;
  metalness: number;
  clearcoat: number;
  clearcoatRoughness: number;
  emissive: number;
  emissiveIntensity: number;
  /** couleur de la lueur autour du ballon */
  glowColor: number;
  /** intensité de la lueur 0..2 */
  glowPower: number;
  /** restitution (rebond) 0..1 */
  restitution: number;
  /** multiplicateur de gravité (ballon léger = flottant) */
  gravityFactor: number;
  /** mix des particules : 0 = neutre/sable, 1 = couleur du ballon */
  particleShade: number;
  /** particules de feu (météore) */
  fireParticles: boolean;
  /** opacité du matériau (ballons de verre/glace), 1 par défaut */
  opacity?: number;
  /** true : teinte animée arc-en-ciel (émissive + lueur) */
  rainbow?: boolean;
  /** tagline courte pour la boutique */
  tagline: string;
  /** couleur CSS de la vignette dégradée si preview=null */
  previewColor: string;
}

/* ---------------- DTOs API ---------------- */

/** Joueur tel que renvoyé par l'API */
export interface PlayerDTO {
  id: string;
  totalXp: number;
  /** niveau joueur calculé */
  level: number;
  /** XP progressée dans le niveau courant */
  xpIntoLevel: number;
  /** XP nécessaire pour le niveau suivant */
  xpForNext: number;
  selectedBall: string;
  ownedBalls: string[];
  completedLevels: number[];
  /** true si le bonus pub (24h) est réclamable */
  canClaimAdBonus: boolean;
  /** ISO date du prochain bonus pub disponible, null si disponible maintenant */
  nextAdBonusAt: string | null;
  /** nombre de pubs rewarded regardées */
  adsWatched: number;
}

/** POST /api/player/complete — réponse */
export interface CompleteResponse {
  ok: boolean;
  firstCompletion: boolean;
  xpGained: number;
  /** true si le joueur a monté d'un niveau grâce à cette complétion */
  levelUp: boolean;
  player: PlayerDTO;
  error?: string;
}

/** POST /api/player/ad-bonus — réponse */
export interface AdBonusResponse {
  ok: boolean;
  xpGained: number;
  player: PlayerDTO;
  error?: string;
}

/** POST /api/player/xp — réponse (utilisé pour doubler l'XP après pub rewarded) */
export interface XpResponse {
  ok: boolean;
  xpGained: number;
  levelUp: boolean;
  player: PlayerDTO;
  error?: string;
}

/** Réponse générique d'achat / sélection */
export interface ActionResponse {
  ok: boolean;
  player: PlayerDTO;
  error?: string;
}
