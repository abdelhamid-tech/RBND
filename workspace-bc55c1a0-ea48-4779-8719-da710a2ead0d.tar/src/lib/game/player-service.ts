/* ============================================================
   Service joueur — serveur uniquement.
   Accès DB Prisma (via @/lib/db) + mapping vers les DTOs
   partagés définis dans ./types.ts.
   Ne jamais importer ce fichier côté client.
============================================================ */

import type { Player } from "@prisma/client";
import { NextResponse, type NextRequest } from "next/server";
import { db } from "@/lib/db";
import { AD_BONUS_COOLDOWN_MS, computeLevel } from "./xp";
import type { PlayerDTO } from "./types";

const PID_REGEX = /^[a-zA-Z0-9_-]+$/;

/** Erreur de validation (→ HTTP 400). */
export class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ValidationError";
  }
}

/** Valide le pid : string de 8 à 64 caractères, [a-zA-Z0-9_-] uniquement. */
export function validatePid(pid: unknown): string {
  if (
    typeof pid !== "string" ||
    pid.length < 8 ||
    pid.length > 64 ||
    !PID_REGEX.test(pid)
  ) {
    throw new ValidationError("pid invalide");
  }
  return pid;
}

/** Récupère le joueur ou le crée (upsert). Lance ValidationError si pid invalide. */
export async function getOrCreatePlayer(pid: string): Promise<Player> {
  const id = validatePid(pid);
  return db.player.upsert({
    where: { id },
    update: {},
    create: { id },
  });
}

/* ---------------- Helpers CSV ---------------- */

/** "classic,soccer" → ["classic","soccer"] */
export function parseCsvStrings(csv: string): string[] {
  return csv
    .split(",")
    .map((s) => s.trim())
    .filter((s) => s.length > 0);
}

/** "1,2,3" → [1,2,3] (ignore les fragments non entiers) */
export function parseCsvNumbers(csv: string): number[] {
  return parseCsvStrings(csv)
    .map((s) => Number(s))
    .filter((n) => Number.isInteger(n));
}

/** Ajoute une valeur à une liste CSV, sans doublon. */
export function addToCsv(csv: string, value: string): string {
  const set = new Set(parseCsvStrings(csv));
  set.add(value);
  return [...set].join(",");
}

/** Ajoute un id de niveau à la liste CSV (triée numériquement). */
export function addLevelToCsv(csv: string, levelId: number): string {
  const set = new Set(parseCsvNumbers(csv));
  set.add(levelId);
  return [...set].sort((a, b) => a - b).join(",");
}

export function csvHasLevel(csv: string, levelId: number): boolean {
  return parseCsvNumbers(csv).includes(levelId);
}

/* ---------------- DTO ---------------- */

/** Mapping ligne Prisma → PlayerDTO (contrat ./types.ts). */
export function toDTO(row: Player): PlayerDTO {
  const { level, xpIntoLevel, xpForNext } = computeLevel(row.totalXp);

  let canClaimAdBonus = true;
  let nextAdBonusAt: string | null = null;
  if (row.lastAdBonusAt) {
    const readyAtMs = row.lastAdBonusAt.getTime() + AD_BONUS_COOLDOWN_MS;
    canClaimAdBonus = Date.now() >= readyAtMs;
    if (!canClaimAdBonus) {
      nextAdBonusAt = new Date(readyAtMs).toISOString();
    }
  }

  return {
    id: row.id,
    totalXp: row.totalXp,
    level,
    xpIntoLevel,
    xpForNext,
    selectedBall: row.selectedBall,
    ownedBalls: parseCsvStrings(row.ownedBalls),
    completedLevels: parseCsvNumbers(row.completedLvls),
    canClaimAdBonus,
    nextAdBonusAt,
    adsWatched: row.adsWatched,
  };
}

/** Réponse d'erreur JSON normalisée { ok: false, error }. */
export function errorResponse(message: string, status: number): NextResponse {
  return NextResponse.json({ ok: false, error: message }, { status });
}

/** Parse le body JSON d'une requête, null si invalide. */
export async function readJsonBody(req: NextRequest): Promise<unknown> {
  return (await req.json().catch(() => null)) as unknown;
}
