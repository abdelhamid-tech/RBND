import type { LevelDef, ChallengeType } from './types';

/* ============================================================
   Campagne — 400 défis répartis en 20 mondes de 20 niveaux.
   Génération 100 % déterministe (RNG seedé par l'id) : le même
   niveau est identique côté client ET côté serveur (API).
   - collect  : collecter des cibles lumineuses avant la fin du temps
   - survival : ne pas laisser le ballon reposer au sol
   - combo    : enchaîner des rebonds rapprochés (chaîne)
   Mécaniques qui se débloquent au fil des mondes :
   - Monde 3+  : bumpers (butées de flipper)
   - Monde 4+  : obstacles mobiles
   - Monde 6+  : portails de téléportation
   - Fin de monde (niveau ×20) : BOSS à récompense majorée
============================================================ */

/* ---------------- Mondes (thèmes visuels de l'arène) ---------------- */

export interface ChapterDef {
  id: number;
  name: string;
  tagline: string;
  /** couleur d'accent principale (hex) */
  accent: number;
  /** couleur d'accent secondaire (hex) */
  accent2: number;
  /** couleurs du ciel : haut / bas */
  skyTop: number;
  skyBot: number;
}

export const CHAPTERS: ChapterDef[] = [
  { id: 1,  name: 'Le Laboratoire',        tagline: 'Où tout commence',              accent: 0xd4574b, accent2: 0xffc94a, skyTop: 0x2a2520, skyBot: 0x1a1814 },
  { id: 2,  name: 'Serre Néon',            tagline: 'Des plantes qui brillent',      accent: 0x2bd48f, accent2: 0xa4ff5e, skyTop: 0x14261e, skyBot: 0x0c1712 },
  { id: 3,  name: 'Forge de Magma',        tagline: 'Chaleur et métal en fusion',    accent: 0xff6a3a, accent2: 0xffb347, skyTop: 0x2b150e, skyBot: 0x180b07 },
  { id: 4,  name: 'Cité de Cristal',       tagline: 'Tours de verre scintillantes',  accent: 0xe86bd4, accent2: 0xb388ff, skyTop: 0x241428, skyBot: 0x150b18 },
  { id: 5,  name: 'Océan Digital',         tagline: 'Vagues de données',             accent: 0x35d0c0, accent2: 0x7affe0, skyTop: 0x0f2528, skyBot: 0x081518 },
  { id: 6,  name: 'Zone Glacée',           tagline: 'Rebonds sur glace vive',        accent: 0x9ad6ff, accent2: 0xe8f7ff, skyTop: 0x16222c, skyBot: 0x0c141c },
  { id: 7,  name: 'Temple d’Or',           tagline: 'Ruines dorées oubliées',        accent: 0xffc94a, accent2: 0xffe9a8, skyTop: 0x29200f, skyBot: 0x171106 },
  { id: 8,  name: 'Jardin Électrique',     tagline: 'Nature surchargée',             accent: 0xb7ff4a, accent2: 0x2bd48f, skyTop: 0x1a2410, skyBot: 0x0f150a },
  { id: 9,  name: 'Cratère Pourpre',       tagline: 'Cœur d’une étoile morte',       accent: 0xb05cff, accent2: 0xff6a5e, skyTop: 0x1f1129, skyBot: 0x120a18 },
  { id: 10, name: 'Observatoire Céleste',  tagline: 'Entre les constellations',      accent: 0x6bd4e8, accent2: 0xffd27a, skyTop: 0x101c26, skyBot: 0x0a1016 },
  { id: 11, name: 'Usine Chrome',          tagline: 'Machines sans âme',             accent: 0xc0c8d0, accent2: 0xff6a3a, skyTop: 0x1c1e22, skyBot: 0x101214 },
  { id: 12, name: 'Grotte de Lave',        tagline: 'Profondeurs incandescentes',    accent: 0xff4a3a, accent2: 0xff9a3a, skyTop: 0x26100c, skyBot: 0x160806 },
  { id: 13, name: 'Forêt Luminescente',    tagline: 'Spores flottantes',             accent: 0x4affc0, accent2: 0xd4ff6a, skyTop: 0x0e2418, skyBot: 0x08160f },
  { id: 14, name: 'Station Orbitale',      tagline: 'Zéro gravité apparente',        accent: 0xe8f0ff, accent2: 0x8fb8ff, skyTop: 0x141821, skyBot: 0x0b0d14 },
  { id: 15, name: 'Cirque Néon',           tagline: 'Pistes de lumière',             accent: 0xff6bb8, accent2: 0xffd23f, skyTop: 0x26101c, skyBot: 0x160a10 },
  { id: 16, name: 'Désert de Verre',       tagline: 'Dunes polies par le vent',      accent: 0xffb84d, accent2: 0xff7a3a, skyTop: 0x281a0c, skyBot: 0x170f07 },
  { id: 17, name: 'Abysse Violet',         tagline: 'Le vide qui chante',            accent: 0x8a4aff, accent2: 0xff4aff, skyTop: 0x170f26, skyBot: 0x0d0816 },
  { id: 18, name: 'Cœur Quantique',        tagline: 'Réalité instable',              accent: 0x4affff, accent2: 0xb05cff, skyTop: 0x0c2026, skyBot: 0x071318 },
  { id: 19, name: 'Couronne Solaire',      tagline: 'Aux portes du feu',             accent: 0xffcf5a, accent2: 0xff5a3a, skyTop: 0x2a1c0a, skyBot: 0x180f06 },
  { id: 20, name: 'Le Big Bang',           tagline: 'L’épreuve finale',              accent: 0xffffff, accent2: 0xff6a5e, skyTop: 0x241f2b, skyBot: 0x120e16 },
];

/* ---------------- Paliers de difficulté ---------------- */

export type Tier = 'Facile' | 'Difficile' | 'Extrême' | 'Cauchemar';

/** Palier de difficulté pour un niveau donné */
export function tierOf(id: number): Tier {
  if (id <= 100) return 'Facile';
  if (id <= 220) return 'Difficile';
  if (id <= 330) return 'Extrême';
  return 'Cauchemar';
}

export const TOTAL_LEVELS = 400;
export const TOTAL_CHAPTERS = CHAPTERS.length;
export const LEVELS_PER_CHAPTER = 20;

/** Numéro romain 1..20 */
export function romanChapter(n: number): string {
  const R = ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X',
    'XI', 'XII', 'XIII', 'XIV', 'XV', 'XVI', 'XVII', 'XVIII', 'XIX', 'XX'];
  return R[Math.max(0, Math.min(20, n))];
}

/** Monde d'un niveau donné */
export function chapterOf(id: number): ChapterDef {
  return CHAPTERS[Math.min(TOTAL_CHAPTERS, Math.ceil(id / LEVELS_PER_CHAPTER)) - 1];
}

/* ---------------- RNG déterministe ---------------- */

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ---------------- Bancs de noms ---------------- */

const NAME_POOLS: Record<ChallengeType, string[]> = {
  collect: ['Moisson', 'Chasse aux Cibles', 'Récolte', 'Précision', 'Salve', 'Pluie d’Étoiles', 'Traque', 'Frénésie', 'Vision Laser', 'Cibles Vivantes', 'Éclipse', 'À l’Affût'],
  survival: ['Endurance', 'Sans Filet', 'Marathon', 'Ténacité', 'Vertige', 'Souffle Long', 'Équilibre', 'Résistance', 'Sans Faute', 'Jamais à Terre', 'Permanent', 'Le Long Courrier'],
  combo: ['Rythme', 'Grande Chaîne', 'Tempo', 'Cascades', 'Métronome', 'Élan', 'Séquence', 'Percussion', 'Staccato', 'Roulement', 'Virtuose', 'Sans Répit'],
};

const HINTS: Record<ChallengeType, string[]> = {
  collect: [
    'Les cibles en hauteur exigent une impulsion (clic) au bon moment.',
    'Planifiez votre itinéraire : visez la cible suivante avant même la collecte.',
    'Utilisez les obstacles comme rampes de lancement.',
    'Les bumpers propulsent le ballon à grande vitesse — servez-vous en !',
  ],
  survival: [
    'Cliquez régulièrement pour relancer le ballon avant qu’il ne s’arrête.',
    'Anticipez la chute : relancez pendant la descente, pas au sol.',
    'Le rythme est roi : gardez le ballon en mouvement permanent.',
    'Restez au centre : moins de distance à parcourir pour relancer.',
  ],
  combo: [
    'Un rebond sur mur, obstacle, bumper ou sol compte. Ne cassez pas la chaîne !',
    'Coincer le ballon entre deux murs fait des merveilles.',
    'Les bumpers relancent la chaîne avec puissance.',
    'Gardez de la vitesse : chaque impact doit arriver avant la fin de la fenêtre.',
  ],
};

/* ---------------- Génération des 400 niveaux ---------------- */

function buildLevels(): LevelDef[] {
  const levels: LevelDef[] = [];

  for (let id = 1; id <= TOTAL_LEVELS; id++) {
    const rng = mulberry32(id * 7919 + 1013);
    const chapter = Math.ceil(id / LEVELS_PER_CHAPTER);
    const idxInCh = id - (chapter - 1) * LEVELS_PER_CHAPTER; // 1..20
    const isBoss = idxInCh === LEVELS_PER_CHAPTER;
    const t = id / TOTAL_LEVELS; // progression globale 0..1

    /* --- type de défi --- */
    let type: ChallengeType;
    if (isBoss) {
      type = (['collect', 'survival', 'combo'] as const)[chapter % 3];
    } else {
      const wCollect = 5;
      const wCombo = 3;
      const wSurvival = 1 + 4 * t; // la survie prend de l'importance
      const total = wCollect + wCombo + wSurvival;
      const roll = rng() * total;
      type = roll < wCollect ? 'collect' : roll < wCollect + wCombo ? 'combo' : 'survival';
    }

    /* --- paramètres par type (difficulté croissante) --- */
    let targets: number | undefined;
    let elevated: number | undefined;
    let comboGoal: number | undefined;
    let restLimit: number | undefined;
    let timeLimit: number;

    if (type === 'collect') {
      targets = Math.max(3, Math.round(3 + t * t * 22 + rng() * 3));
      elevated = Math.floor(targets * (0.22 + 0.38 * t));
      timeLimit = Math.min(120, Math.round(targets * (6.4 - 2.6 * t) + 16 + rng() * 6));
      if (isBoss) { targets += 4; elevated += 2; timeLimit += 10; }
    } else if (type === 'combo') {
      comboGoal = Math.max(6, Math.min(55, Math.round(7 + t * 44 + (rng() * 6 - 3))));
      timeLimit = Math.round(38 + comboGoal * 1.15 + t * 12);
      if (isBoss) { comboGoal += 6; timeLimit += 12; }
    } else {
      timeLimit = Math.round(20 + 78 * t);
      restLimit = Math.round((2.6 - 1.15 * t) * 10) / 10;
      if (isBoss) { timeLimit += 15; restLimit = Math.max(1.1, restLimit - 0.2); }
    }

    /* --- mécaniques d'arène --- */
    const obstacleCount = Math.min(12, 2 + Math.floor((id - 1) / 34) + (isBoss ? 2 : 0));
    const bumpers = chapter >= 3 ? Math.min(4, 1 + Math.floor((chapter - 3) / 4)) : 0;
    const movers = chapter >= 4 ? Math.min(6, Math.floor((chapter - 2) / 2)) : 0;
    const portals = chapter >= 6;

    /* --- récompense / étoiles --- */
    const xpReward = 50 + Math.round(id * 2.5) + (isBoss ? 80 + Math.round(id * 0.6) : 0);
    const stars: 1 | 2 | 3 = isBoss ? 3 : t < 0.3 ? 1 : t < 0.65 ? 2 : 3;

    /* --- nom + textes --- */
    const pool = NAME_POOLS[type];
    const base = pool[(idxInCh * 5 + chapter * 3) % pool.length];
    const suffix = chapter > 1 ? ` ${romanChapter(chapter)}` : '';
    const name = isBoss ? `BOSS · ${base}` : `${base}${suffix}`;
    const hint = HINTS[type][(chapter + idxInCh) % HINTS[type].length];

    const mech: string[] = [];
    if (bumpers > 0) mech.push(`${bumpers} bumper${bumpers > 1 ? 's' : ''}`);
    if (movers > 0) mech.push(`${movers} obstacle${movers > 1 ? 's' : ''} mobile${movers > 1 ? 's' : ''}`);
    if (portals) mech.push('portail');

    let description: string;
    if (type === 'collect') {
      description = `Collectez ${targets} cibles${elevated ? ` dont ${elevated} en hauteur` : ''} en ${timeLimit} s${mech.length ? ` · ${mech.join(', ')}` : ''}.`;
    } else if (type === 'combo') {
      description = `Enchaînez une chaîne de ${comboGoal} rebonds rapprochés en ${timeLimit} s${mech.length ? ` · ${mech.join(', ')}` : ''}.`;
    } else {
      description = `Tenez ${timeLimit} s sans laisser le ballon reposer plus de ${String(restLimit).replace('.', ',')} s au sol${mech.length ? ` · ${mech.join(', ')}` : ''}.`;
    }
    if (isBoss) description += ' Épreuve de fin de monde : récompense majeure !';

    levels.push({
      id, chapter, name, type, description, hint,
      targets, elevated, comboGoal, timeLimit, restLimit,
      obstacleCount, bumpers, movers, portals, isBoss,
      xpReward, stars,
    });
  }
  return levels;
}

export const LEVELS: LevelDef[] = buildLevels();

export function getLevel(id: number): LevelDef | undefined {
  if (!Number.isInteger(id) || id < 1 || id > TOTAL_LEVELS) return undefined;
  return LEVELS[id - 1];
}

export const CHALLENGE_LABEL: Record<LevelDef['type'], string> = {
  collect: 'Collecte',
  survival: 'Survie',
  combo: 'Combo',
};

export const CHALLENGE_EMOJI: Record<LevelDef['type'], string> = {
  collect: '🎯',
  survival: '🔥',
  combo: '⚡',
};
