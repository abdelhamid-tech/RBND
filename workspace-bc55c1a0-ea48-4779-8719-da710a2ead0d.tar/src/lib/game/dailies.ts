/* ============================================================
   Missions du jour — remises à zéro chaque jour (locale).
   Progression enregistrée côté client (localStorage) puis
   récompense XP réclamée via POST /api/player/xp.
============================================================ */

export type DailyKind = 'collect' | 'bounces' | 'wins' | 'chain';

export interface DailyDef {
  id: DailyKind;
  emoji: string;
  label: string;
  target: number;
  xp: number;
}

export const DAILIES: DailyDef[] = [
  { id: 'collect', emoji: '🎯', label: 'Collecter des cibles', target: 10, xp: 50 },
  { id: 'bounces', emoji: '💥', label: 'Rebonds dans l’arène', target: 40, xp: 40 },
  { id: 'wins', emoji: '🏆', label: 'Terminer des défis', target: 3, xp: 60 },
  { id: 'chain', emoji: '⚡', label: 'Meilleure chaîne du jour', target: 8, xp: 55 },
];

export interface DailyState {
  /** clé du jour (yyyy-mm-dd local) */
  date: string;
  /** progression par type de mission */
  progress: Record<DailyKind, number>;
  /** missions déjà réclamées aujourd'hui */
  claimed: DailyKind[];
}

const STORAGE_KEY = 'labo-physique-dailies';

/** Clé du jour local (yyyy-mm-dd) */
export function todayKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function emptyState(): DailyState {
  return {
    date: todayKey(),
    progress: { collect: 0, bounces: 0, wins: 0, chain: 0 },
    claimed: [],
  };
}

/** Charge l'état du jour (réinitialisé si nouvelle journée) */
export function loadDailyState(): DailyState {
  if (typeof window === 'undefined') return emptyState();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyState();
    const parsed = JSON.parse(raw) as DailyState;
    if (parsed.date !== todayKey() || !parsed.progress) return emptyState();
    return {
      date: parsed.date,
      progress: {
        collect: parsed.progress.collect ?? 0,
        bounces: parsed.progress.bounces ?? 0,
        wins: parsed.progress.wins ?? 0,
        chain: parsed.progress.chain ?? 0,
      },
      claimed: Array.isArray(parsed.claimed) ? parsed.claimed : [],
    };
  } catch {
    return emptyState();
  }
}

export function saveDailyState(state: DailyState): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    /* stockage indisponible */
  }
}

/**
 * Incrémente (mode add) ou fixe un maximum (mode max, ex. meilleure chaîne)
 * la progression d'une mission du jour, puis persiste.
 */
export function bumpDaily(kind: DailyKind, amount: number, mode: 'add' | 'max' = 'add'): DailyState {
  const state = loadDailyState();
  const prev = state.progress[kind] ?? 0;
  state.progress[kind] = mode === 'add' ? prev + amount : Math.max(prev, amount);
  saveDailyState(state);
  return state;
}

/** Mission terminée (objectif atteint) ? */
export function dailyDone(def: DailyDef, state: DailyState): boolean {
  return (state.progress[def.id] ?? 0) >= def.target;
}

/** Mission terminée mais récompense pas encore réclamée ? */
export function dailyClaimable(def: DailyDef, state: DailyState): boolean {
  return dailyDone(def, state) && !state.claimed.includes(def.id);
}
