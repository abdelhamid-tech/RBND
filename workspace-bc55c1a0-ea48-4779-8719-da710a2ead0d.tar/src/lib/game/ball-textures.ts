/* ============================================================
   Textures procédurales de ballons (canvas → THREE.CanvasTexture)
   Dessinées en projection équirectangulaire (2:1) pour un
   mapping sphérique sans couture.
   `size` permet de générer des versions légères (vignettes).
============================================================ */

export type ProcKind =
  | 'soccer' | 'basketball' | 'beach' | 'tennis' | 'golf'
  | 'bowling' | 'eight' | 'disco' | 'galaxy' | 'lava'
  | 'candy' | 'moon';

export function buildBallTexture(kind: ProcKind, size = 1024): HTMLCanvasElement {
  const W = size;
  const H = size / 2;
  const c = document.createElement('canvas');
  c.width = W;
  c.height = H;
  const g = c.getContext('2d');
  if (!g) return c;
  switch (kind) {
    case 'soccer': drawSoccer(g, W, H); break;
    case 'basketball': drawBasket(g, W, H); break;
    case 'beach': drawBeach(g, W, H); break;
    case 'tennis': drawTennis(g, W, H); break;
    case 'golf': drawGolf(g, W, H); break;
    case 'bowling': drawBowling(g, W, H); break;
    case 'eight': drawEight(g, W, H); break;
    case 'disco': drawDisco(g, W, H); break;
    case 'galaxy': drawGalaxy(g, W, H); break;
    case 'lava': drawLava(g, W, H); break;
    case 'candy': drawCandy(g, W, H); break;
    case 'moon': drawMoon(g, W, H); break;
  }
  return c;
}

/* ---------------- Ballon de soccer ---------------- */

function drawSoccer(g: CanvasRenderingContext2D, W: number, H: number) {
  g.fillStyle = '#f2f0ea';
  g.fillRect(0, 0, W, H);

  // Léger grain
  for (let i = 0; i < 2600; i++) {
    g.fillStyle = Math.random() < 0.5 ? 'rgba(0,0,0,0.02)' : 'rgba(255,255,255,0.03)';
    g.fillRect(Math.random() * W, Math.random() * H, 3, 3);
  }

  // Sommets d'un icosaèdre = centres des pentagones noirs
  const PHI = (1 + Math.sqrt(5)) / 2;
  const L = Math.hypot(1, PHI);
  const verts: Array<[number, number, number]> = [];
  for (const a of [-1, 1]) for (const b of [-1, 1]) verts.push([0, a, b * PHI]);
  for (const a of [-1, 1]) for (const b of [-1, 1]) verts.push([a, b * PHI, 0]);
  for (const a of [-1, 1]) for (const b of [-1, 1]) verts.push([a * PHI, 0, b]);

  const latR = 0.33 * (H / Math.PI);
  for (const [x, y, z] of verts) {
    const lat = Math.asin(y / L);
    const lon = Math.atan2(x, z);
    const cx = (lon / (2 * Math.PI) + 0.5) * W;
    const cy = (0.5 - lat / Math.PI) * H;
    const lonR = latR / Math.max(0.5, Math.cos(lat));
    drawPentagon(g, cx, cy, lonR, latR, W);
  }
}

function drawPentagon(
  g: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  W: number
) {
  for (const off of [0, -W, W]) {
    g.beginPath();
    for (let i = 0; i < 5; i++) {
      const a = -Math.PI / 2 + (i * 2 * Math.PI) / 5;
      const px = cx + off + Math.cos(a) * rx;
      const py = cy + Math.sin(a) * ry;
      if (i === 0) g.moveTo(px, py);
      else g.lineTo(px, py);
    }
    g.closePath();
    g.fillStyle = '#1c1c1c';
    g.fill();
    g.strokeStyle = 'rgba(0,0,0,0.18)';
    g.lineWidth = 5;
    g.stroke();
  }
}

/* ---------------- Ballon de basket ---------------- */

function drawBasket(g: CanvasRenderingContext2D, W: number, H: number) {
  g.fillStyle = '#e8792e';
  g.fillRect(0, 0, W, H);

  // Grain cuir
  for (let i = 0; i < 9000; i++) {
    g.fillStyle = Math.random() < 0.5 ? 'rgba(110,45,8,0.22)' : 'rgba(255,200,140,0.20)';
    g.fillRect(Math.random() * W, Math.random() * H, 2, 2);
  }

  g.strokeStyle = '#26180f';
  g.lineWidth = 12;
  g.lineCap = 'round';

  // Méridiens (2 grands cercles verticaux)
  for (const f of [0, 0.25, 0.5, 0.75]) {
    g.beginPath();
    g.moveTo(f * W, -4);
    g.lineTo(f * W, H + 4);
    g.stroke();
  }

  // Équateur
  g.beginPath();
  g.moveTo(0, H / 2);
  g.lineTo(W, H / 2);
  g.stroke();

  // Deux grands cercles inclinés (coutures latérales)
  const TH = (62 * Math.PI) / 180;
  for (const s of [1, -1]) {
    g.beginPath();
    for (let px = 0; px <= W; px += 4) {
      const lon = (px / W) * 2 * Math.PI;
      const lat = Math.atan(Math.tan(TH) * Math.sin(lon)) * s;
      const py = (0.5 - lat / Math.PI) * H;
      if (px === 0) g.moveTo(px, py);
      else g.lineTo(px, py);
    }
    g.stroke();
  }
}

/* ---------------- Ballon de plage ---------------- */

function drawBeach(g: CanvasRenderingContext2D, W: number, H: number) {
  const cols = ['#ffffff', '#e63946', '#ffffff', '#ffd23f', '#ffffff', '#3fa34d'];
  const sw = W / 6;
  for (let i = 0; i < 6; i++) {
    g.fillStyle = cols[i];
    g.fillRect(i * sw, 0, sw + 1, H);
  }
  // Bords de panneaux
  g.fillStyle = 'rgba(0,0,0,0.07)';
  for (let i = 0; i <= 6; i++) g.fillRect(i * sw - 2, 0, 4, H);

  // Calottes polaires
  g.fillStyle = '#ffffff';
  g.fillRect(0, 0, W, 30);
  g.fillRect(0, H - 30, W, 30);
  g.fillStyle = 'rgba(0,0,0,0.08)';
  g.fillRect(0, 30, W, 5);
  g.fillRect(0, H - 35, W, 5);
}

/* ---------------- Ballon de tennis ---------------- */

function drawTennis(g: CanvasRenderingContext2D, W: number, H: number) {
  g.fillStyle = '#d8e34a';
  g.fillRect(0, 0, W, H);

  // Grain feutre
  for (let i = 0; i < 9000; i++) {
    g.fillStyle = Math.random() < 0.5 ? 'rgba(120,140,20,0.16)' : 'rgba(240,255,180,0.16)';
    g.fillRect(Math.random() * W, Math.random() * H, 2, 2);
  }

  // Coutures blanches courbes (deux grands cercles inclinés)
  g.strokeStyle = '#ffffff';
  g.lineWidth = 14;
  g.lineCap = 'round';
  const TH = (58 * Math.PI) / 180;
  for (const s of [1, -1]) {
    g.beginPath();
    for (let px = 0; px <= W; px += 4) {
      const lon = (px / W) * 2 * Math.PI;
      const lat = Math.atan(Math.tan(TH) * Math.sin(lon)) * s;
      const py = (0.5 - lat / Math.PI) * H;
      if (px === 0) g.moveTo(px, py);
      else g.lineTo(px, py);
    }
    g.stroke();
  }
  g.strokeStyle = 'rgba(0,0,0,0.18)';
  g.lineWidth = 4;
  for (const s of [1, -1]) {
    g.beginPath();
    for (let px = 0; px <= W; px += 4) {
      const lon = (px / W) * 2 * Math.PI;
      const lat = Math.atan(Math.tan(TH) * Math.sin(lon)) * s;
      const py = (0.5 - lat / Math.PI) * H + 8;
      if (px === 0) g.moveTo(px, py);
      else g.lineTo(px, py);
    }
    g.stroke();
  }
}

/* ---------------- Ballon de golf ---------------- */

function drawGolf(g: CanvasRenderingContext2D, W: number, H: number) {
  const grd = g.createLinearGradient(0, 0, 0, H);
  grd.addColorStop(0, '#ffffff');
  grd.addColorStop(0.5, '#f2f3f5');
  grd.addColorStop(1, '#dde0e6');
  g.fillStyle = grd;
  g.fillRect(0, 0, W, H);

  // Alvéoles (dimples) : grille hexagonale décalée
  const step = W / 24;
  const rr = step * 0.34;
  for (let row = 0; row * step * 0.87 < H + step; row++) {
    const y = row * step * 0.87;
    const squeeze = Math.sin((y / H) * Math.PI); // moins d'alvéoles aux pôles
    if (squeeze < 0.25) continue;
    for (let col = 0; col * step < W + step; col++) {
      const x = col * step + (row % 2 ? step / 2 : 0);
      const grad = g.createRadialGradient(x - rr * 0.3, y - rr * 0.3, rr * 0.1, x, y, rr);
      grad.addColorStop(0, 'rgba(255,255,255,0.95)');
      grad.addColorStop(0.55, 'rgba(190,196,208,0.55)');
      grad.addColorStop(1, 'rgba(120,126,140,0.4)');
      g.fillStyle = grad;
      g.beginPath();
      g.arc(x, y, rr, 0, Math.PI * 2);
      g.fill();
    }
  }
}

/* ---------------- Ballon de bowling ---------------- */

function drawBowling(g: CanvasRenderingContext2D, W: number, H: number) {
  const grd = g.createRadialGradient(W * 0.5, H * 0.42, 10, W * 0.5, H * 0.5, W * 0.42);
  grd.addColorStop(0, '#5a2030');
  grd.addColorStop(0.6, '#33111d');
  grd.addColorStop(1, '#16070c');
  g.fillStyle = grd;
  g.fillRect(0, 0, W, H);

  // Reflet marbré
  for (let i = 0; i < 24; i++) {
    g.strokeStyle = `rgba(255,160,190,${0.03 + Math.random() * 0.05})`;
    g.lineWidth = 8 + Math.random() * 22;
    g.beginPath();
    const y0 = Math.random() * H;
    g.moveTo(0, y0);
    g.bezierCurveTo(W * 0.3, y0 - 40 + Math.random() * 80, W * 0.7, y0 - 40 + Math.random() * 80, W, y0 + (Math.random() - 0.5) * 60);
    g.stroke();
  }

  // Trois trous de doigts (hémisphère nord)
  const holes: Array<[number, number, number]> = [
    [0.5, 0.36, 0.030], [0.445, 0.44, 0.034], [0.555, 0.44, 0.034],
  ];
  for (const [fx, fy, fr] of holes) {
    const x = fx * W, y = fy * H, r = fr * W;
    const hg = g.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.2, x, y, r);
    hg.addColorStop(0, '#000000');
    hg.addColorStop(0.8, '#0a0406');
    hg.addColorStop(1, '#241016');
    g.fillStyle = hg;
    g.beginPath();
    g.arc(x, y, r, 0, Math.PI * 2);
    g.fill();
  }
}

/* ---------------- 8-Ball ---------------- */

function drawEight(g: CanvasRenderingContext2D, W: number, H: number) {
  const grd = g.createRadialGradient(W * 0.5, H * 0.4, 12, W * 0.5, H * 0.5, W * 0.45);
  grd.addColorStop(0, '#3a3a42');
  grd.addColorStop(0.55, '#17171c');
  grd.addColorStop(1, '#060608');
  g.fillStyle = grd;
  g.fillRect(0, 0, W, H);

  // Deux cercles blancs opposés avec le « 8 »
  for (const fx of [0.25, 0.75]) {
    const x = fx * W, y = H * 0.5, r = W * 0.085;
    g.fillStyle = '#f4f2ec';
    g.beginPath();
    g.arc(x, y, r, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = '#111114';
    g.font = `bold ${Math.round(r * 1.15)}px system-ui, sans-serif`;
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText('8', x, y + r * 0.06);
  }
}

/* ---------------- Boule à facettes (disco) ---------------- */

function drawDisco(g: CanvasRenderingContext2D, W: number, H: number) {
  const cols = W / 14;
  const rows = H / 14;
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      const v = 0.42 + Math.random() * 0.58;
      const tint = Math.random() < 0.12;
      g.fillStyle = tint
        ? `rgba(${180 + v * 60},${150 + v * 80},${200 + v * 55},1)`
        : `rgba(${Math.round(150 + v * 105)},${Math.round(152 + v * 103)},${Math.round(160 + v * 95)},1)`;
      g.fillRect(i * cols, j * rows, cols + 1, rows + 1);
    }
  }
  // Grille sombre entre les facettes
  g.strokeStyle = 'rgba(20,20,26,0.85)';
  g.lineWidth = 2;
  for (let i = 0; i <= cols; i++) {
    g.beginPath();
    g.moveTo(i * cols, 0);
    g.lineTo(i * cols, H);
    g.stroke();
  }
  for (let j = 0; j <= rows; j++) {
    g.beginPath();
    g.moveTo(0, j * rows);
    g.lineTo(W, j * rows);
    g.stroke();
  }
}

/* ---------------- Galaxie ---------------- */

function drawGalaxy(g: CanvasRenderingContext2D, W: number, H: number) {
  g.fillStyle = '#0b0a1e';
  g.fillRect(0, 0, W, H);

  // Nuages colorés
  const clouds: Array<[string, number, number, number]> = [
    ['rgba(140,70,255,0.55)', 0.28, 0.42, 0.42],
    ['rgba(60,190,255,0.4)', 0.66, 0.55, 0.38],
    ['rgba(255,90,200,0.35)', 0.85, 0.3, 0.3],
    ['rgba(90,255,220,0.25)', 0.12, 0.68, 0.28],
    ['rgba(255,190,90,0.3)', 0.5, 0.75, 0.3],
  ];
  for (const [col, fx, fy, fr] of clouds) {
    const rg = g.createRadialGradient(fx * W, fy * H, 4, fx * W, fy * H, fr * W);
    rg.addColorStop(0, col);
    rg.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = rg;
    g.fillRect(0, 0, W, H);
  }

  // Étoiles
  for (let i = 0; i < 900; i++) {
    const a = Math.random();
    const r = 0.6 + a * 1.7;
    g.fillStyle = `rgba(255,255,255,${0.25 + Math.random() * 0.75})`;
    g.beginPath();
    g.arc(Math.random() * W, Math.random() * H, r, 0, Math.PI * 2);
    g.fill();
  }
}

/* ---------------- Lave ---------------- */

function drawLava(g: CanvasRenderingContext2D, W: number, H: number) {
  // Roche sombre
  const grd = g.createRadialGradient(W * 0.5, H * 0.45, 10, W * 0.5, H * 0.5, W * 0.45);
  grd.addColorStop(0, '#2a1410');
  grd.addColorStop(1, '#120705');
  g.fillStyle = grd;
  g.fillRect(0, 0, W, H);

  // Taches incandescentes
  for (let i = 0; i < 46; i++) {
    const x = Math.random() * W;
    const y = Math.random() * H;
    const r = 6 + Math.random() * 26;
    const rg = g.createRadialGradient(x, y, 1, x, y, r);
    rg.addColorStop(0, 'rgba(255,220,120,0.95)');
    rg.addColorStop(0.35, 'rgba(255,120,40,0.75)');
    rg.addColorStop(1, 'rgba(180,40,10,0)');
    g.fillStyle = rg;
    g.beginPath();
    g.arc(x, y, r, 0, Math.PI * 2);
    g.fill();
  }

  // Fissures lumineuses (marches aléatoires)
  for (let c = 0; c < 12; c++) {
    let x = Math.random() * W;
    let y = Math.random() * H;
    g.strokeStyle = 'rgba(255,150,50,0.8)';
    g.lineWidth = 2 + Math.random() * 3;
    g.beginPath();
    g.moveTo(x, y);
    for (let s = 0; s < 26; s++) {
      x += (Math.random() - 0.5) * 60;
      y += (Math.random() - 0.5) * 40;
      g.lineTo(x, y);
    }
    g.stroke();
  }
}

/* ---------------- Bonbon (swirl rose) ---------------- */

function drawCandy(g: CanvasRenderingContext2D, W: number, H: number) {
  g.fillStyle = '#ff9ec7';
  g.fillRect(0, 0, W, H);

  // Spirale blanche
  g.save();
  g.translate(W / 2, H / 2);
  g.strokeStyle = '#ffffff';
  g.lineWidth = H * 0.13;
  g.lineCap = 'round';
  g.beginPath();
  for (let a = 0; a < Math.PI * 6; a += 0.05) {
    const rr = (a / (Math.PI * 6)) * W * 0.52;
    const px = Math.cos(a) * rr * 1.9;
    const py = Math.sin(a) * rr * 0.8;
    if (a === 0) g.moveTo(px, py);
    else g.lineTo(px, py);
  }
  g.stroke();
  g.restore();

  // Petits cœurs / bonbons
  for (let i = 0; i < 26; i++) {
    const x = Math.random() * W;
    const y = Math.random() * H;
    g.fillStyle = ['#ffffff', '#ffe08a', '#7adfff', '#c78aff'][Math.floor(Math.random() * 4)];
    g.globalAlpha = 0.85;
    g.beginPath();
    g.arc(x, y, 5 + Math.random() * 8, 0, Math.PI * 2);
    g.fill();
    g.globalAlpha = 1;
  }
}

/* ---------------- Lune ---------------- */

function drawMoon(g: CanvasRenderingContext2D, W: number, H: number) {
  const grd = g.createRadialGradient(W * 0.45, H * 0.4, 10, W * 0.5, H * 0.5, W * 0.45);
  grd.addColorStop(0, '#e8e6df');
  grd.addColorStop(0.7, '#c9c6bd');
  grd.addColorStop(1, '#97948b');
  g.fillStyle = grd;
  g.fillRect(0, 0, W, H);

  // Mers sombres
  for (let i = 0; i < 10; i++) {
    const x = Math.random() * W;
    const y = H * (0.2 + Math.random() * 0.6);
    const r = 30 + Math.random() * 90;
    g.fillStyle = 'rgba(105,102,95,0.4)';
    g.beginPath();
    g.ellipse(x, y, r, r * (0.55 + Math.random() * 0.4), Math.random() * Math.PI, 0, Math.PI * 2);
    g.fill();
  }

  // Cratères
  for (let i = 0; i < 46; i++) {
    const x = Math.random() * W;
    const y = Math.random() * H;
    const r = 4 + Math.random() * 16;
    g.fillStyle = 'rgba(90,88,82,0.5)';
    g.beginPath();
    g.arc(x, y, r, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = 'rgba(255,255,255,0.35)';
    g.beginPath();
    g.arc(x - r * 0.25, y - r * 0.25, r * 0.55, 0, Math.PI * 2);
    g.fill();
  }

  // Grain
  for (let i = 0; i < 6000; i++) {
    g.fillStyle = Math.random() < 0.5 ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.06)';
    g.fillRect(Math.random() * W, Math.random() * H, 2, 2);
  }
}
