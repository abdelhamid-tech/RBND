/* ============================================================
   Rangs du joueur — titre cosmétique selon le niveau.
============================================================ */

export interface Rank {
  title: string;
  /** index de palier (0..10) — sert de teinte d'accent */
  tier: number;
}

const RANKS: Array<{ min: number; title: string }> = [
  { min: 0, title: 'Novice du Labo' },
  { min: 3, title: 'Apprenti Rebond' },
  { min: 5, title: 'Technicien des Surfaces' },
  { min: 7, title: 'Ingénieur de l’Élasticité' },
  { min: 10, title: 'Maître de la Chaîne' },
  { min: 14, title: 'Légende du Laboratoire' },
  { min: 20, title: 'Architecte des Mondes' },
  { min: 27, title: 'Voyager des Sphères' },
  { min: 35, title: 'Maître des Bumpers' },
  { min: 45, title: 'Physicien Quantique' },
  { min: 60, title: 'Immortel du Rebond' },
];

/** Rang atteint pour un niveau de joueur donné */
export function rankFor(level: number): Rank {
  let tier = 0;
  for (let i = 0; i < RANKS.length; i++) {
    if (level >= RANKS[i].min) tier = i;
  }
  return { title: RANKS[tier].title, tier };
}

/** Prochain rang à débloquer, null si dernier rang */
export function nextRankTitle(level: number): string | null {
  for (const r of RANKS) {
    if (level < r.min) return r.title;
  }
  return null;
}

/** Niveau requis pour le prochain rang */
export function nextRankLevel(level: number): number | null {
  for (const r of RANKS) {
    if (level < r.min) return r.min;
  }
  return null;
}
