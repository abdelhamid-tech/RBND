/* ============================================================
   Courbe de niveau joueur — l'XP sert aussi de devise.
============================================================ */

/** XP nécessaire pour passer du niveau `level` au niveau suivant */
export function xpForLevel(level: number): number {
  return 120 + (level - 1) * 80;
}

/** Calcule le niveau atteint pour un total d'XP donné */
export function computeLevel(totalXp: number): {
  level: number;
  xpIntoLevel: number;
  xpForNext: number;
} {
  let level = 1;
  let remaining = Math.max(0, Math.floor(totalXp));
  while (level < 999 && remaining >= xpForLevel(level)) {
    remaining -= xpForLevel(level);
    level++;
  }
  return { level, xpIntoLevel: remaining, xpForNext: xpForLevel(level) };
}

/** XP donnée lors d'une complétion de niveau déjà réalisée (replay) */
export function replayReward(fullReward: number): number {
  return Math.max(10, Math.floor(fullReward * 0.25));
}

/** Prix de validation côté serveur : montant max d'un bonus XP manuel (pub x2) */
export const MAX_MANUAL_XP = 500;

/** Durée du cooldown du bonus pub en ms (24h) */
export const AD_BONUS_COOLDOWN_MS = 24 * 60 * 60 * 1000;

/** XP du bonus quotidien après pub rewarded */
export const AD_BONUS_XP = 60;
