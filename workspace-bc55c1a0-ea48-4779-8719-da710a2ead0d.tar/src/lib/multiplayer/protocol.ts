/* ============================================================
   Protocole multijoueur RBND — contrat partagé client / serveur
   Le serveur socket.io est construit sur ce contrat exact :
   ne renomme AUCUN champ ni événement sans synchroniser les deux
   côtés. Les interfaces socket typées (ci-dessous) sont une
   projection 1:1 de ce contrat pour socket.io-client v4.
============================================================ */

import type { Socket } from 'socket.io-client';

export interface MpPlayerState { id: string; name: string; ballId: string; color: number; x: number; y: number; z: number }
export type JoinAck = { ok: true; room: string } | { ok: false; error: string };
export type CreateAck = { ok: true; room: string };
// Client → serveur : 'mp:join' {room,name,ballId,color} ack JoinAck · 'mp:create' {name,ballId,color} ack CreateAck ·
//   'mp:move' {x,y,z} · 'mp:chat' {text} · 'mp:leave' · 'mp:ping' ack (t:number)
// Serveur → client : 'mp:joined' {room,you,players:MpPlayerState[]} · 'mp:player-joined' {player} · 'mp:player-left' {id,name} ·
//   'mp:snap' {p:Array<[id,x,y,z]>} (15 Hz) · 'mp:chat' {id,from,name,text,ts} · 'mp:sys' {text,ts}
export const MP_WORLD_HALF = 120; // limite du monde (±120)

/* ---------------- Projection typée du contrat (socket.io) ---------------- */

/** Un élément du paquet de snapshot : [id, x, y, z] */
export type MpSnapTuple = [string, number, number, number];

export interface MpJoinedPayload {
  room: string;
  /** id socket du joueur local */
  you: string;
  players: MpPlayerState[];
}

export interface MpChatPayload {
  id: string;
  from: string;
  name: string;
  text: string;
  ts: number;
}

export interface MpSysPayload {
  text: string;
  ts: number;
}

/** Serveur → client */
export interface MpServerToClientEvents {
  'mp:joined': (d: MpJoinedPayload) => void;
  'mp:player-joined': (d: { player: MpPlayerState }) => void;
  'mp:player-left': (d: { id: string; name: string }) => void;
  'mp:snap': (d: { p: MpSnapTuple[] }) => void;
  'mp:chat': (d: MpChatPayload) => void;
  'mp:sys': (d: MpSysPayload) => void;
}

/** Client → serveur */
export interface MpClientToServerEvents {
  'mp:join': (d: { room: string; name: string; ballId: string; color: number }, ack: (a: JoinAck) => void) => void;
  'mp:create': (d: { name: string; ballId: string; color: number }, ack: (a: CreateAck) => void) => void;
  'mp:move': (d: { x: number; y: number; z: number }) => void;
  'mp:chat': (d: { text: string }) => void;
  'mp:leave': () => void;
  'mp:ping': (ack: (t: { t: number }) => void) => void;
}

/** Socket client typée (socket.io-client) */
export type MpSocket = Socket<MpServerToClientEvents, MpClientToServerEvents>;

/** Nom de la salle publique */
export const MP_PUBLIC_ROOM = 'public';
