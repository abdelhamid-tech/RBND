import type { Metadata, Viewport } from "next";
import { Manrope, Russo_One } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const manrope = Manrope({
  variable: "--font-manrope",
  subsets: ["latin"],
  display: "swap",
});

const russoOne = Russo_One({
  weight: "400",
  variable: "--font-russo",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "RBND — Laboratoire de Physique",
  description:
    "Guidez votre ballon dans l'arène, relevez des défis, gagnez de l'XP et achetez des ballons légendaires. Publicités propulsées par le SDK CrazyGames.",
  keywords: ["jeu", "physique", "ballon", "défis", "XP", "CrazyGames"],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
};

export const viewport: Viewport = {
  themeColor: "#1a1814",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <body
        className={`${manrope.variable} ${russoOne.variable} antialiased bg-[#14120f] text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
