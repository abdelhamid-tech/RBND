'use client';

/* ============================================================
   Laboratoire de Physique — page unique
   Lobby (garage + campagne + missions) ↔ Jeu, avec :
   - XP = devise, niveaux de joueur, missions du jour
   - Bonus de performance à chaque victoire (temps restant + chaîne)
   - SDK CrazyGames : rewarded (récompenses) + midgame obligatoire
     toutes les 3 victoires (sans récompense)
============================================================ */

import { useCallback, useEffect, useRef, useState } from 'react';
import dynamic from 'next/dynamic';
import { Clapperboard, PartyPopper, RotateCcw, DoorOpen, Zap, TrendingUp, Gauge } from 'lucide-react';
import HomeView from '@/components/home/HomeView';
import type { GameResult } from '@/components/game/GameCanvas';
import { crazyGames } from '@/lib/crazygames';
import type { BallDef, LevelDef, PlayerDTO, CompleteResponse, AdBonusResponse, XpResponse, ActionResponse } from '@/lib/game/types';
import { getBall } from '@/lib/game/balls';
import { CHAPTERS } from '@/lib/game/levels';
import { bumpDaily, loadDailyState, saveDailyState, type DailyDef, type DailyState } from '@/lib/game/dailies';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';

const GameCanvas = dynamic(() => import('@/components/game/GameCanvas'), { ssr: false });

interface ResultState {
  success: boolean;
  progressLabel: string;
  level: LevelDef | null;
  xpGained: number;
  /** bonus de performance (temps restant + chaîne), 0 si échec */
  perfBonus: number;
  firstCompletion: boolean;
  levelUp: boolean;
  doubled: boolean;
}

const PID_KEY = 'labo-physique-pid';

function getPid(): string {
  let pid = localStorage.getItem(PID_KEY);
  if (!pid) {
    pid = crypto.randomUUID();
    localStorage.setItem(PID_KEY, pid);
  }
  return pid;
}

export default function Page() {
  const { toast } = useToast();
  const [pid, setPid] = useState<string>('');
  const [player, setPlayer] = useState<PlayerDTO | null>(null);
  const [dailies, setDailies] = useState<DailyState | null>(null);
  const [view, setView] = useState<'home' | 'game'>('home');
  const [playingLevel, setPlayingLevel] = useState<LevelDef | null>(null);
  const [gameKey, setGameKey] = useState(0);
  const [result, setResult] = useState<ResultState | null>(null);
  const [busy, setBusy] = useState(false);
  const winsSinceAdRef = useRef(0);
  const pidRef = useRef('');
  pidRef.current = pid;

  /* ---------------- Chargement joueur + missions du jour ---------------- */
  useEffect(() => {
    const id = getPid();
    setPid(id);
    setDailies(loadDailyState());
    crazyGames.init();
    fetch(`/api/player?pid=${encodeURIComponent(id)}`)
      .then((r) => r.json())
      .then((d) => {
        if (d?.ok && d.player) setPlayer(d.player as PlayerDTO);
        else toast({ title: 'Erreur', description: 'Impossible de charger le profil.', variant: 'destructive' });
      })
      .catch(() => toast({ title: 'Erreur réseau', description: 'Profil inaccessible.', variant: 'destructive' }));

  }, []);

  /* ---------------- Actions boutique ---------------- */
  const handleBuy = useCallback(
    async (ball: BallDef) => {
      setBusy(true);
      try {
        const res = await fetch('/api/player/buy', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pid: pidRef.current, ballId: ball.id }),
        });
        const d: ActionResponse = await res.json();
        if (d.ok) {
          setPlayer(d.player);
          toast({ title: `${ball.emoji} ${ball.name} acheté !`, description: 'Le ballon a été équipé automatiquement.' });
        } else {
          toast({ title: 'Achat impossible', description: d.error, variant: 'destructive' });
        }
      } finally {
        setBusy(false);
      }
    },
    [toast]
  );

  const handleSelect = useCallback(
    async (ball: BallDef) => {
      setBusy(true);
      try {
        const res = await fetch('/api/player/select', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pid: pidRef.current, ballId: ball.id }),
        });
        const d: ActionResponse = await res.json();
        if (d.ok) {
          setPlayer(d.player);
          toast({ title: `${ball.emoji} ${ball.name} équipé !` });
        } else {
          toast({ title: 'Impossible', description: d.error, variant: 'destructive' });
        }
      } finally {
        setBusy(false);
      }
    },
    [toast]
  );

  /* ---------------- Bonus pub quotidien ---------------- */
  const handleClaimBonus = useCallback(() => {
    setBusy(true);
    crazyGames.requestAd('rewarded', {
      adStarted: () => { /* audio coupé automatiquement */ },
      adFinished: async () => {
        try {
          const res = await fetch('/api/player/ad-bonus', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ pid: pidRef.current }),
          });
          const d: AdBonusResponse = await res.json();
          if (d.ok) {
            setPlayer(d.player);
            toast({ title: '🎁 Bonus réclamé !', description: `+${d.xpGained} XP grâce à la publicité.` });
          } else {
            toast({ title: 'Bonus indisponible', description: d.error, variant: 'destructive' });
          }
        } finally {
          setBusy(false);
        }
      },
      adError: () => {
        setBusy(false);
        toast({ title: 'Publicité indisponible', description: 'Réessayez dans un instant.', variant: 'destructive' });
      },
    });
  }, [toast]);

  /* ---------------- Missions du jour ---------------- */
  const handleClaimDaily = useCallback(
    async (d: DailyDef) => {
      setBusy(true);
      try {
        const res = await fetch('/api/player/xp', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pid: pidRef.current, amount: d.xp, reason: `daily_${d.id}` }),
        });
        const r: XpResponse = await res.json();
        if (r.ok) {
          setPlayer(r.player);
          setDailies((prev) => {
            const next: DailyState = prev
              ? { date: prev.date, progress: { ...prev.progress }, claimed: [...prev.claimed, d.id] }
              : loadDailyState();
            saveDailyState(next);
            return next;
          });
          toast({ title: `${d.emoji} Mission accomplie !`, description: `+${r.xpGained} XP${r.levelUp ? ' · Niveau supérieur !' : ''}` });
        } else {
          toast({ title: 'Impossible', description: r.error, variant: 'destructive' });
        }
      } finally {
        setBusy(false);
      }
    },
    [toast]
  );

  /* ---------------- Fin de défi ---------------- */
  const handleResult = useCallback(
    async (r: GameResult) => {
      if (!playingLevel) return;

      // Progression des missions du jour (succès ET échec)
      bumpDaily('bounces', r.stats.bounces);
      bumpDaily('chain', r.stats.bestChain, 'max');
      bumpDaily('collect', r.stats.collected);
      if (r.success) bumpDaily('wins', 1);
      setDailies(loadDailyState());

      if (!r.success) {
        setResult({
          success: false, progressLabel: r.progressLabel, level: playingLevel,
          xpGained: 0, perfBonus: 0, firstCompletion: false, levelUp: false, doubled: false,
        });
        return;
      }

      setBusy(true);
      try {
        const res = await fetch('/api/player/complete', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pid: pidRef.current, levelId: playingLevel.id, timeMs: r.timeMs }),
        });
        const d: CompleteResponse = await res.json();
        if (!d.ok) {
          toast({ title: 'Erreur', description: d.error, variant: 'destructive' });
          return;
        }
        setPlayer(d.player);

        // Bonus de performance : rapidité (temps restant) + meilleure chaîne
        let perfBonus = Math.min(80, Math.floor(r.stats.timeLeftSec * 1.5) + r.stats.bestChain * 2);
        if (perfBonus < 5) perfBonus = 0;
        if (perfBonus > 0) {
          try {
            const pres = await fetch('/api/player/xp', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ pid: pidRef.current, amount: perfBonus, reason: 'performance' }),
            });
            const pd: XpResponse = await pres.json();
            if (pd.ok) {
              setPlayer(pd.player);
              perfBonus = pd.xpGained;
            } else {
              perfBonus = 0;
            }
          } catch {
            perfBonus = 0;
          }
        }

        // Pub obligatoire (midgame) toutes les 3 victoires — sans récompense
        winsSinceAdRef.current += 1;
        const needMandatoryAd = winsSinceAdRef.current >= 3;
        if (needMandatoryAd) winsSinceAdRef.current = 0;

        setResult({
          success: true, progressLabel: r.progressLabel, level: playingLevel,
          xpGained: d.xpGained, perfBonus, firstCompletion: d.firstCompletion, levelUp: d.levelUp, doubled: false,
        });

        if (needMandatoryAd) {
          await new Promise<void>((resolve) => {
            crazyGames.requestAd('midgame', {
              adStarted: () => { /* mute auto */ },
              adFinished: () => resolve(),
              adError: () => resolve(),
            });
          });
        }
      } finally {
        setBusy(false);
      }
    },
    [playingLevel, toast]
  );

  /* ---------------- Doubler l'XP (pub rewarded) ---------------- */
  const handleDoubleXp = useCallback(() => {
    if (!result || result.doubled || result.xpGained <= 0) return;
    crazyGames.requestAd('rewarded', {
      adStarted: () => { /* mute auto */ },
      adFinished: async () => {
        // compte la pub regardée
        fetch('/api/player/ad-watched', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pid: pidRef.current }),
        }).catch(() => { /* noop */ });
        const res = await fetch('/api/player/xp', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pid: pidRef.current, amount: result.xpGained, reason: 'ad_double' }),
        });
        const d: XpResponse = await res.json();
        if (d.ok) {
          setPlayer(d.player);
          setResult((prev) => (prev ? { ...prev, doubled: true, levelUp: prev.levelUp || d.levelUp } : prev));
          toast({ title: '🎬 XP doublée !', description: `+${d.xpGained} XP bonus` });
        } else {
          toast({ title: 'Erreur', description: d.error, variant: 'destructive' });
        }
      },
      adError: () => {
        toast({ title: 'Publicité indisponible', description: 'Réessayez dans un instant.', variant: 'destructive' });
      },
    });
  }, [result, toast]);

  /* ---------------- Navigation ---------------- */
  const startLevel = useCallback((lv: LevelDef) => {
    setPlayingLevel(lv);
    setResult(null);
    setGameKey((k) => k + 1);
    setView('game');
  }, []);

  const exitGame = useCallback(() => {
    setView('home');
    setResult(null);
  }, []);

  const replay = useCallback(() => {
    setResult(null);
    setGameKey((k) => k + 1);
  }, []);

  /* ---------------- Rendu ---------------- */
  if (!player || !dailies) {
    return (
      <main className="flex min-h-screen flex-col items-center justify-center gap-4 bg-[#1a1814]">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-white/10 border-t-[#d4574b]" />
        <p className="text-[10px] uppercase tracking-[0.3em] text-[#98907f]">Chargement du laboratoire</p>
      </main>
    );
  }

  if (view === 'game' && playingLevel) {
    return (
      <main className="fixed inset-0 bg-[#1a1814]">
        <GameCanvas
          key={gameKey}
          level={playingLevel}
          ball={getBall(player.selectedBall)}
          onExit={exitGame}
          onResult={handleResult}
        />
        {result && <ResultModal result={result} onDouble={handleDoubleXp} onReplay={replay} onExit={exitGame} busy={busy} />}
      </main>
    );
  }

  return (
    <div className="flex min-h-screen flex-col bg-[#14120f]">
      <main className="flex-1">
        <HomeView
          player={player}
          dailies={dailies}
          onPlay={startLevel}
          onBuy={handleBuy}
          onSelect={handleSelect}
          onClaimBonus={handleClaimBonus}
          onClaimDaily={handleClaimDaily}
          busy={busy}
        />
      </main>
      <footer className="mt-auto border-t border-white/5 bg-[#14120f] pb-[calc(12px+env(safe-area-inset-bottom,0px))] pt-4 text-center">
        <p className="text-[10px] uppercase tracking-[0.22em] text-[#6e675c]">
          Laboratoire de Physique · Défis · XP · Boutique · Publicités CrazyGames
        </p>
      </footer>
    </div>
  );
}

/* ============================================================
   Modale de fin de défi
============================================================ */

function ResultModal({
  result,
  onDouble,
  onReplay,
  onExit,
  busy,
}: {
  result: ResultState;
  onDouble: () => void;
  onReplay: () => void;
  onExit: () => void;
  busy: boolean;
}) {
  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
      <div className="w-full max-w-sm rounded-3xl border border-white/15 bg-[#221e19]/95 p-6 text-center shadow-2xl">
        {result.success ? (
          <>
            <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-emerald-400/15 text-emerald-300">
              <PartyPopper size={26} />
            </div>
            <h2 className="text-xl font-extrabold text-white">Défi réussi !</h2>
            {result.level && (
              <p className="mt-1 text-[10px] uppercase tracking-[0.2em] text-[#98907f]">
                Monde {result.level.chapter} — {CHAPTERS[result.level.chapter - 1]?.name ?? '?'} · {result.level.name}
              </p>
 )}
            {result.levelUp && (
              <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-amber-400/15 px-3 py-1 text-xs font-bold text-amber-300">
                <TrendingUp size={13} /> Niveau supérieur atteint !
              </div>
            )}
            <div className="mt-4 rounded-2xl border border-white/10 bg-white/5 p-4">
              <div className="flex items-center justify-center gap-2 text-3xl font-black text-amber-300">
                <Zap size={22} className="fill-amber-300" /> +{result.doubled ? result.xpGained * 2 : result.xpGained} XP
              </div>
              {result.perfBonus > 0 && (
                <div className="mt-1.5 inline-flex items-center gap-1 rounded-full bg-white/5 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-widest text-[#ffd27a]">
                  <Gauge size={11} /> Bonus de performance +{result.perfBonus} XP
                </div>
              )}
              {result.doubled && <p className="mt-1 text-[11px] font-semibold uppercase tracking-widest text-emerald-300">XP doublée grâce à la pub</p>}
              {!result.firstCompletion && result.xpGained > 0 && (
                <p className="mt-1 text-[10px] uppercase tracking-widest text-[#98907f]">Défi déjà réussi · récompense réduite</p>
              )}
            </div>
            {!result.doubled && (
              <Button
                onClick={onDouble}
                disabled={busy}
                className="mt-4 min-h-[48px] w-full bg-gradient-to-r from-amber-400 to-amber-500 text-base font-bold text-[#1a1814] shadow-lg hover:from-amber-300 hover:to-amber-400"
              >
                <Clapperboard size={17} /> Regarder une pub → XP x2
              </Button>
            )}
            <div className="mt-3 grid grid-cols-2 gap-2">
              <Button onClick={onReplay} variant="outline" className="min-h-[44px] border-white/20 bg-white/5 text-[#e0d8c8] hover:bg-white/10">
                <RotateCcw size={15} /> Rejouer
              </Button>
              <Button onClick={onExit} variant="outline" className="min-h-[44px] border-white/20 bg-white/5 text-[#e0d8c8] hover:bg-white/10">
                <DoorOpen size={15} /> Menu
              </Button>
            </div>
          </>
        ) : (
          <>
            <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-red-400/15 text-red-300">
              <Zap size={24} className="opacity-50" />
            </div>
            <h2 className="text-xl font-extrabold text-white">Échec…</h2>
            {result.level && (
              <p className="mt-1 text-[10px] uppercase tracking-[0.2em] text-[#98907f]">
                Monde {result.level.chapter} — {CHAPTERS[result.level.chapter - 1]?.name ?? '?'}
              </p>
 )}
            <p className="mt-2 text-sm text-[#b5ac9c]">
              {result.level ? `${result.level.name} — ${result.progressLabel}` : result.progressLabel}
            </p>
            <p className="mt-1 text-xs text-[#98907f]">Chaque essai vous rapproche de la victoire !</p>
            <div className="mt-5 grid grid-cols-2 gap-2">
              <Button onClick={onReplay} className="min-h-[46px] bg-[#d4574b] font-bold text-white hover:bg-[#c4493d]">
                <RotateCcw size={15} /> Réessayer
              </Button>
              <Button onClick={onExit} variant="outline" className="min-h-[46px] border-white/20 bg-white/5 text-[#e0d8c8] hover:bg-white/10">
                <DoorOpen size={15} /> Menu
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
