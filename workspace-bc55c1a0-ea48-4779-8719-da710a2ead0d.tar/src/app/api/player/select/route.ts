/* ============================================================
   POST /api/player/select { pid, ballId }
   Sélectionne un ballon déjà possédé.
============================================================ */

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ballExists } from "@/lib/game/balls";
import {
  errorResponse,
  getOrCreatePlayer,
  parseCsvStrings,
  readJsonBody,
  toDTO,
  ValidationError,
} from "@/lib/game/player-service";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const body = await readJsonBody(req);
    if (body === null || typeof body !== "object") {
      return errorResponse("Corps de requête invalide", 400);
    }
    const { pid, ballId } = body as { pid?: unknown; ballId?: unknown };
    if (typeof ballId !== "string" || ballId.length === 0) {
      return errorResponse("ballId requis", 400);
    }

    const player = await getOrCreatePlayer(pid as string);

    if (!ballExists(ballId)) return errorResponse("Ballon inconnu", 400);
    if (!parseCsvStrings(player.ownedBalls).includes(ballId)) {
      return errorResponse("Ballon non possédé", 400);
    }

    const updated = await db.player.update({
      where: { id: player.id },
      data: { selectedBall: ballId },
    });

    return NextResponse.json({ ok: true, player: toDTO(updated) });
  } catch (err) {
    if (err instanceof ValidationError) return errorResponse(err.message, 400);
    console.error("[api/player/select] POST failed:", err);
    return errorResponse("Erreur serveur", 500);
  }
}
