/* ============================================================
   POST /api/player/xp { pid, amount, reason }
   Bonus XP manuel (ex : "ad_double" après un rewarded).
   amount entier clampé à 1..MAX_MANUAL_XP (pas d'erreur).
============================================================ */

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { computeLevel, MAX_MANUAL_XP } from "@/lib/game/xp";
import {
  errorResponse,
  getOrCreatePlayer,
  readJsonBody,
  toDTO,
  ValidationError,
} from "@/lib/game/player-service";
import type { XpResponse } from "@/lib/game/types";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const body = await readJsonBody(req);
    if (body === null || typeof body !== "object") {
      return errorResponse("Corps de requête invalide", 400);
    }
    const { pid, amount } = body as { pid?: unknown; amount?: unknown };

    let xpGained = Math.floor(Number(amount));
    if (!Number.isFinite(xpGained)) xpGained = 1;
    xpGained = Math.min(MAX_MANUAL_XP, Math.max(1, xpGained));

    const player = await getOrCreatePlayer(pid as string);
    const levelBefore = computeLevel(player.totalXp).level;

    const updated = await db.player.update({
      where: { id: player.id },
      data: { totalXp: { increment: xpGained } },
    });

    const levelUp = levelBefore < computeLevel(updated.totalXp).level;

    const payload: XpResponse = {
      ok: true,
      xpGained,
      levelUp,
      player: toDTO(updated),
    };
    return NextResponse.json(payload);
  } catch (err) {
    if (err instanceof ValidationError) return errorResponse(err.message, 400);
    console.error("[api/player/xp] POST failed:", err);
    return errorResponse("Erreur serveur", 500);
  }
}
