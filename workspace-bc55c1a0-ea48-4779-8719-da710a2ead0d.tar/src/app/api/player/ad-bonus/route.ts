/* ============================================================
   POST /api/player/ad-bonus { pid }
   Bonus quotidien après pub rewarded (cooldown 24 h).
   Incrément atomique : lastAdBonusAt, totalXp (+AD_BONUS_XP),
   adsWatched. 429 si le cooldown n'est pas écoulé.
============================================================ */

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { AD_BONUS_COOLDOWN_MS, AD_BONUS_XP } from "@/lib/game/xp";
import {
  errorResponse,
  getOrCreatePlayer,
  readJsonBody,
  toDTO,
  ValidationError,
} from "@/lib/game/player-service";
import type { AdBonusResponse } from "@/lib/game/types";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const body = await readJsonBody(req);
    if (body === null || typeof body !== "object") {
      return errorResponse("Corps de requête invalide", 400);
    }
    const player = await getOrCreatePlayer((body as { pid?: unknown }).pid as string);

    const now = new Date();
    const cutoff = new Date(now.getTime() - AD_BONUS_COOLDOWN_MS);

    // Update conditionnel : évite les doubles claims concurrents.
    const res = await db.player.updateMany({
      where: {
        id: player.id,
        OR: [{ lastAdBonusAt: null }, { lastAdBonusAt: { lt: cutoff } }],
      },
      data: {
        lastAdBonusAt: now,
        totalXp: { increment: AD_BONUS_XP },
        adsWatched: { increment: 1 },
      },
    });

    if (res.count === 0) {
      return errorResponse("Bonus déjà réclamé — revenez plus tard", 429);
    }

    const updated = await db.player.findUniqueOrThrow({ where: { id: player.id } });

    const payload: AdBonusResponse = {
      ok: true,
      xpGained: AD_BONUS_XP,
      player: toDTO(updated),
    };
    return NextResponse.json(payload);
  } catch (err) {
    if (err instanceof ValidationError) return errorResponse(err.message, 400);
    console.error("[api/player/ad-bonus] POST failed:", err);
    return errorResponse("Erreur serveur", 500);
  }
}
