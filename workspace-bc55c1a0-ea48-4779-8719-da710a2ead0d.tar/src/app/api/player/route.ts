/* ============================================================
   GET  /api/player?pid=... → { ok, player: PlayerDTO }
   POST /api/player { pid }  → identique au GET.
   Crée le joueur s'il n'existe pas.
============================================================ */

import { NextRequest, NextResponse } from "next/server";
import {
  errorResponse,
  getOrCreatePlayer,
  readJsonBody,
  toDTO,
  ValidationError,
} from "@/lib/game/player-service";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  try {
    const pid = req.nextUrl.searchParams.get("pid");
    if (pid === null) return errorResponse("pid requis", 400);

    const player = await getOrCreatePlayer(pid);
    return NextResponse.json({ ok: true, player: toDTO(player) });
  } catch (err) {
    if (err instanceof ValidationError) return errorResponse(err.message, 400);
    console.error("[api/player] GET failed:", err);
    return errorResponse("Erreur serveur", 500);
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await readJsonBody(req);
    if (body === null || typeof body !== "object") {
      return errorResponse("Corps de requête invalide", 400);
    }
    const pid = (body as { pid?: unknown }).pid;
    if (pid === undefined || pid === null) return errorResponse("pid requis", 400);

    const player = await getOrCreatePlayer(pid as string);
    return NextResponse.json({ ok: true, player: toDTO(player) });
  } catch (err) {
    if (err instanceof ValidationError) return errorResponse(err.message, 400);
    console.error("[api/player] POST failed:", err);
    return errorResponse("Erreur serveur", 500);
  }
}
