/* ============================================================
   POST /api/player/complete { pid, levelId, timeMs?, stars? }
   Complétion d'un niveau :
   - première fois → xpReward complet, id ajouté au CSV
   - replay        → replayReward (25 %, min 10)
   Incrémente totalXp + levelWins, recalcule levelUp.
   timeMs / stars sont acceptés mais non persistés (aucun champ
   correspondant dans le schéma actuel).
============================================================ */

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getLevel } from "@/lib/game/levels";
import { computeLevel, replayReward } from "@/lib/game/xp";
import {
  addLevelToCsv,
  csvHasLevel,
  errorResponse,
  getOrCreatePlayer,
  readJsonBody,
  toDTO,
  ValidationError,
} from "@/lib/game/player-service";
import type { CompleteResponse } from "@/lib/game/types";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const body = await readJsonBody(req);
    if (body === null || typeof body !== "object") {
      return errorResponse("Corps de requête invalide", 400);
    }
    const { pid, levelId } = body as { pid?: unknown; levelId?: unknown };

    const id = Number(levelId);
    if (!Number.isInteger(id)) return errorResponse("levelId requis", 400);
    const level = getLevel(id);
    if (!level) return errorResponse("Niveau inconnu", 400);

    const player = await getOrCreatePlayer(pid as string);
    const levelBefore = computeLevel(player.totalXp).level;

    const firstCompletion = !csvHasLevel(player.completedLvls, level.id);
    const xpGained = firstCompletion
      ? level.xpReward
      : replayReward(level.xpReward);

    const updated = await db.player.update({
      where: { id: player.id },
      data: {
        totalXp: { increment: xpGained },
        levelWins: { increment: 1 },
        completedLvls: firstCompletion
          ? addLevelToCsv(player.completedLvls, level.id)
          : player.completedLvls,
      },
    });

    const levelUp = levelBefore < computeLevel(updated.totalXp).level;

    const payload: CompleteResponse = {
      ok: true,
      firstCompletion,
      xpGained,
      levelUp,
      player: toDTO(updated),
    };
    return NextResponse.json(payload);
  } catch (err) {
    if (err instanceof ValidationError) return errorResponse(err.message, 400);
    console.error("[api/player/complete] POST failed:", err);
    return errorResponse("Erreur serveur", 500);
  }
}
