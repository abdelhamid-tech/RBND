/* ============================================================
   POST /api/player/ad-watched { pid }
   Incrémente adsWatched pour toute pub rewarded regardée
   ailleurs que le bonus quotidien.
============================================================ */

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  errorResponse,
  getOrCreatePlayer,
  readJsonBody,
  toDTO,
  ValidationError,
} from "@/lib/game/player-service";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const body = await readJsonBody(req);
    if (body === null || typeof body !== "object") {
      return errorResponse("Corps de requête invalide", 400);
    }
    const player = await getOrCreatePlayer((body as { pid?: unknown }).pid as string);

    const updated = await db.player.update({
      where: { id: player.id },
      data: { adsWatched: { increment: 1 } },
    });

    return NextResponse.json({ ok: true, player: toDTO(updated) });
  } catch (err) {
    if (err instanceof ValidationError) return errorResponse(err.message, 400);
    console.error("[api/player/ad-watched] POST failed:", err);
    return errorResponse("Erreur serveur", 500);
  }
}
