/* ============================================================
   POST /api/player/buy { pid, ballId }
   Achat d'un ballon avec l'XP comme devise.
   IMPORTANT : l'XP ne diminue JAMAIS — on vérifie seulement
   totalXp >= price. L'achat ajoute le ballon aux ownedBalls
   et le sélectionne automatiquement.
============================================================ */

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ballExists, getBall } from "@/lib/game/balls";
import {
  addToCsv,
  errorResponse,
  getOrCreatePlayer,
  parseCsvStrings,
  readJsonBody,
  toDTO,
  ValidationError,
} from "@/lib/game/player-service";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const body = await readJsonBody(req);
    if (body === null || typeof body !== "object") {
      return errorResponse("Corps de requête invalide", 400);
    }
    const { pid, ballId } = body as { pid?: unknown; ballId?: unknown };
    if (typeof ballId !== "string" || ballId.length === 0) {
      return errorResponse("ballId requis", 400);
    }

    const player = await getOrCreatePlayer(pid as string);

    if (!ballExists(ballId)) return errorResponse("Ballon inconnu", 400);
    if (parseCsvStrings(player.ownedBalls).includes(ballId)) {
      return errorResponse("Ballon déjà possédé", 400);
    }

    const price = getBall(ballId).price;
    if (player.totalXp < price) return errorResponse("XP insuffisant", 400);

    // XP conservée intégralement (monnaie non consommable) :
    // seul le ballon est débloqué et sélectionné.
    const updated = await db.player.update({
      where: { id: player.id },
      data: {
        ownedBalls: addToCsv(player.ownedBalls, ballId),
        selectedBall: ballId,
      },
    });

    return NextResponse.json({ ok: true, player: toDTO(updated) });
  } catch (err) {
    if (err instanceof ValidationError) return errorResponse(err.message, 400);
    console.error("[api/player/buy] POST failed:", err);
    return errorResponse("Erreur serveur", 500);
  }
}
